package app.pdfreader.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.pdfreader.ai.AiTask
import app.pdfreader.ui.l10n.LocalStrings

@Composable
private fun taskTitle(t: AiTask, page: Int, rangeTo: Int): String {
    val str = LocalStrings.current
    return when {
        rangeTo >= 0 -> str.taskTitleRangeSummary(page + 1, rangeTo + 1)
        t == AiTask.EXTRACT -> str.taskTitleExtract(page + 1)
        t == AiTask.TRANSLATE -> str.taskTitleTranslate(page + 1)
        t == AiTask.EXPLAIN -> str.taskTitleExplain(page + 1)
        else -> str.taskTitleSummary(page + 1)
    }
}

/** True when RTL letters dominate this paragraph (so a Persian paragraph that starts with "P&ID" stays RTL). */
fun isRtlParagraph(s: String): Boolean {
    var rtl = 0
    var ltr = 0
    for (ch in s) {
        when (Character.getDirectionality(ch)) {
            Character.DIRECTIONALITY_RIGHT_TO_LEFT, Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC -> rtl++
            Character.DIRECTIONALITY_LEFT_TO_RIGHT -> ltr++
            else -> {}
        }
    }
    return rtl > 0 && rtl >= ltr
}

/** The model sometimes answers with Markdown; show it as clean text. */
fun cleanMarkdown(s: String): String = s.lines().joinToString("\n") { line ->
    if (line.trimStart().startsWith("|")) line else
        line.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^(\\s*)[*\\-]\\s+"), "\$1• ")
}

sealed interface Block {
    class Para(val text: String) : Block
    class Table(val rows: List<List<String>>) : Block
}

/** Splits text into paragraphs and Markdown tables. */
fun parseBlocks(text: String): List<Block> {
    val out = mutableListOf<Block>()
    val para = StringBuilder()
    val rows = mutableListOf<List<String>>()
    fun flushPara() {
        if (para.isNotBlank()) out += Block.Para(para.toString().trim())
        para.clear()
    }
    fun flushTable() {
        if (rows.isNotEmpty()) out += Block.Table(rows.toList())
        rows.clear()
    }
    for (line in cleanMarkdown(text).lines()) {
        val t = line.trim()
        if (t.startsWith("|")) {
            flushPara()
            if (Regex("^[|\\s:\\-]+$").matches(t)) continue // separator row
            rows += t.trim('|').split('|').map { it.trim().replace("**", "") }
        } else {
            flushTable()
            if (t.isEmpty()) flushPara() else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(t)
            }
        }
    }
    flushTable()
    flushPara()
    return out
}

@Composable
private fun ParaText(text: String, rtl: Boolean, muted: Boolean = false) {
    Text(
        text,
        modifier = Modifier.fillMaxWidth(),
        style = (if (muted) MaterialTheme.typography.bodyMedium else MaterialTheme.typography.bodyLarge).copy(
            textDirection = if (rtl) TextDirection.Rtl else TextDirection.Ltr,
            textAlign = TextAlign.Start,
        ),
        color = if (muted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
    )
}

@Composable
private fun TableView(rows: List<List<String>>, rtl: Boolean) {
    val cols = rows.maxOf { it.size }.coerceAtLeast(1)
    val cell = when {
        cols <= 2 -> 170.dp
        cols == 3 -> 130.dp
        else -> 110.dp
    }
    val shape = RoundedCornerShape(12.dp)
    CompositionLocalProvider(LocalLayoutDirection provides if (rtl) LayoutDirection.Rtl else LayoutDirection.Ltr) {
        Column(
            Modifier.horizontalScroll(rememberScrollState()).clip(shape)
                .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape),
        ) {
            rows.forEachIndexed { ri, row ->
                val bg = when {
                    ri == 0 -> MaterialTheme.colorScheme.primaryContainer
                    ri % 2 == 0 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                    else -> Color.Transparent
                }
                Row(Modifier.background(bg)) {
                    for (c in 0 until cols) {
                        val v = row.getOrElse(c) { "" }
                        Text(
                            v,
                            modifier = Modifier.width(cell).padding(horizontal = 10.dp, vertical = 8.dp),
                            style = MaterialTheme.typography.bodyMedium.copy(
                                textDirection = if (isRtlParagraph(v) || (rtl && v.none { it.isLetter() })) TextDirection.Rtl else TextDirection.Ltr,
                                textAlign = TextAlign.Start,
                            ),
                            fontWeight = if (ri == 0) FontWeight.Bold else FontWeight.Normal,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BlockView(b: Block, rtl: Boolean, muted: Boolean = false) {
    when (b) {
        is Block.Para -> ParaText(b.text, rtl, muted)
        is Block.Table -> TableView(b.rows, rtl)
    }
}

/** Renders text with paragraphs, tables, per-block direction and (optionally) the source text next to it. */
@Composable
fun RichText(text: String, rtl: Boolean, original: String? = null, forceRtl: Boolean = true) {
    val blocks = parseBlocks(text)
    val orig = if (original.isNullOrBlank()) null else parseBlocks(original)
    fun dirOf(b: Block) = if (forceRtl) rtl else (b as? Block.Para)?.let { isRtlParagraph(it.text) } ?: rtl
    SelectionContainer {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (orig != null) {
                val count = maxOf(orig.size, blocks.size)
                for (i in 0 until count) {
                    val o = orig.getOrNull(i)
                    val b = blocks.getOrNull(i)
                    Column(
                        Modifier.fillMaxWidth()
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
                            .padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (o != null) {
                            BlockView(o, rtl = false, muted = true)
                        }
                        if (b != null) {
                            BlockView(b, dirOf(b))
                        }
                    }
                }
            } else {
                blocks.forEach { BlockView(it, dirOf(it)) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AiResultSheet(
    state: AiUi,
    bilingual: Boolean,
    onBilingualChange: (Boolean) -> Unit,
    onDismiss: () -> Unit,
    onRetry: (AiUi.Done) -> Unit,
    onCancel: () -> Unit = {},
    onNextModel: () -> Unit = {},
) {
    if (state is AiUi.Idle) return
    val clipboard = LocalClipboardManager.current
    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            when (state) {
                is AiUi.Loading -> {
                    Text(taskTitle(state.task, state.page, state.rangeTo), style = MaterialTheme.typography.titleLarge)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.padding(vertical = 8.dp),
                    ) {
                        CircularProgressIndicator(modifier = Modifier.size(28.dp), strokeWidth = 3.dp)
                        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            val status = if (state.currentModel.isNotBlank()) {
                                "${state.phase} · ${state.currentModel} · ${LocalStrings.current.elapsedSeconds(state.elapsedSeconds)}"
                            } else {
                                "${state.phase} · ${LocalStrings.current.elapsedSeconds(state.elapsedSeconds)}"
                            }
                            Text(status, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            Text(LocalStrings.current.aiProcessing, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    // Router already auto-falls through models; no manual "next model" button.
                    OutlinedButton(
                        onClick = onCancel,
                        modifier = Modifier.padding(top = 8.dp),
                    ) {
                        Text(LocalStrings.current.cancel, style = MaterialTheme.typography.labelMedium)
                    }
                }
                is AiUi.Streaming -> {
                    Text(taskTitle(state.task, state.page, state.rangeTo), style = MaterialTheme.typography.titleLarge)
                    Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                        RichText(state.text, state.rtl, if (bilingual) state.original else null)
                    }
                    Text(LocalStrings.current.receiving, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                is AiUi.Done -> {
                    val ctx = LocalContext.current
                    Text(taskTitle(state.task, state.page, state.rangeTo), style = MaterialTheme.typography.titleLarge)
                    if (state.task == AiTask.TRANSLATE && state.rangeTo < 0) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("نمایش متن اصلی کنار ترجمه", Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                            Switch(checked = bilingual, onCheckedChange = onBilingualChange)
                        }
                    }
                    Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState())) {
                        RichText(state.text, state.rtl, if (bilingual) state.original else null)
                    }
                    Row {
                        TextButton(onClick = { clipboard.setText(AnnotatedString(state.text)) }) { Text("کپی") }
                        if (state.handoutPdfPath != null) {
                            TextButton(onClick = {
                                try {
                                    val f = File(state.handoutPdfPath)
                                    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", f)
                                    val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    ctx.startActivity(Intent.createChooser(i, "باز کردن جزوه"))
                                } catch (_: Exception) {}
                            }) { Text("باز کردن PDF") }
                        }
                        TextButton(onClick = { onRetry(state) }) { Text("تولید دوباره") }
                        TextButton(onClick = onDismiss) { Text("بستن") }
                    }
                }
                is AiUi.Error -> {
                    Text(state.message, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = onDismiss) { Text("بستن") }
                }
                AiUi.Idle -> {}
            }
        }
    }
}
