package app.pdfreader.ai

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import java.io.File

/** Persian OCR output. [confidence] is Tesseract's mean confidence (0..100), or -1 if unknown. */
class PersianOcrResult(val text: String, val confidence: Int)

/**
 * On-device OCR. ML Kit handles Latin-script languages; bundled Tesseract `fas`
 * (LSTM) model handles Persian. Both run locally and do not require an API key/network.
 *
 * Note: the bundled fas.traineddata is an LSTM-only model, so it needs Tesseract 4+
 * (tesseract4android). The old tess-two library (Tesseract 3.05) cannot load it.
 */
object LocalOcr {
    private const val TAG = "LocalOcr"
    private const val PSM_AUTO = 3

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    @Volatile private var persianApi: TessBaseAPI? = null
    private val persianLock = Any()

    suspend fun recognize(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result -> if (cont.isActive) cont.resume(result.text.orEmpty()) }
            .addOnFailureListener { if (cont.isActive) cont.resume("") }
    }

    /** Persian OCR using a model shipped in app assets; no runtime download. */
    fun recognizePersian(context: Context, bitmap: Bitmap): PersianOcrResult = synchronized(persianLock) {
        val api = persianApi ?: createPersianApi(context.applicationContext).also { persianApi = it }
        try {
            api.setPageSegMode(PSM_AUTO)
            api.setImage(bitmap)
            val text = api.getUTF8Text().orEmpty()
            val conf = try { api.meanConfidence() } catch (_: Throwable) { -1 }
            PersianOcrResult(text, conf)
        } finally {
            try { api.clear() } catch (_: Throwable) { }
        }
    }

    private fun createPersianApi(context: Context): TessBaseAPI {
        val root = File(context.filesDir, "tesseract")
        val tessdata = File(root, "tessdata")
        if (!tessdata.exists()) tessdata.mkdirs()
        val model = File(tessdata, "fas.traineddata")
        if (!model.exists() || model.length() < 100_000L) {
            val tmp = File(tessdata, "fas.traineddata.tmp")
            context.assets.open("tessdata/fas.traineddata").use { input ->
                tmp.outputStream().use(input::copyTo)
            }
            if (model.exists()) model.delete()
            check(tmp.renameTo(model)) { "Could not install Persian OCR model" }
        }
        val api = TessBaseAPI()
        val ok = try {
            api.init(root.absolutePath, "fas")
        } catch (t: Throwable) {
            Log.e(TAG, "Tesseract init threw", t)
            false
        }
        if (!ok) {
            try { api.recycle() } catch (_: Throwable) { }
            Log.e(TAG, "Tesseract init failed for the fas model")
            throw IllegalStateException("Could not initialize Persian OCR model")
        }
        return api
    }
}
