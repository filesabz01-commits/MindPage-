package app.pdfreader.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Google Translate (unofficial free endpoint) with structure-aware handling:
 * - Paragraphs translated in chunks
 * - Tables: translate row batches with stable cell markers and rebuild the exact grid.
 * - Technical spans: protect formulas, inline/display math, code and engineering units.
 */
object GoogleTranslateService {

    @Volatile private var activeBaseUrl: String = "https://translate.googleapis.com"

    // Preserve equipment tags and numeric/measurement-only cells. Do not skip ordinary
    // capitalized words (e.g. Tank, Pump, Design) just because they look like labels.
    private val keepAsIs = Regex(
        """^(?:(?:[A-Z]{1,4}[- ]?\d{1,5}[A-Z]?(?:/[A-Z0-9]+)?)|(?:[\d.,+\-×^/()°\s]+(?:[A-Za-z°µ%Ω/0-9]*)?)|N/?A)$""",
        RegexOption.IGNORE_CASE,
    )

    suspend fun translate(
        text: String,
        sourceLang: String = "auto",
        targetLang: String = "fa",
        baseUrl: String = "https://translate.googleapis.com",
        stripHeaders: Boolean = true,
    ): String =
        withContext(Dispatchers.IO) {
            activeBaseUrl = baseUrl.ifBlank { "https://translate.googleapis.com" }
            val cleaned = if (stripHeaders) {
                TextQuality.stripPageFurniture(TextQuality.stripPublisherNoise(text))
                    .ifBlank { TextQuality.localClean(text).ifBlank { text.trim() } }
            } else TextQuality.stripPublisherNoise(TextQuality.localClean(text).ifBlank { text.trim() })
            if (cleaned.isBlank()) return@withContext ""
            val structured = TextQuality.promoteTables(cleaned)
            val normalized = coalesceTableLines(structured)
            // Keep every detected table intact, regardless of its width. Flattening here
            // destroys the row/column mapping and cannot be repaired after translation.
            val blocks = splitBlocks(normalized)
            val out = ArrayList<String>(blocks.size)
            for (b in blocks) {
                when (b) {
                    is Block.Para -> {
                        val t = b.text.trim()
                        if (t.isNotEmpty()) out += translateParagraph(t, sourceLang, targetLang)
                        else out += ""
                    }
                    is Block.Table -> out += translateTable(b.rows, sourceLang, targetLang)
                }
            }
            out.joinToString("\n\n").trim()
        }

    private suspend fun translateParagraph(text: String, sl: String, tl: String): String {
        val protected = protectTechnicalSpans(text)
        val input = protected.first
        val translated = if (input.length <= 2500) {
            translateChunk(input, sl, tl)
        } else {
            val sentences = input.split(Regex("(?<=[.!?\\n])\\s+"))
            val chunk = StringBuilder()
            val parts = mutableListOf<String>()
            for (sentence in sentences) {
                if (chunk.length + sentence.length > 2000 && chunk.isNotEmpty()) {
                    parts += translateChunk(chunk.toString(), sl, tl)
                    chunk.clear()
                }
                if (chunk.isNotEmpty()) chunk.append(' ')
                chunk.append(sentence)
            }
            if (chunk.isNotEmpty()) parts += translateChunk(chunk.toString(), sl, tl)
            parts.joinToString(" ")
        }
        return restoreTechnicalSpans(translated, protected.second)
    }

    /** Protect inline math, display math, code and common engineering expressions from translation. */
    private fun protectTechnicalSpans(text: String): Pair<String, Map<String, String>> {
        val tokens = linkedMapOf<String, String>()
        val patterns = listOf(
            Regex("(?s)```.*?```"),
            Regex("`[^`\\n]+`"),
            Regex("\\\\\\(.*?\\\\\\)"),
            Regex("\\\\\\[.*?\\\\\\]"),
            Regex("\\$\\$.*?\\$\\$"),
            Regex("\\$(?:[^$\\n]{1,120})\\$"),
            Regex("(?<![A-Za-z])(?:[A-Za-z]\\s*=\\s*[^,;.!?\\n]{1,80})(?![A-Za-z])"),
            Regex("(?<!\\w)(?:[0-9]+(?:\\.[0-9]+)?\\s*(?:V|kV|mV|A|mA|kA|W|kW|MW|Hz|kHz|MHz|Pa|kPa|MPa|GPa|N|kN|J|kJ|kg|mg|mm|cm|km|m|\\u00B0C|\\u00B0F|%|\\u03A9))(?!\\w)")
        )
        var result = text
        var index = 0
        for (pattern in patterns) {
            result = pattern.replace(result) { match ->
                val token = "ZXQTECH${index++}QXZ"
                tokens[token] = match.value
                token
            }
        }
        return result to tokens
    }

    private fun restoreTechnicalSpans(text: String, tokens: Map<String, String>): String {
        var result = text
        for ((token, original) in tokens) result = result.replace(token, original)
        return result
    }

    /**
     * Structure-preserving table translation:
     * keep the Markdown grid; translate each row as one marked batch. Markers bind each
     * translated cell to its original column. If the endpoint alters markers, use safe
     * per-cell fallback rather than risk putting text in the wrong column.
     */
    private suspend fun translateTable(rows: List<List<String>>, sl: String, tl: String): String {
        if (rows.isEmpty()) return ""
        val colCount = rows.maxOf { it.size }.coerceAtLeast(1)
        val normalized = rows.map { row -> List(colCount) { c -> row.getOrElse(c) { "" }.trim() } }

        // Translate a complete row in one request using stable cell markers. This reduces
        // endpoint calls substantially while keeping every value tied to its original column.
        val translatedRows = normalized.mapIndexed { rowIndex, row ->
            if (rowIndex == 0 && row.all { it.isBlank() }) return@mapIndexed row
            val candidates = row.mapIndexedNotNull { col, cell ->
                if (cell.isBlank() || cell == "---" || cell.matches(Regex("^:?-+:?$")) ||
                    keepAsIs.matches(cell) || cell.length <= 1) null
                else col to protectTechnicalSpans(cell)
            }
            if (candidates.isEmpty()) return@mapIndexed row

            val markerToColumn = linkedMapOf<String, Int>()
            val joined = buildString {
                candidates.forEachIndexed { i, (col, protected) ->
                    val marker = "ZXQCELL${rowIndex}X${col}QXZ"
                    markerToColumn[marker] = col
                    if (i > 0) append(" ZXQSEP${rowIndex}QXZ ")
                    append(marker).append(' ').append(protected.first)
                }
            }
            val translated = try { translateChunk(joined, sl, tl) } catch (_: Exception) { "" }
            val parsed = parseMarkedCells(translated, markerToColumn.keys.toList())
            val result = row.toMutableList()
            if (parsed != null) {
                for ((i, entry) in candidates.withIndex()) {
                    val (col, protected) = entry
                    val value = parsed[i].trim()
                    if (value.isNotBlank()) result[col] = restoreTechnicalSpans(value, protected.second)
                }
            } else {
                // Endpoint may strip/reorder markers. Safe fallback: translate cells separately;
                // never guess the destination column from an ambiguous response.
                for ((col, protected) in candidates) {
                    val value = try { translateChunk(protected.first, sl, tl) } catch (_: Exception) { "" }
                    if (value.isNotBlank()) result[col] = restoreTechnicalSpans(value, protected.second)
                }
            }
            result
        }

        return buildString {
            translatedRows.forEachIndexed { i, row ->
                val safeCells = row.map { it.replace("|", "\\|").replace("\r", " ").replace("\n", " ") }
                append("| ").append(safeCells.joinToString(" | ")).append(" |\n")
                if (i == 0) append("| ").append(List(colCount) { "---" }.joinToString(" | ")).append(" |\n")
            }
        }.trimEnd()
    }

    private fun parseMarkedCells(translated: String, markers: List<String>): List<String>? {
        if (markers.isEmpty()) return emptyList()
        val positions = markers.map { marker -> translated.indexOf(marker) }
        if (positions.any { it < 0 } || positions.zipWithNext().any { (a, b) -> b <= a }) return null
        return markers.mapIndexed { index, marker ->
            val start = positions[index] + marker.length
            val end = if (index == markers.lastIndex) translated.length else {
                val next = positions[index + 1]
                val sep = translated.lastIndexOf("ZXQSEP", next)
                if (sep >= start) sep else next
            }
            translated.substring(start, end).trim().removePrefix("ZXQSEP${index}QXZ").trim()
        }
    }

    private fun coalesceTableLines(text: String): String {
        val paras = text.split(Regex("\\n\\s*\\n"))
        val out = mutableListOf<String>()
        val buf = mutableListOf<String>()
        fun flushBuf() {
            if (buf.isEmpty()) return
            out += if (buf.size >= 2) buf.joinToString("\n") else buf[0]
            buf.clear()
        }
        for (p in paras) {
            val lines = p.trim().split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            val allTable = lines.isNotEmpty() && lines.all { TextQuality.looksLikeTableRow(it) || it.startsWith("|") }
            if (allTable) buf.addAll(lines)
            else {
                flushBuf()
                out += p.trim()
            }
        }
        flushBuf()
        return out.filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private sealed class Block {
        data class Para(val text: String) : Block()
        data class Table(val rows: List<List<String>>) : Block()
    }

    private fun splitBlocks(text: String): List<Block> {
        val lines = text.replace("\r\n", "\n").split('\n')
        val blocks = mutableListOf<Block>()
        val para = StringBuilder()
        val tableRows = mutableListOf<List<String>>()

        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) blocks += Block.Para(t)
            para.clear()
        }
        fun flushTable() {
            if (tableRows.isNotEmpty()) {
                blocks += Block.Table(tableRows.toList())
                tableRows.clear()
            }
        }

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val md = parseMarkdownRow(line)
            if (md != null) {
                flushPara()
                while (i < lines.size) {
                    val r = parseMarkdownRow(lines[i])
                    if (r != null) {
                        tableRows += r
                        i++
                    } else if (isMarkdownSeparator(lines[i])) {
                        i++
                    } else break
                }
                flushTable()
                continue
            }

            val cells = parseAlignedRow(line)
            if (cells != null && cells.size >= 2) {
                var j = i + 1
                val probe = mutableListOf(cells)
                while (j < lines.size) {
                    val next = parseAlignedRow(lines[j])
                    if (next != null && next.size >= 2) {
                        probe += next
                        j++
                    } else if (lines[j].isBlank()) break
                    else break
                }
                if (probe.size >= 2) {
                    flushPara()
                    tableRows.addAll(probe)
                    flushTable()
                    i = j
                    continue
                }
            }

            if (line.isBlank()) {
                flushPara()
            } else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(line)
            }
            i++
        }
        flushPara()
        flushTable()
        return blocks
    }

    private fun isMarkdownSeparator(line: String): Boolean {
        val t = line.trim()
        return t.matches(Regex("^\\|?[\\s:\\-]+\\|([\\s:\\-]+\\|)*[\\s:\\-]*\\|?$"))
    }

    private fun parseMarkdownRow(line: String): List<String>? {
        val t = line.trim()
        if (!t.startsWith("|") || t.indexOf('|', startIndex = 1) < 0) return null
        if (isMarkdownSeparator(t)) return null
        val parts = t.trim('|').split("|").map { it.trim() }
        return if (parts.any { it.isNotEmpty() }) parts else null
    }

    private fun parseAlignedRow(line: String): List<String>? {
        val t = line.trim()
        if (t.length < 3) return null
        if (t.startsWith("#") || t.startsWith("- ") || t.startsWith("* ") || t.startsWith("•")) return null
        if (t.contains('\t')) {
            val cells = t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            return if (cells.size >= 2) cells else null
        }
        val cells = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (cells.size >= 2) {
            val shortish = cells.count { it.length <= 40 }
            if (cells.size >= 3 || shortish >= 2) return cells
        }
        return null
    }

    private fun translateChunk(chunk: String, sl: String, tl: String): String {
        val textToTranslate = chunk.trim()
        if (textToTranslate.isEmpty()) return ""

        val sLang = if (sl.isBlank() || sl == "auto") "auto" else sl
        val tLang = if (tl.isBlank()) "fa" else tl
        val path = "${activeBaseUrl.trimEnd('/')}/translate_a/single"

        var lastError: Exception? = null
        for (attempt in 0 until 4) {
            try {
                val usePost = attempt < 2
                val conn: HttpURLConnection = if (usePost) {
                    val body = "client=gtx&sl=$sLang&tl=$tLang&dt=t&q=${URLEncoder.encode(textToTranslate, "UTF-8")}"
                    (URL(path).openConnection() as HttpURLConnection).also { c ->
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                        c.setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
                        )
                        c.connectTimeout = 12_000
                        c.readTimeout = 20_000
                        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                } else {
                    val encoded = URLEncoder.encode(textToTranslate, "UTF-8")
                    (URL("$path?client=gtx&sl=$sLang&tl=$tLang&dt=t&q=$encoded").openConnection() as HttpURLConnection).also { c ->
                        c.requestMethod = "GET"
                        c.setRequestProperty(
                            "User-Agent",
                            "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
                        )
                        c.connectTimeout = 12_000
                        c.readTimeout = 20_000
                    }
                }
                try {
                    val code = conn.responseCode
                    if (code == 429 || code in 500..599) {
                        lastError = IOException("HTTP $code")
                        Thread.sleep((800L * (1 shl attempt)).coerceAtMost(8_000L))
                        continue
                    }
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    if (code !in 200..299) {
                        lastError = IOException("HTTP $code ${resp.take(100)}")
                        continue
                    }
                    val root = JSONArray(resp)
                    val sentences = root.optJSONArray(0)
                    if (sentences == null) {
                        lastError = IOException("bad response")
                        continue
                    }
                    val sb = StringBuilder()
                    for (i in 0 until sentences.length()) {
                        val part = sentences.optJSONArray(i) ?: continue
                        val str = part.optString(0, "")
                        if (str.isNotEmpty()) sb.append(str)
                    }
                    val result = sb.toString()
                    if (result.isNotEmpty()) return result
                    lastError = IOException("empty translation")
                } finally {
                    try { conn.disconnect() } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                lastError = e
                Thread.sleep((500L * (1 shl attempt)).coerceAtMost(5_000L))
            }
        }
        // Never silently return the source as if it were a translation
        throw IOException("Google Translate failed: ${lastError?.message ?: "unknown"}", lastError)
    }
}
