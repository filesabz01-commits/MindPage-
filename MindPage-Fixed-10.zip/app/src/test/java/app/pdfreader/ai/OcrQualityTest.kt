package app.pdfreader.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OcrQualityTest {
    @Test
    fun goodEnglishIsAccepted() {
        val t = "The quick brown fox jumps over the lazy dog and runs across the field."
        assertTrue(TextQuality.ocrQuality(t, OcrScript.LATIN, null))
    }

    @Test
    fun dottedBlanksDoNotCountAsGarbage() {
        val t = "If you want to make something clear, it's better to avoid ............ and be precise today."
        assertTrue(TextQuality.ocrQuality(t, OcrScript.LATIN, null))
    }

    @Test
    fun symbolSoupIsRejected() {
        val t = "~~ ^^ || ## @@ << >> ~~ ^^ || ## @@ << >> ~~ ^^ || ## @@ << >> ~~"
        assertFalse(TextQuality.ocrQuality(t, OcrScript.LATIN, null))
    }

    @Test
    fun tooShortIsRejected() {
        assertFalse(TextQuality.ocrQuality("Hello world", OcrScript.LATIN, null))
    }

    @Test
    fun persianTextNeedsPersianScript() {
        val fa = "این یک متن آزمایشی فارسی است که باید به درستی خوانده شود و کیفیت آن خوب باشد."
        assertTrue(TextQuality.ocrQuality(fa, OcrScript.PERSIAN, 80))
        assertFalse(TextQuality.ocrQuality(fa, OcrScript.LATIN, null))
    }

    @Test
    fun lowTesseractConfidenceIsRejected() {
        val fa = "این یک متن آزمایشی فارسی است که باید به درستی خوانده شود و کیفیت آن خوب باشد."
        assertFalse(TextQuality.ocrQuality(fa, OcrScript.PERSIAN, 20))
    }
}
