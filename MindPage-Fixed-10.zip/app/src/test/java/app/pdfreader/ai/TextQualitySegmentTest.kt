package app.pdfreader.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextQualitySegmentTest {

    @Test
    fun dropsGlossaryAndDrillsAndCaptionsWhileKeepingContinuousParagraph() {
        val glossaryBox = """
            GLOSSARY
            promise a statement that you will definitely do something
            blame say or think that someone did something wrong
        """.trimIndent()

        val drillLine = "1 If you keep a promise, is that a good thing?......"
        val figureCaption = "Figure 4-2. Centrifugal pump arrangement on the skid with bypass line."
        val runningHeader = "Oxford Word Skills Upper Intermediate"
        val realHeading = "### 3.1 Making and Keeping Promises"
        val normalParagraph = "Learning vocabulary in authentic context is widely recognized by linguists as the most effective method for expanding lexical competence and developing natural language fluency."
        val equipmentTag = "FIC-101"
        val tableColumns = "Word   Part of Speech   Definition"

        assertTrue("Glossary box must be dropped", TextQuality.shouldDropSegment(glossaryBox))
        assertTrue("Fill-in-the-blank drill line must be dropped", TextQuality.shouldDropSegment(drillLine))
        assertTrue("Figure caption must be dropped", TextQuality.shouldDropSegment(figureCaption))
        assertTrue("Running header banner must be dropped", TextQuality.shouldDropSegment(runningHeader))
        assertTrue("Isolated equipment tag must be dropped", TextQuality.shouldDropSegment(equipmentTag))
        assertTrue("Aligned columns must be dropped", TextQuality.shouldDropSegment(tableColumns))

        assertFalse("Real section heading must be kept", TextQuality.shouldDropSegment(realHeading))
        assertFalse("Normal continuous paragraph must be kept", TextQuality.shouldDropSegment(normalParagraph))

        val segments = listOf(
            runningHeader,
            realHeading,
            normalParagraph,
            glossaryBox,
            drillLine,
            figureCaption,
        )

        val filtered = TextQuality.filterMainTextOnly(segments)
        assertTrue(filtered.contains(realHeading))
        assertTrue(filtered.contains(normalParagraph))
        assertFalse(filtered.contains(runningHeader))
        assertFalse(filtered.contains(glossaryBox))
        assertFalse(filtered.contains(drillLine))
        assertFalse(filtered.contains(figureCaption))
    }
}
