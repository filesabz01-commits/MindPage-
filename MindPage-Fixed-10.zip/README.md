# Universal PDF Reader — مرحله ۳
Kotlin + Compose + Material 3 + Room. ساخت: `gradle assembleDebug` (Gradle 8.9، JDK 17، Android SDK 34).

## این مرحله
- ارزیابی ۳‌حالتی صفحه پیش از پردازش: متن سالم (بدون OCR + یک پاکسازی ساختاری) / اسکن (OCR) / متن مخدوش (کنار گذاشتن لایه‌ی خراب + OCR). دکمه‌ی «OCR این صفحه» همیشه OCR اجباری است.
- حذف نویز: DC offset، فید، حذف کلیک/پرش لبه‌ها، مکث بین تکه‌ها، پخش‌کننده‌ی بعدی از قبل آماده، تحویل بدون وقفه حتی بین صفحه‌ها.
- انتخاب متن: دسته‌های کشیدنی، هایلایت چندرنگ، خط‌زیر، خط‌خورده، کپی، یادداشت، فهرست هایلایت‌ها با پرش به صفحه.
- هایلایت صوتی: جمله (از مکث‌های واقعی صدا) + کلمه‌ی در حال خواندن؛ صفحه خودکار دنبال خط خوانده‌شده می‌رود.
- پیش‌بارگذاری: صفحه‌ی بعد (OCR/ترجمه/صدا) هم‌زمان آماده می‌شود، تکه‌ی در حال پخش اولویت دارد، تلاش مجدد با فاصله‌ی فزاینده، نمایش «آماده‌ی پخش: n ثانیه».

## OCR (v0.1.17)
- Local OCR: ML Kit (Latin) + bundled Tesseract `fas` (LSTM model) via the Tesseract4Android 4.9.0 AAR (Tesseract 5.5). CI downloads the AAR from JitPack into `app/libs/tesseract4android.aar` (retries + cache); for a local build put that file there yourself. Works offline, no API key. The old `tess-two` library (Tesseract 3.05) cannot load LSTM-only models, which was why Persian OCR failed without a key.
- Settings → OCR engine: **Local (online backup)** [default], **Local only**, **Online only (Gemini)**.
  - Local: runs on-device; if the result is empty or low quality (`TextQuality.ocrQuality`) and an API key exists, Gemini Vision is tried; otherwise the best local text is kept and marked "low quality".
  - Local only: never goes online. Online only: Gemini Vision only.
- OCR runs in the normal page-extraction path (translate, chat, read-aloud, study, "OCR this page"), not only in Study Mode.
- First Persian OCR copies the model to app storage and may take a few seconds longer.
- Relative times on the home screen follow the app language (Persian: «۷ دقیقه پیش»).
