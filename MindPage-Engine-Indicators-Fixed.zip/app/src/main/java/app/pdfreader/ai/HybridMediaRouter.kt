package app.pdfreader.ai

import app.pdfreader.tts.EdgeTts
import app.pdfreader.tts.ReadMode

/**
 * Smart Hybrid Audio & Translation Router.
 *
 * Enforces key architectural invariants:
 * 1. Original Persian Content:
 *    - Completely bypasses Edge TTS. Never sends Persian narration to Edge TTS.
 *    - Uses Gemini AI TTS with 5-tier fallback model hierarchy.
 *    - Detects Persian language reliably before selecting TTS provider.
 *    - Preserves Persian punctuation, pronunciation, sentence structure, and reading order.
 * 2. Original Foreign-Language Content:
 *    - Uses native Kotlin Edge TTS (OkHttp WebSocket).
 *    - Avoids unnecessary Gemini API calls when Edge TTS is sufficient.
 *    - Preserves voice selection, playback controls, sentence timing, and reading progress.
 * 3. Translation into Persian:
 *    - Respects selected translation engine (Google Translate or Gemini AI).
 *    - Completely bypasses Edge TTS for the resulting Persian narration.
 *    - Sends Persian translated text to the Gemini TTS pipeline.
 * 4. Translation into Foreign-Language:
 *    - Translates using active translation engine.
 *    - Sends translated text to Edge TTS for audio playback.
 * 5. Settings Priority:
 *    - User configuration is strictly respected.
 *    - Translation engine and TTS provider are separate responsibilities.
 */
object HybridMediaRouter {

    /**
     * Reliably detects if text is in Persian (Farsi).
     * Distinguishes Persian from Arabic and Latin scripts using character frequency and Persian-exclusive letters (گ, چ, پ, ژ, ک, ی).
     */
    fun isPersian(text: String, hintSourceLang: String = ""): Boolean {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return hintSourceLang.equals("fa", ignoreCase = true)

        if (hintSourceLang.equals("fa", ignoreCase = true)) return true

        val letters = trimmed.filter { it.isLetter() }
        if (letters.isEmpty()) return false

        var persianSpecific = 0
        var arabicScript = 0
        var latin = 0

        for (ch in letters) {
            when (ch) {
                'گ', 'چ', 'پ', 'ژ', 'ک', 'ی', 'ه' -> {
                    persianSpecific++
                    arabicScript++
                }
                in '\u0600'..'\u06FF', in '\u0750'..'\u077F', in '\u08A0'..'\u08FF',
                in '\uFB50'..'\uFDFF', in '\uFE70'..'\uFEFF' -> arabicScript++
                in 'A'..'Z', in 'a'..'z' -> latin++
            }
        }

        if (persianSpecific >= 1 && arabicScript > latin) return true
        return arabicScript > latin && arabicScript >= (letters.length * 0.35)
    }

    enum class TtsProvider {
        GEMINI_TTS,
        EDGE_TTS,
    }

    data class TtsDecision(
        val provider: TtsProvider,
        val speechLanguage: String,
        val isPersian: Boolean,
        val bypassEdgeTts: Boolean,
        val description: String,
    )

    /**
     * Determines TTS provider based on language and reading mode.
     */
    fun decideTtsRouting(
        spokenText: String,
        mode: ReadMode,
        settings: ReadingSettings,
    ): TtsDecision {
        // Actual script of the spoken text always wins over a stale sourceLanguage setting
        // (e.g. user left source=en while reading a Persian PDF).
        val textIsPersian = isPersian(spokenText, settings.sourceLanguage)
        val targetSpeechLang = when (mode) {
            ReadMode.TRANSLATE_AUDIO -> settings.targetLanguage.ifBlank { "fa" }
            ReadMode.ORIGINAL -> when {
                textIsPersian -> "fa"
                settings.sourceLanguage.isNotBlank() && settings.sourceLanguage != "auto" -> settings.sourceLanguage
                else -> EdgeTts.detectLang(spokenText)
            }
        }

        val persian = targetSpeechLang.equals("fa", ignoreCase = true) || textIsPersian ||
            isPersian(spokenText, targetSpeechLang)

        return if (persian) {
            TtsDecision(
                provider = TtsProvider.GEMINI_TTS,
                speechLanguage = "fa",
                isPersian = true,
                bypassEdgeTts = true,
                description = "Persian text -> Gemini AI TTS first; Edge only as fa-IR fallback.",
            )
        } else {
            TtsDecision(
                provider = TtsProvider.EDGE_TTS,
                speechLanguage = targetSpeechLang,
                isPersian = false,
                bypassEdgeTts = false,
                description = "Foreign language text -> Native Edge TTS via OkHttp WebSocket.",
            )
        }
    }
}
