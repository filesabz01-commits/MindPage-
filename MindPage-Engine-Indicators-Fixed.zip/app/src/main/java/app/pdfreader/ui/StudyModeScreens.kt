package app.pdfreader.ui

import android.graphics.Bitmap
import java.io.ByteArrayOutputStream
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.KeyStatus
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider

import app.pdfreader.ui.l10n.LocalStrings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import android.speech.tts.TextToSpeech
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import app.pdfreader.ai.AiDao
import app.pdfreader.ai.AiRequest
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.CacheEntity
import app.pdfreader.ai.Capability
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class StudyTool { Vocab, Grammar, Quiz, Exercise }

/**
 * Full-screen Study Mode tool screen.
 * Reuses extract/OCR cache via [PageTextService] and caches AI responses in [AiDao]
 * so subsequent opens use 0 extra tokens and display instantly.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyToolScreen(
    tool: StudyTool,
    doc: PdfDocument,
    docUri: String,
    page: Int,
    settings: ReadingSettings,
    pageText: PageTextService,
    router: AiRouter,
    dao: AiDao,
    onDismiss: () -> Unit,
    quizConfig: QuizConfig? = null,
) {
    val str = LocalStrings.current
    val qFrom = quizConfig?.fromPage ?: page
    val qTo = quizConfig?.toPage ?: page
    val title = when (tool) {
        StudyTool.Vocab -> if (str.isFa) "واژگان صفحه ${page + 1}" else "Vocabulary · page ${page + 1}"
        StudyTool.Grammar -> if (str.isFa) "گرامر صفحه ${page + 1}" else "Grammar · page ${page + 1}"
        StudyTool.Quiz -> {
            val rangeLabel = if (qFrom == qTo) "${qFrom + 1}" else "${qFrom + 1}–${qTo + 1}"
            if (str.isFa) "آزمون صفحات $rangeLabel" else "Quiz · pages $rangeLabel"
        }
        StudyTool.Exercise -> if (str.isFa) "تمرین صفحه ${page + 1}" else "Exercises · page ${page + 1}"
    }

    val initialPhase = if (str.isFa) "در حال بررسی متن صفحه…" else "Checking page text…"
    var phase by remember { mutableStateOf(initialPhase) }
    var body by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var copied by remember { mutableStateOf(false) }
    var reloadTrigger by remember { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000L)
            copied = false
        }
    }

    val cacheKey = buildString {
        append("study_v6|${tool.name}|$docUri|")
        if (tool == StudyTool.Quiz && quizConfig != null) {
            append("${quizConfig.fromPage}-${quizConfig.toPage}|${quizConfig.level}|${quizConfig.count}|${quizConfig.kind}|")
            append(if (str.isFa) "fa|" else "en|")
        } else append("$page|")
        append(settings.handoutLanguage)
    }

    LaunchedEffect(tool, page, quizConfig, reloadTrigger) {
        loading = true
        error = null
        // Clear previous result when regenerating so old quiz/vocab does not linger.
        if (reloadTrigger > 0) body = ""

        // 1. Check local persistent cache to prevent wasting tokens!
        if (reloadTrigger == 0) {
            val cached = withContext(Dispatchers.IO) { dao.cached(cacheKey) }
            if (cached != null && cached.text.isNotBlank()) {
                body = cached.text
                loading = false
                return@LaunchedEffect
            }
        }

        phase = if (str.isFa) "خواندن متن صفحه…" else "Reading page text…"
        try {
            val text = if (tool == StudyTool.Quiz && quizConfig != null && quizConfig.fromPage != quizConfig.toPage) {
                buildString {
                    for (p in quizConfig.fromPage..quizConfig.toPage) {
                        phase = if (str.isFa) "خواندن صفحه ${p + 1}…" else "Reading page ${p + 1}…"
                        var ex = pageText.extract(doc, docUri, p, settings, force = false)
                        if (ex is PT.NoText) ex = pageText.extract(doc, docUri, p, settings, force = true)
                        val t = (ex as? PT.Ok)?.text?.trim().orEmpty()
                        if (t.isNotBlank()) {
                            append("\n\n--- Page ${p + 1} ---\n")
                            append(t)
                        }
                    }
                }.trim()
            } else {
                var ex = pageText.extract(doc, docUri, page, settings, force = false)
                if (ex is PT.NoText) {
                    phase = if (str.isFa) "متن لایه خالی بود؛ OCR…" else "No text layer; running OCR…"
                    ex = pageText.extract(doc, docUri, page, settings, force = true)
                }
                when (ex) {
                    is PT.Ok -> ex.text
                    PT.NoText -> {
                        error = if (str.isFa) "متن این صفحه استخراج نشد." else "Could not extract text from this page."
                        loading = false
                        return@LaunchedEffect
                    }
                    is PT.Fail -> {
                        error = ex.message
                        loading = false
                        return@LaunchedEffect
                    }
                }
            }
            if (text.isBlank()) {
                error = if (str.isFa) "متن این صفحه استخراج نشد." else "Could not extract text from this page."
                loading = false
                return@LaunchedEffect
            }

            phase = if (str.isFa) "در حال پردازش با هوش مصنوعی…" else "Processing with AI…"

            val hasGemini = withContext(Dispatchers.IO) {
                val prov = dao.providers().firstOrNull { it.enabled && it.type == ProviderTypes.GEMINI }
                prov != null && dao.keysFor(prov.id).any { it.status != KeyStatus.INVALID.name && it.status != KeyStatus.DISABLED.name }
            }
            var vocabJpeg: ByteArray? = null
            if (tool == StudyTool.Vocab && hasGemini) {
                vocabJpeg = try {
                    withContext(Dispatchers.IO) {
                        val bmp = doc.render(page, 1200)
                        val out = ByteArrayOutputStream()
                        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
                        bmp.recycle()
                        out.toByteArray()
                    }
                } catch (_: Exception) {
                    null
                }
            }

            val commonRules = """
                قوانین بسیار مهم قالب‌بندی:
                - بدون LaTeX و بدون هیچ علامت $ یا \text.
                - فرمول‌ها و ساختارها را به صورت متن ساده و حتماً داخل بک‌تیک `...` بنویسید (مانند `Subject + Verb + to-infinitive`).
                - به هیچ عنوان از خط افقی --- استفاده نکنید؛ برای بخش‌بندی فقط از هدینگ‌های ## و ### استفاده کنید.
                - از بولد (**) فقط برای اصطلاح کلیدی و مفاهیم مهم استفاده کنید.
                - مثال‌های انگلیسی همان‌گونه دقیقاً به انگلیسی بمانند و همه‌ی توضیح‌ها روان به فارسی (${settings.handoutLanguage}) باشد.
            """.trimIndent()

            val level = quizConfig?.level ?: "medium"
            val count = (quizConfig?.count ?: 6).coerceIn(3, 20)
            val kind = quizConfig?.kind ?: "mc"
            // Normal-mode quiz (from More menu, has quizConfig) follows UI language.
            // Study-mode quiz/exercise stays English for language learners.
            val quizInFa = tool == StudyTool.Quiz && quizConfig != null && str.isFa
            val langRule = if (quizInFa) {
                "LANGUAGE RULE: Write EVERYTHING in natural Persian (Farsi): questions, options, answers, and explanations. Do not mix English into the questions unless a technical term must stay in English."
            } else {
                "LANGUAGE RULE: Write EVERYTHING in English only (questions, options, answers, explanations). No Persian."
            }
            val levelGuide = when (level) {
                "easy" -> "EASY: straightforward recall and basic comprehension."
                "hard" -> "HARD: inference, application, and subtle distinctions."
                else -> "MEDIUM: mix of comprehension and light application."
            }
            val kindGuide = when (kind) {
                "mc" -> "Create ONLY multiple-choice questions."
                "essay" -> "Create ONLY short essay / open-ended questions."
                else -> "Create a MIX: about 60% multiple-choice and 40% essay."
            }

            val prompt = when (tool) {
                StudyTool.Exercise -> """
                    CRITICAL: Do NOT copy long textbook passages. Paraphrase. Use short original examples only.
                    You are an expert tutor solving exercises from this textbook page.
                    LANGUAGE RULE: Write ALL questions, options, and answers in English only. No Persian.

                    Identify exercises on the page. For each item use this exact structure:

                    ### Q1 [ESSAY]
                    <question or exercise prompt in English>
                    **Answer:** <concise correct answer in English>
                    **Explain:** <one short teaching note in English>

                    If the page has no printed exercises, invent 4 comprehension items from the page content.

                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Quiz -> """
                    CRITICAL: Do NOT copy long textbook passages. Paraphrase. Use short original examples only.
                    You are an educational coach. Create a quiz from the PAGE TEXT below.
                    $langRule

                    Difficulty: $levelGuide
                    $kindGuide
                    Create exactly $count questions.

                    STRICT OUTPUT FORMAT (no horizontal rules, no extra commentary):

                    ### Q1 [MC]
                    <question>
                    A) <option>
                    B) <option>
                    C) <option>
                    D) <option>
                    **Answer:** B
                    **Explain:** <one very short reason>

                    ### Q2 [ESSAY]
                    <open-ended question>
                    **Answer:** <sample answer in 2-4 sentences>
                    **Explain:** <optional short tip>

                    Use [MC] or [ESSAY] tags correctly. For MC, Answer must be a single letter A-D.

                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Grammar -> """
                    CRITICAL: Do NOT copy long textbook passages. Paraphrase. Use short original examples only.
                    You are an English language grammar teacher. Analyze the grammar structures, verb tenses, sentence patterns, and syntax rules present on this page.

                    $commonRules

                    ساختار ثابت برای هر مورد:
                    ## ساختار {شماره}: {نام ساختار}
                    - **فرمول:** `{الگو یا فرمول ساختار}`
                    - **کاربرد:** {توضیح کاربرد به زبان ساده}
                    - **مثال‌ها:**
                      - {مثال ۱ استخراج‌شده مستقیم از همین صفحه کتاب}
                      - {مثال ۲}
                    - **اشتباه رایج:** ❌ {عبارت غلط} → ✅ {عبارت درست} ({توضیح کوتاه})

                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Vocab -> if (vocabJpeg != null) {
                    """
                    CRITICAL: Paraphrase examples only. Do not copy long passages.
                    تصویر را ببین: بولد و برجسته‌ها و کادر GLOSSARY اجباری‌اند.
                    You are a vocabulary coach for technical and academic English.
                    Analyze the attached PAGE IMAGE and extract comprehensive vocabulary items up to ~30 entries.

                    MANDATORY PRIORITY:
                    1. First, include ALL headwords/terms from the GLOSSARY / wordlist box on the page.
                    2. Include ALL words and multi-word phrases that are printed in bold, highlighted (yellow/green), or visually emphasized on the page.
                    3. Multi-word phrases, phrasal verbs, idioms, and collocations (such as "set an example", "take the blame") MUST be kept as a single headword entry.
                    4. Fill remaining entries with other high-value, educational terms from the page up to ~30 entries.

                    Output STRICT Markdown for each word/phrase in this exact template:
                    ### Headword
                    - **POS:** noun|verb|adjective|adverb|phrase|idiom
                    - **IPA:** /pronunciation in IPA/
                    - **EN:** short clear English definition
                    - **FA:** Persian definition (روان و طبیعی به فارسی)
                    - **Example:** one short original example sentence in English
                    - **Synonyms:** synonym1 / synonym2
                    - **Antonyms:** antonym1 / antonym2

                    Rules:
                    - Headword line must be plain text after ### (no ** around headword)
                    - Language of field labels stays in English as above so the app can parse cards.
                    - Persian translation goes only in FA field.
                    - Always include IPA when reasonably possible.
                    """.trimIndent()
                } else {
                    """
                    CRITICAL: Paraphrase examples only. Do not copy long passages.
                    You are a vocabulary coach for technical and academic English.
                    From the PAGE TEXT, extract comprehensive vocabulary items up to ~30 entries.

                    MANDATORY PRIORITY:
                    1. First, extract ALL headwords from any GLOSSARY or wordlist box in the text.
                    2. Extract multi-word expressions, phrasal verbs, and collocations (e.g. "set an example", "take the blame") as single entries.
                    3. Extract clear, high-value terms from the page up to ~30 entries.

                    Output STRICT Markdown for each word/phrase in this exact template:
                    ### Headword
                    - **POS:** noun|verb|adjective|adverb|phrase|idiom
                    - **IPA:** /pronunciation in IPA/
                    - **EN:** short clear English definition
                    - **FA:** Persian definition (روان و طبیعی به فارسی)
                    - **Example:** one short original example sentence in English
                    - **Synonyms:** synonym1 / synonym2
                    - **Antonyms:** antonym1 / antonym2

                    Rules:
                    - Headword line must be plain text after ### (no ** around headword)
                    - Language of field labels stays in English as above so the app can parse cards.
                    - Persian translation goes only in FA field.
                    - Always include IPA when reasonably possible.

                    PAGE TEXT:
                    $text
                    """.trimIndent()
                }
            }
            val maxTokens = if (tool == StudyTool.Vocab) 8192 else 4096
            val cap = if (tool == StudyTool.Vocab && vocabJpeg != null) Capability.VISION else Capability.TEXT
            val req = AiRequest(prompt = prompt, imageJpeg = vocabJpeg, task = AiTask.EXPLAIN, maxOutputTokens = maxTokens)
            when (val o = withContext(Dispatchers.IO) {
                router.run(cap, req, settings.preferredModel)
            }) {
                is AiRouter.Outcome.Ok -> {
                    body = o.text
                    // Save to persistent cache so subsequent openings consume ZERO tokens
                    withContext(Dispatchers.IO) {
                        dao.upsertCache(CacheEntity(cacheKey, o.text, o.model, System.currentTimeMillis()))
                    }
                }
                is AiRouter.Outcome.Failed -> {
                    error = when (o.reason) {
                        AiRouter.Reason.NOT_CONFIGURED ->
                            if (str.isFa)
                                "کلید API تنظیم نشده است. از تنظیمات → کلیدهای API یک کلید Gemini اضافه کنید تا حالت مطالعه کار کند."
                            else
                                "No API key configured. Open Settings → API Keys and add a Gemini key so Study Mode can run."
                        AiRouter.Reason.ALL_COOLING_DOWN ->
                            if (str.isFa) "همه مدل‌ها موقتاً در حالت خنک‌سازی هستند. چند لحظه بعد دوباره تلاش کنید."
                            else "All models are cooling down. Try again in a moment."
                        else -> pageText.describe(o, str.isFa)
                    }
                }
            }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        val subtitle = when {
                            quizConfig != null -> if (str.isFa) "آزمون از متن کتاب" else "Quiz from the book"
                            else -> LocalStrings.current.studyModeActive
                        }
                        Text(subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن")
                    }
                },
                actions = {
                    if (body.isNotBlank() && !loading) {
                        FilledTonalButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(body))
                                copied = true
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.padding(end = 4.dp),
                        ) {
                            Text(if (copied) (if (str.isFa) "کپی شد ✓" else "Copied ✓") else (if (str.isFa) "کپی" else "Copy"))
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            when {
                loading -> {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.5.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Column {
                                    Text(phase, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text(if (str.isFa) "پاسخ در حافظه ذخیره می‌شود تا توکن تکراری مصرف نشود." else "Answer is cached to avoid repeated token use.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        // Modern shimmer skeleton while loading
                        AiShimmerSkeleton()
                    }
                }
                error != null -> {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(if (str.isFa) "خطا در پردازش هوش مصنوعی:" else "AI processing error:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                Text(error!!, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = {
                                router.forceClearAllCooldowns()
                                reloadTrigger++
                            }) {
                                Text(if (str.isFa) "تلاش دوباره" else "Retry")
                            }
                            OutlinedButton(onClick = onDismiss) {
                                Text(if (str.isFa) "بستن" else "Close")
                            }
                        }
                    }
                }
                else -> {
                    val isRtlContent = settings.handoutLanguage.startsWith("fa", ignoreCase = true) ||
                        settings.handoutLanguage.contains("Persian", ignoreCase = true) || str.isFa
                    val vocabCards = if (tool == StudyTool.Vocab) parseVocabCards(body) else emptyList()
                    val quizItems = if (tool == StudyTool.Quiz || tool == StudyTool.Exercise) parseQuizItems(body) else emptyList()
                    // UI chrome language for guide labels follows quiz content language.
                    val quizLabelsFa = tool == StudyTool.Quiz && quizConfig != null && str.isFa
                    SelectionContainer {
                        Column(
                            Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState())
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                        ) {
                            when {
                                tool == StudyTool.Vocab && vocabCards.isNotEmpty() ->
                                    vocabCards.forEach { card -> VocabCardView(card, str.isFa) }
                                quizItems.isNotEmpty() -> QuizItemsView(quizItems, quizLabelsFa)
                                else -> AiMarkdownBody(text = body, isRtl = isRtlContent)
                            }
                        }
                    }

                    Surface(
                        tonalElevation = 3.dp,
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.9f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            FilledTonalButton(onClick = { reloadTrigger++ }) {
                                Text(if (str.isFa) "تولید دوباره" else "Regenerate")
                            }
                            if (tool == StudyTool.Vocab && vocabCards.isNotEmpty()) {
                                TextButton(onClick = {
                                    val tsv = buildAnkiTsv(vocabCards)
                                    clipboard.setText(AnnotatedString(tsv))
                                    copied = true
                                }) {
                                    Text(if (str.isFa) "خروجی Anki" else "Export Anki")
                                }
                            }
                            TextButton(onClick = onDismiss) {
                                Text(if (str.isFa) "بستن" else "Close")
                            }
                        }
                    }
                }
            }
        }
    }
}


data class VocabCard(
    val head: String,
    val pos: String,
    val ipa: String,
    val en: String,
    val fa: String,
    val example: String,
    val syn: String,
    val ant: String,
)

fun parseVocabCards(md: String): List<VocabCard> {
    val parts = md.split(Regex("(?m)^###\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
    val out = ArrayList<VocabCard>()
    for ((index, p) in parts.withIndex()) {
        val lines = p.lines()
        if (lines.isEmpty()) continue
        val head = lines.first().trim().trim('`', '*', ' ')
        if (head.length < 2 || head.startsWith("Key") || head.startsWith("Here")) continue
        fun field(key: String): String {
            val re = Regex("(?im)^[-*]\\s*(?:\\*\\*\\s*$key\\s*:?\\s*\\*\\*|\\b$key\\b)\\s*:?\\s*(.+)$")
            return re.find(p)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        }
        val pos = field("POS")
        val ipa = field("IPA").ifBlank { field("Pronunciation") }
        val en = field("EN").ifBlank { field("Meaning") }
        val fa = field("FA")
        val example = field("Example")
        val syn = field("Synonyms")
        val ant = field("Antonyms")

        val isLast = index == parts.lastIndex
        if (isLast && (en.isBlank() || fa.isBlank() || (example.isBlank() && !p.contains("Example", ignoreCase = true)))) {
            continue
        }

        if (head.isNotBlank() && (en.isNotBlank() || fa.isNotBlank())) {
            out += VocabCard(head, pos, ipa, en, fa, example, syn, ant)
        }
    }
    return out
}

private fun buildAnkiTsv(cards: List<VocabCard>): String = buildString {
    appendLine("Front\tBack")
    for (c in cards) {
        val front = c.head.replace("\t", " ").replace("\n", " ")
        val back = listOfNotNull(
            c.ipa.takeIf { it.isNotBlank() },
            c.fa.takeIf { it.isNotBlank() },
            c.en.takeIf { it.isNotBlank() },
            c.pos.takeIf { it.isNotBlank() }?.let { "($it)" },
            c.example.takeIf { it.isNotBlank() }?.let { "e.g. $it" },
        ).joinToString(" · ").replace("\t", " ").replace("\n", " ")
        append(front).append('\t').append(back).append('\n')
    }
}

@Composable
fun VocabCardView(card: VocabCard, isFa: Boolean = false) {
    val context = LocalContext.current
    var tts by remember { mutableStateOf<TextToSpeech?>(null) }
    var faOpen by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        var engine: TextToSpeech? = null
        engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                engine?.language = Locale.US
            }
        }
        tts = engine
        onDispose {
            engine?.stop()
            engine?.shutdown()
        }
    }
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surfaceContainerHigh,
            modifier = Modifier.fillMaxWidth(),
        ) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Text(
                        text = card.head,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Left,
                        modifier = Modifier.weight(1f, fill = false),
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (card.pos.isNotBlank()) {
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primaryContainer,
                                modifier = Modifier.padding(end = 4.dp),
                            ) {
                                Text(
                                    card.pos,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                                )
                            }
                        }
                        IconButton(onClick = {
                            tts?.speak(card.head, TextToSpeech.QUEUE_FLUSH, null, "vocab")
                        }) {
                            Icon(Icons.Default.VolumeUp, contentDescription = "Pronounce")
                        }
                    }
                }

                if (card.ipa.isNotBlank()) {
                    Text(
                        card.ipa,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }

                if (card.en.isNotBlank()) {
                    Text(
                        card.en,
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Left,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                if (card.fa.isNotBlank()) {
                    Column(Modifier.fillMaxWidth()) {
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { faOpen = !faOpen }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            Text(
                                if (isFa) "معنی فارسی" else "Persian meaning",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.tertiary,
                                fontWeight = FontWeight.SemiBold,
                            )
                            Icon(
                                if (faOpen) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.tertiary,
                            )
                        }
                        AnimatedVisibility(visible = faOpen) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                    Text(
                                        text = card.fa,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.Right,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                    )
                                }
                            }
                        }
                    }
                }

                if (card.example.isNotBlank()) {
                    Text(
                        card.example,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Left,
                        modifier = Modifier.fillMaxWidth(),
                    )
                }

                if (card.syn.isNotBlank() || card.ant.isNotBlank()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        if (card.syn.isNotBlank()) {
                            Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
                                Text("≈ ${card.syn}", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                        if (card.ant.isNotBlank()) {
                            Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.errorContainer) {
                                Text("≠ ${card.ant}", Modifier.padding(horizontal = 8.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}

