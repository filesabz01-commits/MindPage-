package app.pdfreader.ai

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ReadingProfile(val label: String, val hint: String) {
    GENERAL("عمومی", ""),
    TECHNICAL("فنی / مهندسی", "Technical text: preserve engineering terms, acronyms, formulas and units. Keep English term in parentheses on first use."),
    ACADEMIC("آکادمیک", "Academic text: keep precise scholarly register, retain citations and references intact."),
    MEDICAL("پزشکی", "Medical text: use accurate terminology; preserve drug names, dosages and units exactly."),
    LITERATURE("ادبیات", "Literary text: favor natural, elegant phrasing and preserve tone."),
    CUSTOM("سفارشی", "");
}

data class ReadingSettings(
    val sourceLanguage: String = "auto",
    val targetLanguage: String = "fa",
    val handoutLanguage: String = "fa",
    val profile: ReadingProfile = ReadingProfile.TECHNICAL,
    val customInstruction: String = "",
    val preferredModel: String = "",
    val preferredTtsModel: String = "",
    val persistOcr: Boolean = true,
    /** "mlkit" (on-device, default) or "gemini" */
    val ocrEngine: String = "auto",
    /** AI may correct locally extracted text; never sends the page image. */
    val aiLocalCorrection: Boolean = false,
    /** Auto OCR minimum composite quality score (0..100). */
    val ocrQualityThreshold: Int = 95,
    /** When true (default), weak/failed local OCR may try online if mode allows. */
    val ocrOnlineFallback: Boolean = true,
    /** Minimum Tesseract mean confidence 0..100; below this counts as weak. */
    val ocrMinConfidence: Int = 55,
    /** off | weak | always — AI text repair after local OCR/layer (shared by all tools) */
    val textRepair: String = "weak",
    /** Optional AI cleanup for native PDF text layer only; OCR path is intentionally excluded. */
    val aiTypedTextCleanup: Boolean = false,
    /** Fully offline deterministic cleanup applied to every extracted page; never calls an API. */
    val localPageCleanup: Boolean = true,
    /** Strip repeated headers/footers / license-only lines before Google Translate */
    val stripHeaders: Boolean = true,
    val googleTranslateBase: String = "https://translate.googleapis.com",
    val translationEngine: String = "google",
    val ttsEngine: String = "edge",
    val edgeVoice: String = "fa-IR-DilaraNeural",
    val ttsFallbackGemini: Boolean = true,
    val bilingual: Boolean = false,
    val voice: String = "Kore",
    val readText: Boolean = false,
    val highlightPdf: Boolean = true,
    val hideFallbackText: Boolean = false,
    val nightMode: Boolean = false,
    val appLanguage: String = "fa",
    val translateMainTextOnly: Boolean = false,
    val studyMode: Boolean = false,
    val pageViewMode: String = "Flip",
)

class SettingsRepo(context: Context) {
    private val prefs = context.getSharedPreferences("reader_settings", Context.MODE_PRIVATE)

    private val _state = MutableStateFlow(
        ReadingSettings(
            sourceLanguage = prefs.getString("source", "auto") ?: "auto",
            targetLanguage = prefs.getString("target", "fa") ?: "fa",
            handoutLanguage = prefs.getString("handout_lang", "fa") ?: "fa",
            profile = runCatching {
                ReadingProfile.valueOf(prefs.getString("profile", ReadingProfile.TECHNICAL.name)!!)
            }.getOrDefault(ReadingProfile.TECHNICAL),
            customInstruction = prefs.getString("custom", "") ?: "",
            preferredModel = prefs.getString("model", "") ?: "",
            preferredTtsModel = prefs.getString("preferred_tts_model", "") ?: "",
            persistOcr = prefs.getBoolean("persist_ocr", true),
            ocrOnlineFallback = prefs.getBoolean("ocr_online_fallback", true),
            aiLocalCorrection = prefs.getBoolean("ai_local_correction", false),
            ocrQualityThreshold = prefs.getInt("ocr_quality_threshold", 95).coerceIn(0, 100),
            ocrMinConfidence = prefs.getInt("ocr_min_confidence", 55).coerceIn(0, 100),
            aiTypedTextCleanup = prefs.getBoolean("ai_typed_text_cleanup", false),
            localPageCleanup = prefs.getBoolean("local_page_cleanup", true),
            textRepair = when (prefs.getString("text_repair", "weak")) {
                "always", "on" -> "always"
                "off", "never" -> "off"
                else -> "weak"
            },
            ocrEngine = when (prefs.getString("ocr_engine", "auto")) {
                "ai", "ai_ocr", "gemini", "online" -> "ai"
                "local", "local_only", "local_fa", "fa", "local_en", "en", "mlkit" -> "local"
                else -> "auto"
            },
            stripHeaders = prefs.getBoolean("strip_headers", true),
            googleTranslateBase = prefs.getString("gt_base", "https://translate.googleapis.com") ?: "https://translate.googleapis.com",
            translationEngine = prefs.getString("translation_engine", "google") ?: "google",
            ttsEngine = (prefs.getString("tts_engine", "edge") ?: "edge").let { if (it == "system") "edge" else it },
            edgeVoice = prefs.getString("edge_voice", "fa-IR-DilaraNeural") ?: "fa-IR-DilaraNeural",
            ttsFallbackGemini = prefs.getBoolean("tts_fallback_gemini", true),
            bilingual = prefs.getBoolean("bilingual", false),
            voice = prefs.getString("voice", "Kore") ?: "Kore",
            readText = prefs.getBoolean("read_text_v2", false),
            highlightPdf = prefs.getBoolean("highlight_pdf", true),
            hideFallbackText = prefs.getBoolean("hide_fallback_text", false),
            nightMode = prefs.getBoolean("night_mode", false),
            appLanguage = prefs.getString("app_language", "fa") ?: "fa",
            translateMainTextOnly = prefs.getBoolean("translate_main_text_only", false),
            studyMode = prefs.getBoolean("study_mode", false),
            pageViewMode = prefs.getString("page_view_mode", "Flip") ?: "Flip",
        )
    )

    val state: StateFlow<ReadingSettings> = _state.asStateFlow()

    fun update(transform: (ReadingSettings) -> ReadingSettings) {
        val s = transform(_state.value)
        _state.value = s
        prefs.edit()
            .putString("source", s.sourceLanguage)
            .putString("target", s.targetLanguage)
            .putString("handout_lang", s.handoutLanguage)
            .putString("profile", s.profile.name)
            .putString("custom", s.customInstruction)
            .putString("model", s.preferredModel)
            .putString("preferred_tts_model", s.preferredTtsModel)
            .putBoolean("persist_ocr", s.persistOcr)
            .putString("ocr_engine", s.ocrEngine)
            .putBoolean("ai_local_correction", s.aiLocalCorrection)
            .putInt("ocr_quality_threshold", s.ocrQualityThreshold)
            .putBoolean("ocr_online_fallback", s.ocrOnlineFallback)
            .putInt("ocr_min_confidence", s.ocrMinConfidence)
            .putString("text_repair", s.textRepair)
            .putBoolean("ai_typed_text_cleanup", s.aiTypedTextCleanup)
            .putBoolean("local_page_cleanup", s.localPageCleanup)
            .putBoolean("strip_headers", s.stripHeaders)
            .putString("gt_base", s.googleTranslateBase)
            .putString("translation_engine", s.translationEngine)
            .putString("tts_engine", s.ttsEngine)
            .putString("edge_voice", s.edgeVoice)
            .putBoolean("tts_fallback_gemini", s.ttsFallbackGemini)
            .putBoolean("bilingual", s.bilingual)
            .putString("voice", s.voice)
            .putBoolean("read_text_v2", s.readText)
            .putBoolean("highlight_pdf", s.highlightPdf)
            .putBoolean("hide_fallback_text", s.hideFallbackText)
            .putBoolean("night_mode", s.nightMode)
            .putString("app_language", s.appLanguage)
            .putBoolean("translate_main_text_only", s.translateMainTextOnly)
            .putBoolean("study_mode", s.studyMode)
            .putString("page_view_mode", s.pageViewMode)
            .apply()
    }

    fun seedVersion(): Int = prefs.getInt("seed_version", 0)
    fun setSeedVersion(v: Int) { prefs.edit().putInt("seed_version", v).apply() }
}