package app.pdfreader.ui

import app.pdfreader.ui.l10n.LocalStrings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pdfreader.ai.AiDao
import app.pdfreader.ai.AiRequest
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.CacheEntity
import app.pdfreader.ai.Capability
import app.pdfreader.ai.PT
import app.pdfreader.ai.PageTextService
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class StudyTool { Vocab, Grammar, Quiz, Exercise }

/**
 * Full-screen Study Mode tool screen.
 * Reuses extract/OCR cache via [PageTextService] and caches AI responses in [AiDao]
 * so subsequent opens use 0 extra tokens and display instantly.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudyToolScreen(
    tool: StudyTool,
    doc: PdfDocument,
    docUri: String,
    page: Int,
    settings: ReadingSettings,
    pageText: PageTextService,
    router: AiRouter,
    dao: AiDao,
    onDismiss: () -> Unit,
) {
    val str = LocalStrings.current
    val title = when (tool) {
        StudyTool.Vocab -> if (str.isFa) "واژگان صفحه ${page + 1}" else "Vocabulary · page ${page + 1}"
        StudyTool.Grammar -> if (str.isFa) "گرامر صفحه ${page + 1}" else "Grammar · page ${page + 1}"
        StudyTool.Quiz -> if (str.isFa) "آزمون صفحه ${page + 1}" else "Quiz · page ${page + 1}"
        StudyTool.Exercise -> if (str.isFa) "تمرین صفحه ${page + 1}" else "Exercises · page ${page + 1}"
    }

    val initialPhase = if (str.isFa) "در حال بررسی متن صفحه…" else "Checking page text…"
    var phase by remember { mutableStateOf(initialPhase) }
    var body by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var copied by remember { mutableStateOf(false) }
    var reloadTrigger by remember { mutableStateOf(0) }
    val clipboard = LocalClipboardManager.current

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000L)
            copied = false
        }
    }

    val cacheKey = "study_v2|${tool.name}|$docUri|$page|${settings.handoutLanguage}"

    LaunchedEffect(tool, page, reloadTrigger) {
        loading = true
        error = null

        // 1. Check local persistent cache to prevent wasting tokens!
        if (reloadTrigger == 0) {
            val cached = withContext(Dispatchers.IO) { dao.cached(cacheKey) }
            if (cached != null && cached.text.isNotBlank()) {
                body = cached.text
                loading = false
                return@LaunchedEffect
            }
        }

        phase = if (str.isFa) "خواندن متن صفحه…" else "Reading page text…"
        try {
            var ex = pageText.extract(doc, docUri, page, settings, force = false)
            if (ex is PT.NoText) {
                phase = if (str.isFa) "متن لایه خالی بود؛ OCR…" else "No text layer; running OCR…"
                ex = pageText.extract(doc, docUri, page, settings, force = true)
            }
            val text = when (ex) {
                is PT.Ok -> ex.text
                PT.NoText -> {
                    error = if (str.isFa) "متن این صفحه استخراج نشد." else "Could not extract text from this page."
                    loading = false
                    return@LaunchedEffect
                }
                is PT.Fail -> {
                    error = ex.message
                    loading = false
                    return@LaunchedEffect
                }
            }

            phase = if (str.isFa) "در حال پردازش با هوش مصنوعی…" else "Processing with AI…"

            val prompt = when (tool) {
                StudyTool.Exercise -> """
                    You are an expert tutor solving exercises directly from this textbook page.
                    Analyze the PAGE TEXT carefully and identify ALL exercises, drills, fill-in-the-blanks, matching, and questions printed on this page.
                    
                    For each exercise found on this page:
                    - Write the Exercise title/number clearly (e.g. ## تمرین ۱: عنوان تمرین در کتاب)
                    - List every question or sentence from the book.
                    - Provide the exact correct answer in bold: **پاسخ:** ...
                    - Provide a clear, educational Persian explanation explaining the grammatical/lexical reason.
                    
                    If this page does NOT contain exercises, create 4 comprehensive comprehension exercises testing the key concepts taught on this page, then provide step-by-step solutions with explanations.
                    Language: Reply in Persian (${settings.handoutLanguage}) Markdown.
                    
                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Quiz -> """
                    You are an educational coach preparing a high-yield multiple-choice test directly from the questions and content of this textbook page.
                    
                    Instructions:
                    1. Base every question on the vocabulary, grammar, and exercises printed on this page.
                    2. Create 6 to 8 four-option multiple choice questions (الف، ب، ج، د).
                    3. Format in clean Persian (${settings.handoutLanguage}) Markdown:
                       ## آزمون چهارگزینه‌ای صفحه
                       ### سوال ۱. ...
                       الف) ...
                       ب) ...
                       ج) ...
                       د) ...
                       
                       ---
                       ## پاسخ‌نامه و تحلیل تشریحی
                       - **سوال ۱: گزینه (...)** - دلیل انتخاب این پاسخ به زبان ساده.
                    
                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Vocab -> """
                    You are a professional vocabulary tutor. From the PAGE TEXT, extract all important, lesson-relevant words, idioms, phrasal verbs, and technical terms.
                    Skip common trivial words (like the, is, at).
                    
                    Format in Persian (${settings.handoutLanguage}) Markdown:
                    ## واژگان و اصطلاحات کلیدی
                    For each word:
                    - **کلمه / اصطلاح** [تلفظ صوتی/فونتیک]
                      - **معنی روان:** ...
                      - **نقش دستوری:** (اسم / فعل / صفت / اصطلاح)
                      - **جمله نمونه از متن:** ...
                      - **مترادف و متضاد:** ...
                    
                    PAGE TEXT:
                    $text
                """.trimIndent()

                StudyTool.Grammar -> """
                    You are an English language grammar teacher. Analyze the grammar structures, verb tenses, sentence patterns, and syntax rules present on this page.
                    
                    Format in Persian (${settings.handoutLanguage}) Markdown:
                    ## نکات و ساختارهای گرامری این صفحه
                    Explain each structure clearly with:
                    - **فرمول و الگوی گرامری**
                    - **توضیح کاربرد به زبان ساده**
                    - **مثال‌های استخراج‌شده مستقیم از همین صفحه کتاب**
                    - **اشتباهات رایج زبان‌آموزان**
                    
                    PAGE TEXT:
                    $text
                """.trimIndent()
            }

            val req = AiRequest(prompt = prompt, task = AiTask.EXPLAIN, maxOutputTokens = 4096)
            when (val o = withContext(Dispatchers.IO) {
                router.run(Capability.TEXT, req, settings.preferredModel)
            }) {
                is AiRouter.Outcome.Ok -> {
                    body = o.text
                    // Save to persistent cache so subsequent openings consume ZERO tokens
                    withContext(Dispatchers.IO) {
                        dao.upsertCache(CacheEntity(cacheKey, o.text, o.model, System.currentTimeMillis()))
                    }
                }
                is AiRouter.Outcome.Failed -> {
                    error = when (o.reason) {
                        AiRouter.Reason.NOT_CONFIGURED ->
                            if (str.isFa)
                                "کلید API تنظیم نشده است. از تنظیمات → کلیدهای API یک کلید Gemini اضافه کنید تا حالت مطالعه کار کند."
                            else
                                "No API key configured. Open Settings → API Keys and add a Gemini key so Study Mode can run."
                        AiRouter.Reason.ALL_COOLING_DOWN ->
                            if (str.isFa) "همه مدل‌ها موقتاً در حالت خنک‌سازی هستند. چند لحظه بعد دوباره تلاش کنید."
                            else "All models are cooling down. Try again in a moment."
                        else -> pageText.describe(o)
                    }
                }
            }
        } catch (e: Exception) {
            error = e.message ?: e.javaClass.simpleName
        } finally {
            loading = false
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                        Text(LocalStrings.current.studyModeActive, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "بستن")
                    }
                },
                actions = {
                    if (body.isNotBlank() && !loading) {
                        FilledTonalButton(
                            onClick = {
                                clipboard.setText(AnnotatedString(body))
                                copied = true
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.padding(end = 4.dp),
                        ) {
                            Text(if (copied) "کپی شد ✓" else "کپی")
                        }
                    }
                },
            )
        },
    ) { pad ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(pad)
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp),
        ) {
            when {
                loading -> {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(16.dp),
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp),
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    strokeWidth = 2.5.dp,
                                    color = MaterialTheme.colorScheme.primary,
                                )
                                Column {
                                    Text(phase, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("پاسخ به طور خودکار در حافظه ذخیره می‌شود تا توکن تکراری مصرف نشود.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }

                        // Modern shimmer skeleton while loading
                        AiShimmerSkeleton()
                    }
                }
                error != null -> {
                    Column(
                        Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Surface(
                            shape = RoundedCornerShape(16.dp),
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("خطا در پردازش هوش مصنوعی:", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.error)
                                Text(error!!, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onErrorContainer)
                            }
                        }
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = {
                                router.forceClearAllCooldowns()
                                reloadTrigger++
                            }) {
                                Text("تلاش دوباره")
                            }
                            OutlinedButton(onClick = onDismiss) {
                                Text("بستن")
                            }
                        }
                    }
                }
                else -> {
                    SelectionContainer {
                        Column(
                            Modifier
                                .weight(1f)
                                .verticalScroll(rememberScrollState()),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            AiMarkdownBody(text = body, isRtl = true)
                        }
                    }

                    // Bottom bar with re-generate and dismiss
                    Surface(
                        tonalElevation = 3.dp,
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.9f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp),
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            TextButton(onClick = { reloadTrigger++ }) {
                                Text("تولید دوباره (تازه)")
                            }
                            TextButton(onClick = onDismiss) {
                                Text("بستن")
                            }
                        }
                    }
                }
            }
        }
    }
}
