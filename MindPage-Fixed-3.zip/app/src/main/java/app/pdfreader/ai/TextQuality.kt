package app.pdfreader.ai

enum class PageTextKind {
    CLEAN,
    NONE,
    GARBLED,
}

class TextVerdict(val kind: PageTextKind, val reason: String)

object TextQuality {
    private val VOWELS = "aeiouyAEIOUYàáâãäåæèéêëìíîïòóôõöøùúûüýÿœ"

    private fun isArabicScript(c: Char) =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isPresentationForm(c: Char) = c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isLatin(c: Char) = c in 'A'..'Z' || c in 'a'..'z' || c in '\u00C0'..'\u024F'

    fun assess(raw: String): TextVerdict {
        var visible = 0
        var broken = 0
        var letters = 0
        var latin = 0
        var arabic = 0
        var shaped = 0
        var otherLetters = 0
        var symbols = 0
        for (c in raw) {
            if (c.isWhitespace()) continue
            visible++
            when {
                c == '\uFFFD' || c in '\uE000'..'\uF8FF' || c in '\u0080'..'\u009F' || (c.code < 32) -> broken++
                isArabicScript(c) -> { letters++; arabic++; if (isPresentationForm(c)) shaped++ }
                isLatin(c) -> { letters++; latin++ }
                c.isLetter() -> { letters++; otherLetters++ }
                c.isDigit() -> {}
                Character.getType(c).let {
                    it == Character.OTHER_SYMBOL.toInt() || it == Character.MODIFIER_SYMBOL.toInt() || it == Character.SURROGATE.toInt()
                } -> symbols++
            }
        }
        broken += Regex("\\(cid:\\d+\\)").findAll(raw).count() * 6
        if (visible < 40) return TextVerdict(PageTextKind.NONE, "لایه‌ی متنی ندارد")
        if (broken * 100 > visible * 3) return TextVerdict(PageTextKind.GARBLED, "کاراکترهای نامعتبر")
        if (symbols * 100 > visible * 20) return TextVerdict(PageTextKind.GARBLED, "نمادهای بی‌معنی")

        val tokens = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size >= 12) {
            val single = tokens.count { it.length == 1 && it[0].isLetter() }
            if (single * 100 > tokens.size * 45) return TextVerdict(PageTextKind.GARBLED, "حرف‌های جدا از هم")
            val avg = tokens.sumOf { it.length } / tokens.size
            if (avg > 25) return TextVerdict(PageTextKind.GARBLED, "کلمات چسبیده")
        }
        if (letters > 0 && otherLetters * 100 > letters * 30) return TextVerdict(PageTextKind.GARBLED, "ترکیب نامعمول نوشتارها")
        if (arabic > latin) {
            if (arabic > 0 && shaped * 100 > arabic * 35) return TextVerdict(PageTextKind.GARBLED, "حروف شکل‌یافته/وارونه")
        } else if (latin > 0) {
            val words = tokens.map { w -> w.filter { it.isLetter() } }.filter { it.length >= 3 && !it.all { ch -> ch.isUpperCase() } }
            if (words.size >= 15) {
                val noVowel = words.count { w -> w.none { it in VOWELS } }
                if (noVowel * 100 > words.size * 50) return TextVerdict(PageTextKind.GARBLED, "کلمات بدون واکه (رمزگذاری خراب)")
            }
        }
        return TextVerdict(PageTextKind.CLEAN, "")
    }

    private val pageNumber = Regex("^(page\\s*)?([0-9\u06F0-\u06F9\u0660-\u0669]{1,4}|[ivxlcdm]+)$", RegexOption.IGNORE_CASE)
    private val inddStamp = Regex(".*\\.(indd|idml|ai|psd|qxd)\\s+\\d+.*", RegexOption.IGNORE_CASE)
    private val publisherFooter = Regex(
        "^(downloaded from|wiley online library|see the terms and conditions|terms and conditions|" +
            "all rights reserved|creative commons license|published by|doi:\\s*10\\.|oa articles are governed).*",
        RegexOption.IGNORE_CASE
    )
    private val copyrightLine = Regex(
        ".*(all rights reserved|john wiley\\s*&\\s*sons|companion website|www\\.wiley\\.com|" +
            "text and data mining and training of artificial intelligence|published \\d{4} by|" +
            "©\\s*\\d{4}|copyright\\s*©|rights for text and data mining).*",
        RegexOption.IGNORE_CASE
    )
    private val publisherUrl = Regex(".*(onlinelibrary\\.wiley\\.com|sciencedirect\\.com|springerlink\\.com|tandfonline\\.com|wiley\\.com/go/).*", RegexOption.IGNORE_CASE)
    private val tableCaption = Regex(
        "^table\\s+\\d+(\\.\\d+)?\\.?(\\s+[^.]{1,80})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val shortTableCell = Regex(
        "^(intention|color used|addition|deletion|comment|dark gray|gray|black|white|red|blue|green|" +
            "yes|no|n/?a|optional|required|must|preferred)\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val runningHeader = Regex(
        "^([ivxlcdm]+|[0-9]{1,4})\\s*[|•\\-–—]\\s*.+$|" +
            "^.+[|•\\-–—]\\s*([ivxlcdm]+|[0-9]{1,4})$|" +
            "^\\d{1,3}\\s*\\|\\s*.+$|^.+\\|\\s*\\d{1,3}$",
        RegexOption.IGNORE_CASE
    )
    private val sectionTitleWithPage = Regex("^\\d+(\\.\\d+)+\\s+.{8,70}\\s+\\d{1,3}$")
    private val figureCaption = Regex(
        "^(figure|fig\\.?|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?(\\s+[^.]{1,90})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val legalStamp = Regex(
        ".*(this document was prepared exclusively|permit to practice|permit number|engineer and permit stamps|" +
            "subjects to the terms and conditions|legal terms|signature:\\s*-+|date:\\s*-+).*",
        RegexOption.IGNORE_CASE
    )
    private val romanHeader = Regex(
        "^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|index|foreword|chapter|section).*$",
        RegexOption.IGNORE_CASE
    )
    private val shortSectionTitle = Regex(
        "^(preface|contents|introduction|acknowledgment|acknowledgements|foreword|index|abstract|summary)$",
        RegexOption.IGNORE_CASE
    )
    private val diagramFormula = Regex(".*\\b(sizing|specification|development|p&id)\\b.*[+=].*", RegexOption.IGNORE_CASE)

    private val DIAGRAM_LABELS = setOf(
        "process", "control", "operation", "equipment & instruments", "equipment and instruments",
        "location", "regulations: hse", "regulations", "hse", "maintenance",
        "supporting plants", "calculation", "technical", "not technical",
        "p&id development", "sizing or specification", "p&id", "sizing",
        "p&id development guidelines", "p&id demonstration rules", "p&id drafting rules",
        "development guidelines", "demonstration rules", "drafting rules",
        "where should i put this valve?", "what is its symbol?", "what should be the thickness of this symbol?",
        "calculations", "loop diagram", "alarm table", "piping ds", "piping model", "isometrics",
        "mechanical ds", "plant modeling", "as a reference in plant during operation", "loop diagrams",
    )

    private fun isCaptionOnly(line: String): Boolean {
        val t = line.trim()
        if (t.length > 110) return false
        if (!Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        if (Regex(
                "\\b(outlines?|shows?|showed|showing|describes?|summarizes?|lists?|presents?|provides?|indicates?|explains?)\\b",
                RegexOption.IGNORE_CASE
            ).containsMatchIn(t)
        ) return false
        return figureCaption.matches(t) || tableCaption.matches(t) ||
            Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?\\s*.{0,90}$", RegexOption.IGNORE_CASE).matches(t)
    }

    fun isJunkOrDiagram(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return true
        if (Regex("^\\d{1,2}\\.\\s+\\S.+").matches(trimmed)) return false
        if (Regex("^\\d+(\\.\\d+)+\\s+\\S.+").matches(trimmed)) {
            if (sectionTitleWithPage.matches(trimmed)) return true
            return false
        }
        if (pageNumber.matches(trimmed)) return true
        if (inddStamp.matches(trimmed)) return true
        if (publisherFooter.matches(trimmed)) return true
        if (copyrightLine.matches(trimmed)) return true
        if (publisherUrl.matches(trimmed)) return true
        if (runningHeader.matches(trimmed)) return true
        if (sectionTitleWithPage.matches(trimmed)) return true
        if (romanHeader.matches(trimmed)) return true
        if (shortSectionTitle.matches(trimmed)) return true
        if (legalStamp.matches(trimmed)) return true
        if (diagramFormula.matches(trimmed)) return true
        if (isCaptionOnly(trimmed)) return true
        if (shortTableCell.matches(trimmed)) return true
        val lower = trimmed.lowercase().removeSuffix(".").trim()
        if (lower in DIAGRAM_LABELS) return true
        if (trimmed in listOf("+", "=", "==", "->", "-->", "|", "—", "–")) return true
        if (trimmed.length < 40 && Regex("^[ivxlcdm]+\\s*[|•\\-–—:. ]*(preface|contents|intro|chapter|section)?$", RegexOption.IGNORE_CASE).matches(trimmed)) return true
        if (trimmed.length <= 24 && lower in setOf(
                "dark gray", "light gray", "gray", "black", "white", "red", "blue", "green",
                "addition", "deletion", "comment", "intention", "color used", "mark up", "markup"
            )) return true
        val words = trimmed.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.size in 2..8 && (trimmed.endsWith("?") || lower.contains("p&id"))) {
            if (lower.contains("guideline") || lower.contains("rule") || lower.contains("valve") ||
                lower.contains("symbol") || lower.contains("thickness") || lower.contains("where should") ||
                lower.contains("what is") || lower.contains("what should")) return true
        }
        return false
    }

    fun looksLikeTableRow(line: String): Boolean {
        val t = line.trim()
        if (t.startsWith("|") && t.indexOf('|', startIndex = 1) >= 0) return true
        if (t.contains('|') && t.split('|').size >= 3) return true
        if (t.contains('\t')) {
            if (t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }.size >= 2) return true
        }
        val cells = splitColumns(t)
        if (cells.size >= 2 && cells.count { it.length <= 48 } >= 2) return true
        return false
    }

    fun promoteTables(raw: String): String {
        // Already-markdown tables (from geometry extraction) pass through untouched.
        if (raw.lines().count { it.trim().startsWith("|") && it.indexOf('|', startIndex = 1) >= 0 } >= 3) return raw

        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<String>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            // Caption-anchored table: "Table 4.4 ..." then short/aligned rows until long prose.
            if (line.trim().matches(Regex("""^(Table|TABLE|جدول)\s*\d.*"""))) {
                out += line
                i++
                val block = ArrayList<List<String>>()
                while (i < lines.size) {
                    val L = lines[i]
                    if (L.isBlank()) {
                        i++
                        if (block.size >= 2) break else continue
                    }
                    if (isNarrativeSentence(L) && L.split(Regex("\\s+")).size > 12) break
                    if (L.trim().matches(Regex("""^\d+(\.\d+)+\s+\S+.*"""))) break
                    val c = splitColumns(L)
                    if (c.size >= 2) block += c
                    else if (L.length <= 60 && block.isNotEmpty()) block += listOf(L.trim())
                    else if (block.isEmpty()) {
                        out += L
                        i++
                        continue
                    } else break
                    i++
                }
                if (block.size >= 2) {
                    val cols = block.maxOf { it.size }.coerceAtLeast(2)
                    val norm = block.map { r -> List(cols) { k -> r.getOrElse(k) { "" }.trim() } }
                    out += "| " + norm[0].joinToString(" | ") + " |"
                    out += "| " + List(cols) { "---" }.joinToString(" | ") + " |"
                    for (r in norm.drop(1)) out += "| " + r.joinToString(" | ") + " |"
                    out += ""
                }
                continue
            }

            val cells = splitColumns(line)
            if (cells.size >= 2 && cells.all { it.length <= 80 } && !isNarrativeSentence(line)) {
                val block = ArrayList<List<String>>()
                var j = i
                while (j < lines.size) {
                    val c = splitColumns(lines[j])
                    if (c.size >= 2 && c.all { it.length <= 80 } && !isNarrativeSentence(lines[j])) {
                        block += c
                        j++
                    } else if (lines[j].isBlank() && j + 1 < lines.size && splitColumns(lines[j + 1]).size >= 2) {
                        j++
                    } else break
                }
                if (block.size >= 2) {
                    val cols = block.maxOf { it.size }
                    val norm = block.map { r -> List(cols) { k -> r.getOrElse(k) { "" }.trim() } }
                    out += "| " + norm[0].joinToString(" | ") + " |"
                    out += "| " + List(cols) { "---" }.joinToString(" | ") + " |"
                    for (r in norm.drop(1)) {
                        out += "| " + r.joinToString(" | ") + " |"
                    }
                    out += ""
                    i = j
                    continue
                }
            }
            out += line
            i++
        }
        return out.joinToString("\n")
    }

    private fun isNarrativeSentence(line: String): Boolean {
        val t = line.trim()
        if (t.contains('|')) return false
        if (t.endsWith(".") && t.split(Regex("\\s+")).size > 8) return true
        return false
    }

    fun splitColumns(line: String): List<String> {
        val t = line.trim()
        if (t.isEmpty()) return emptyList()
        if (t.contains('|')) {
            return t.split('|').map { it.trim() }.filter { it.isNotEmpty() && !it.matches(Regex("^:?-+:?$")) }
        }
        if (t.contains('\t')) {
            val parts = t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size >= 2) return parts
        }
        val multi = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (multi.size >= 2) return multi

        val pvuRegex = Regex("""^([A-Za-z\u0600-\u06FF\s]{2,25})\s+([\d\.\+\-×x\^]+)\s*([A-Za-z°µ%Ω\u0600-\u06FF\/\^0-9]{1,12})$""")
        val m = pvuRegex.matchEntire(t)
        if (m != null) {
            return listOf(m.groupValues[1].trim(), m.groupValues[2].trim(), m.groupValues[3].trim())
        }

        if (t.contains(':')) {
            val parts = t.split(':').map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size == 2 && parts[0].length <= 30) return parts
        }

        // Do NOT split ordinary prose / labels into fake table cells.
        // Only treat as multi-column when there is clear alignment (tabs / 2+ spaces / pipes)
        // or a parameter-value-unit pattern above. Aggressive single-space splits destroy
        // Persian and English sentences and equipment callouts.
        return listOf(t)
    }

    fun localClean(raw: String): String {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim() }
        val paragraphs = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) paragraphs += cur.toString().trim(); cur.clear() }
        for (l in lines) {
            if (l.isEmpty()) { flush(); prev = ""; continue }
            if (isJunkOrDiagram(l)) continue
            if (looksLikeTableRow(l) || (l.startsWith("|") && l.contains('|'))) {
                flush()
                paragraphs += l
                prev = ""
                continue
            }
            if (cur.isEmpty()) { cur.append(l); prev = l; continue }
            val endsHyphen = prev.endsWith("-") || prev.endsWith("\u00AD")
            val endsSentence = prev.last() in ".!?\u061F:\u2026"
            when {
                endsHyphen && l.first().isLowerCase() -> { cur.setLength(cur.length - 1); cur.append(l) }
                endsSentence && (l.first().isUpperCase() || l.first() in '\u0600'..'\u06FF' || l.first() in "«\"“‘'[") -> {
                    if (prev.length < 50) {
                        flush()
                        cur.append(l)
                    } else {
                        cur.append(' ').append(l)
                    }
                }
                else -> cur.append(' ').append(l)
            }
            prev = l
        }
        flush()
        if (paragraphs.isNotEmpty()) {
            val first = paragraphs[0]
            val cleanedFirst = first
                .replace(Regex("^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|foreword)?\\s*", RegexOption.IGNORE_CASE), "")
                .trim()
            if (cleanedFirst != first) {
                if (cleanedFirst.isBlank()) paragraphs.removeAt(0)
                else paragraphs[0] = cleanedFirst
            }
        }
        paragraphs.removeAll { p ->
            copyrightLine.matches(p) || publisherFooter.matches(p) || publisherUrl.matches(p) ||
                (p.length > 80 && p.contains("All rights reserved", ignoreCase = true) && p.contains("Wiley", ignoreCase = true))
        }
        return paragraphs.joinToString("\n\n")
    }
}