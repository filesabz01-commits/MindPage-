package app.pdfreader.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Google Translate (unofficial free endpoint) with structure-aware handling:
 * - Paragraphs translated in chunks
 * - Tables: prefer one request for the whole markdown table when small enough;
 *   otherwise translate row-by-row (not cell-by-cell) to keep latency low.
 */
object GoogleTranslateService {

    private val keepAsIs = Regex(
        """^(?:[A-Z]{1,4}[\-\s]?\d{1,4}[A-Z]?(?:/[A-Z])?|[\d\.\,\+\-\u00D7x×\^\/\s]+(?:[A-Za-z°µ%Ω\/0-9]{0,12})?|[A-Z]{1,6}\.?|N/?A)$""",
        RegexOption.IGNORE_CASE,
    )

    suspend fun translate(text: String, sourceLang: String = "auto", targetLang: String = "fa"): String =
        withContext(Dispatchers.IO) {
            val cleaned = TextQuality.localClean(text).ifBlank { text.trim() }
            if (cleaned.isBlank()) return@withContext ""
            val structured = TextQuality.promoteTables(cleaned)
            val normalized = coalesceTableLines(structured)
            val blocks = splitBlocks(normalized)
            val out = ArrayList<String>(blocks.size)
            for (b in blocks) {
                when (b) {
                    is Block.Para -> {
                        val t = b.text.trim()
                        if (t.isNotEmpty()) out += translateParagraph(t, sourceLang, targetLang)
                        else out += ""
                    }
                    is Block.Table -> out += translateTable(b.rows, sourceLang, targetLang)
                }
            }
            out.joinToString("\n\n").trim()
        }

    private fun translateParagraph(text: String, sl: String, tl: String): String {
        if (text.length <= 2500) return translateChunk(text, sl, tl)
        val sentences = text.split(Regex("(?<=[.!?\\n])\\s+"))
        val chunk = StringBuilder()
        val parts = mutableListOf<String>()
        for (s in sentences) {
            if (chunk.length + s.length > 2000 && chunk.isNotEmpty()) {
                parts += translateChunk(chunk.toString(), sl, tl)
                chunk.clear()
            }
            if (chunk.isNotEmpty()) chunk.append(' ')
            chunk.append(s)
        }
        if (chunk.isNotEmpty()) parts += translateChunk(chunk.toString(), sl, tl)
        return parts.joinToString(" ")
    }

    /**
     * Prefer a single network call for the entire markdown table when it fits.
     * Fall back to row-wise translation (still far fewer calls than cell-wise).
     */
    private suspend fun translateTable(rows: List<List<String>>, sl: String, tl: String): String {
        if (rows.isEmpty()) return ""
        val colCount = rows.maxOf { it.size }.coerceAtLeast(1)
        val asMd = buildString {
            rows.forEachIndexed { i, row ->
                val cells = List(colCount) { c -> row.getOrElse(c) { "" }.trim() }
                append("| ").append(cells.joinToString(" | ")).append(" |\n")
                if (i == 0) append("| ").append(List(colCount) { "---" }.joinToString(" | ")).append(" |\n")
            }
        }.trimEnd()

        // Fast path: one request for whole table
        if (asMd.length <= 2200) {
            val translated = translateChunk(asMd, sl, tl)
            if (translated.count { it == '|' } >= asMd.count { it == '|' } / 2) {
                return translated.trim()
            }
        }

        // Row-wise with limited parallelism
        return coroutineScope {
            val sem = Semaphore(4)
            val jobs = rows.mapIndexed { index, row ->
                async {
                    sem.withPermit {
                        val cells = List(colCount) { c ->
                            val cell = row.getOrElse(c) { "" }.trim()
                            when {
                                cell.isEmpty() -> ""
                                keepAsIs.matches(cell) -> cell
                                cell.length <= 2 -> cell
                                else -> translateChunk(cell, sl, tl).replace("|", "/").trim()
                            }
                        }
                        index to cells
                    }
                }
            }
            val translatedRows = jobs.awaitAll().sortedBy { it.first }.map { it.second }
            buildString {
                translatedRows.forEachIndexed { i, row ->
                    append("| ").append(row.joinToString(" | ")).append(" |\n")
                    if (i == 0) append("| ").append(List(colCount) { "---" }.joinToString(" | ")).append(" |\n")
                }
            }.trimEnd()
        }
    }

    private fun coalesceTableLines(text: String): String {
        val paras = text.split(Regex("\\n\\s*\\n"))
        val out = mutableListOf<String>()
        val buf = mutableListOf<String>()
        fun flushBuf() {
            if (buf.isEmpty()) return
            out += if (buf.size >= 2) buf.joinToString("\n") else buf[0]
            buf.clear()
        }
        for (p in paras) {
            val lines = p.trim().split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            val allTable = lines.isNotEmpty() && lines.all { TextQuality.looksLikeTableRow(it) || it.startsWith("|") }
            if (allTable) buf.addAll(lines)
            else {
                flushBuf()
                out += p.trim()
            }
        }
        flushBuf()
        return out.filter { it.isNotBlank() }.joinToString("\n\n")
    }

    private sealed class Block {
        data class Para(val text: String) : Block()
        data class Table(val rows: List<List<String>>) : Block()
    }

    private fun splitBlocks(text: String): List<Block> {
        val lines = text.replace("\r\n", "\n").split('\n')
        val blocks = mutableListOf<Block>()
        val para = StringBuilder()
        val tableRows = mutableListOf<List<String>>()

        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) blocks += Block.Para(t)
            para.clear()
        }
        fun flushTable() {
            if (tableRows.isNotEmpty()) {
                blocks += Block.Table(tableRows.toList())
                tableRows.clear()
            }
        }

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val md = parseMarkdownRow(line)
            if (md != null) {
                flushPara()
                while (i < lines.size) {
                    val r = parseMarkdownRow(lines[i])
                    if (r != null) {
                        tableRows += r
                        i++
                    } else if (isMarkdownSeparator(lines[i])) {
                        i++
                    } else break
                }
                flushTable()
                continue
            }

            val cells = parseAlignedRow(line)
            if (cells != null && cells.size >= 2) {
                var j = i + 1
                val probe = mutableListOf(cells)
                while (j < lines.size) {
                    val next = parseAlignedRow(lines[j])
                    if (next != null && next.size >= 2) {
                        probe += next
                        j++
                    } else if (lines[j].isBlank()) break
                    else break
                }
                if (probe.size >= 2) {
                    flushPara()
                    tableRows.addAll(probe)
                    flushTable()
                    i = j
                    continue
                }
            }

            if (line.isBlank()) {
                flushPara()
            } else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(line)
            }
            i++
        }
        flushPara()
        flushTable()
        return blocks
    }

    private fun isMarkdownSeparator(line: String): Boolean {
        val t = line.trim()
        return t.matches(Regex("^\\|?[\\s:\\-]+\\|([\\s:\\-]+\\|)*[\\s:\\-]*\\|?$"))
    }

    private fun parseMarkdownRow(line: String): List<String>? {
        val t = line.trim()
        if (!t.startsWith("|") || t.indexOf('|', startIndex = 1) < 0) return null
        if (isMarkdownSeparator(t)) return null
        val parts = t.trim('|').split("|").map { it.trim() }
        return if (parts.any { it.isNotEmpty() }) parts else null
    }

    private fun parseAlignedRow(line: String): List<String>? {
        val t = line.trim()
        if (t.length < 3) return null
        if (t.startsWith("#") || t.startsWith("- ") || t.startsWith("* ") || t.startsWith("•")) return null
        if (t.contains('\t')) {
            val cells = t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            return if (cells.size >= 2) cells else null
        }
        val cells = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (cells.size >= 2) {
            val shortish = cells.count { it.length <= 40 }
            if (cells.size >= 3 || shortish >= 2) return cells
        }
        return null
    }

    private fun translateChunk(chunk: String, sl: String, tl: String): String {
        val textToTranslate = chunk.trim()
        if (textToTranslate.isEmpty()) return ""

        val sLang = if (sl.isBlank() || sl == "auto") "auto" else sl
        val tLang = if (tl.isBlank()) "fa" else tl
        val encoded = URLEncoder.encode(textToTranslate, "UTF-8")
        val urlStr =
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sLang&tl=$tLang&dt=t&q=$encoded"

        var lastError: Exception? = null
        repeat(2) { attempt ->
            val conn = URL(urlStr).openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "GET"
                conn.connectTimeout = 10_000
                conn.readTimeout = 15_000
                conn.setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36",
                )
                val code = conn.responseCode
                if (code !in 200..299) throw IOException("Google Translate HTTP $code")
                val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val root = JSONArray(resp)
                val sentences = root.optJSONArray(0) ?: return textToTranslate
                val sb = StringBuilder()
                for (i in 0 until sentences.length()) {
                    val part = sentences.optJSONArray(i) ?: continue
                    val str = part.optString(0, "")
                    if (str.isNotEmpty()) sb.append(str)
                }
                val result = sb.toString()
                if (result.isNotEmpty()) return result
            } catch (e: Exception) {
                lastError = e
                if (attempt == 0) Thread.sleep(400)
            } finally {
                try { conn.disconnect() } catch (_: Exception) {}
            }
        }
        if (lastError != null && textToTranslate.length > 80) {
            throw IOException("Google Translate failed: ${lastError.message}", lastError)
        }
        return textToTranslate
    }
}
