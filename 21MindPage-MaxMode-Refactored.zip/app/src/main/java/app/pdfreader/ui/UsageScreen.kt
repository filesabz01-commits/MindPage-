@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(vm: AiViewModel, onBack: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val attempts by vm.attempts.collectAsStateWithLifecycle()
    val tokenTotals by vm.tokenTotals.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()
    val now = System.currentTimeMillis()
    val appLang = LocalAppLanguage.current
    val strings = LocalStrings.current

    var filter by remember { mutableStateOf("ALL") }

    val filteredAttempts = remember(attempts, filter) {
        when (filter) {
            "ERRORS" -> attempts.filter { it.outcome != "OK" }
            "TRANSLATE" -> attempts.filter { it.task.equals("TRANSLATE", ignoreCase = true) }
            "SUMMARIZE" -> attempts.filter { it.task.equals("SUMMARIZE", ignoreCase = true) }
            "EXPLAIN" -> attempts.filter { it.task.equals("EXPLAIN", ignoreCase = true) }
            "EXTRACT" -> attempts.filter { it.task.equals("EXTRACT", ignoreCase = true) }
            "TTS" -> attempts.filter { it.task.equals("TTS", ignoreCase = true) }
            else -> attempts
        }
    }
...
// در بخش نمایش نشان توکن کل:
    Surface(
        shape = RoundedCornerShape(50),
        color = MaterialTheme.colorScheme.primary,
    ) {
        Text(
            "${totalTokens.localize(appLang)} " + (if (strings.isFa) "توکن" else "tokens"),
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onPrimary,
        )
    }
...
// و در بخش AttemptCard:
    Text("کلید: ${a.keyLabel}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    Text(formatAttemptTime(a.timestamp, appLang), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
...
    Text(
        if (strings.isFa) "اولین بایت: ${a.timeToFirstByteMs.localize(appLang)}ms · کل: ${a.totalTimeMs.localize(appLang)}ms"
        else "TTFB: ${a.timeToFirstByteMs.localize(appLang)}ms · Total: ${a.totalTimeMs.localize(appLang)}ms",
        style = MaterialTheme.typography.bodySmall,
    )
    if (isOk) {
        Text(
            if (strings.isFa) "توکن: ${a.promptTokens.localize(appLang)} ورودی | ${a.candidatesTokens.localize(appLang)} خروجی" + (if (a.thoughtsTokens > 0) " | ${a.thoughtsTokens.localize(appLang)} فکر" else "")
            else "Tokens: ${a.promptTokens.localize(appLang)} in | ${a.candidatesTokens.localize(appLang)} out" + (if (a.thoughtsTokens > 0) " | ${a.thoughtsTokens.localize(appLang)} thoughts" else ""),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Medium,
        )
    }