if (routing.isPersian) {
            val preferred = s.preferredTtsModel.ifBlank { "" }
            val outcome = router.synthesize(text, voice.ifBlank { s.voice.ifBlank { "Kore" } }, preferred)
            if (outcome is AiRouter.Outcome.Ok && outcome.audio != null && outcome.audio!!.isNotEmpty()) {
                lastSynthError = ""
                return outcome.audio
            }
            val geminiErr = if (outcome is AiRouter.Outcome.Failed) texts.describe(outcome) else "پاسخ صوتی خالی از Gemini"
            lastSynthError = "تولید صوت فارسی با مدل‌های Gemini ناموفق بود: $geminiErr"
            return null
        }

        val edgeVoice = resolveEdgeVoice(text)
        try {
            val bytes = EdgeTts.synthesize(text, edgeVoice)
            if (bytes.isNotEmpty()) {
                lastSynthError = ""
                return bytes
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            lastSynthError = "Edge-TTS: ${e.message}"
        }

        if (s.ttsFallbackGemini) {
            val o = router.synthesize(text, s.voice.ifBlank { "Kore" }, s.preferredTtsModel)
            if (o is AiRouter.Outcome.Ok && o.audio != null && o.audio!!.isNotEmpty()) {
                lastSynthError = ""
                return o.audio
            }
        }
        return null