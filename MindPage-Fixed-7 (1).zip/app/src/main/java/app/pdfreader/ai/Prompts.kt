package app.pdfreader.ai

object Prompts {
    const val NO_TEXT = "[[NO_TEXT]]"

    private fun hint(s: ReadingSettings) =
        if (s.profile == ReadingProfile.GENERAL && s.customInstruction.isBlank()) ""
        else {
            val h = if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else s.profile.hint
            if (h.isBlank()) "" else "\nNote: $h"
        }

    private fun srcName(s: ReadingSettings) =
        if (s.sourceLanguage == "auto") "auto-detect source language"
        else Languages.byCode(s.sourceLanguage).english

    private fun tgtName(s: ReadingSettings) = Languages.byCode(s.targetLanguage).english

    fun buildExtract(s: ReadingSettings, jpeg: ByteArray): AiRequest {
        val prompt = """
            Extract running body text from this document page image in its original language (${srcName(s)}).
            Keep: main narrative paragraphs, definitions, numbered lists, boxed notes, equations, and tables as GitHub-flavored Markdown tables (with | header | and | --- | rows).
            Remove: headers/footers, book title banners, page numbers (Arabic or Roman such as xxiv, xiv), 
            standalone section titles like "Preface", "Contents" when they appear alone with a page number, 
            repeated running headers, publisher download/license notices (e.g. Wiley, InDesign .indd timestamps).
            Keep: figure/table captions that explain content, equations, tables as Markdown, meaningful diagram labels that are part of the teaching text.
            Format: join broken lines, blank line between paragraphs.
            If the page has no substantial readable text (empty scan / pure photo), output exactly: $NO_TEXT
            Output ONLY the extracted text.
        """.trimIndent()
        return AiRequest(prompt = prompt, imageJpeg = jpeg, task = AiTask.EXTRACT)
    }

    fun buildOcrRepair(s: ReadingSettings, text: String): AiRequest {
        val prompt = """
            You repair OCR noise in document page text. Source language: ${srcName(s)}.
            Fix ONLY clear OCR errors: broken words, missing spaces, merged/split letters, obvious character confusions (rn/m, 0/O, ی/ي).
            Join hyphenated line breaks. Keep paragraph breaks (blank line between paragraphs).
            Do NOT translate, summarize, rewrite style, or invent missing content.
            Do NOT remove technical terms, numbers, units, equipment tags, or figure/table captions.
            Output ONLY the repaired text in the same language as the input.

            TEXT:
            $text
        """.trimIndent()
        return AiRequest(prompt = prompt, task = AiTask.EXTRACT)
    }

    fun buildClean(s: ReadingSettings, text: String): AiRequest {
        val prompt = """
            Clean structure of this page text layer: join hyphenated words/lines broken by layout, separate paragraphs with blank lines, keep tables as GitHub-flavored Markdown tables.
            Remove: headers/footers, page numbers (Arabic or Roman), standalone titles like Preface/Contents with only a page number,
            publisher download/copyright notices, .indd timestamps.
            Keep: real body text, tables, equations, and informative figure/table captions.
            Keep original language (${srcName(s)}). Never rephrase or summarize.
            If nothing readable remains, output: $NO_TEXT
            Output ONLY cleaned text.

            TEXT:
            $text
        """.trimIndent()
        return AiRequest(prompt = prompt, task = AiTask.EXTRACT)
    }

    fun buildText(task: AiTask, s: ReadingSettings, text: String): AiRequest {
        val tgt = tgtName(s)
        val body = when (task) {
            AiTask.TRANSLATE -> """
                Translate the following document page text from ${srcName(s)} into $tgt.
                RULES:
                1. Keep the original paragraph structure: put one blank line between paragraphs. Never merge the whole page into a single block.
                2. ALWAYS keep and translate numbered section headings (e.g. '3.2 Ownership Block', '2.7 Tracking Changes in P&IDs').
${if (s.translateMainTextOnly) """
                3. جدول، کپشن شکل، کادر واژه‌نامه و تمرین را خروجی نده؛ فقط پاراگراف‌های پیوسته و heading را ترجمه کن.
                   - Do not translate or output tables, figure captions, table captions, glossary boxes, vocabulary sidebars, or exercise drills/blanks.
                   - Output ONLY continuous narrative paragraphs and real section headings.
""".trimIndent() else """
                3. UNIVERSAL TABLE & STRUCTURED DATA PRESERVATION:
                   - Automatically recognize tables, comparison lists, technical specifications, engineering data, numerical datasets, and parameter lists (e.g. Parameter | Value | Unit).
                   - Format all structured data as clean GitHub-Flavored Markdown tables with header and | --- | separator rows.
                   - Translate headers and cell labels accurately while strictly preserving all original numerical values, engineering units (e.g., Pa, °C, mm, rpm, kg, bar), and mathematical expressions.
                   - Maintain exact row and column relationships. Do NOT flatten tables into prose, and do NOT convert normal narrative paragraphs into artificial tables.
                   - Output it as a proper GitHub-flavored Markdown table with a header row and | --- | separator row.
                   - Translate every cell. Do NOT flatten tables into running prose.
""".trimIndent()}
                4. STRICTLY OMIT and never translate: page numbers, running headers/footers, standalone 'Preface/Contents', 
                   diagram oval/bubble labels, flowchart box labels, short question captions under symbols,
                   figure captions, figure stamp/legal boxes, pure color-only cells, publisher/copyright lines.
                5. Keep numbers, units, formulas, acronyms, equipment tags intact. On first use of a technical term you may add the English in parentheses.
                6. Translate ONLY continuous narrative paragraphs and real section headings. Do not invent content that is not in the input.
                Output ONLY the translation.
            """.trimIndent()
            AiTask.EXPLAIN ->
                "Explain the text below in $tgt clearly: define key terms first, then explain main concepts step-by-step. Output only explanation."
            AiTask.SUMMARIZE ->
                "Summarize the text below in $tgt as 4-8 clear, concise bullet points. Output only summary."
            AiTask.EXTRACT, AiTask.TTS -> ""
        }
        return AiRequest(prompt = "$body${hint(s)}\n\nTEXT:\n$text", task = task)
    }

    fun buildSegments(s: ReadingSettings, segments: List<String>): AiRequest {
        val tgt = tgtName(s)
        val body = StringBuilder()
        segments.forEachIndexed { i, t -> body.append("[[").append(i + 1).append("]]\n").append(t).append("\n\n") }
        val prompt = "Translate each numbered segment below into $tgt. " +
            "Output EXACTLY ${segments.size} blocks in the same order. Each block MUST start with a line containing only [[N]] where N is the segment number. " +
            "Never merge, split, or skip segments. " +
            "Omit page numbers, Roman numerals, bare running headers, and copyright/publisher lines. " +
            (if (s.translateMainTextOnly) "Do not output tables, captions, glossary or exercises; translate only continuous paragraphs and headings. " else "Keep real section headings, tables as Markdown when present, and informative captions. ") +
            "Preserve numbers, units, formulas, acronyms. " +
            "Output ONLY the numbered blocks, nothing else before or after.${hint(s)}\n\nSEGMENTS:\n$body"
        return AiRequest(prompt = prompt, task = AiTask.TRANSLATE)
    }

    enum class RangeMode { FULL, PART, MERGE }

    fun buildRangeSummary(s: ReadingSettings, from: Int, to: Int, text: String, mode: RangeMode): AiRequest {
        val langCode = s.handoutLanguage.ifBlank { s.targetLanguage }.ifBlank { "fa" }
        val tgt = Languages.byCode(langCode).english
        val structure = """
            |Write a DETAILED study handout (NOT a short abstract) in $tgt as Markdown.
            |Be thorough: cover every major idea, definition, rule, and example from the source.
            |Aim for rich notes a student can study from without the original pages.
            |
            |Required sections (## headings):
            |## عنوان بازه
            |## جوهر مطلب
            |(one short paragraph, then expand key themes)
            |## مفاهیم کلیدی
            |(- **term**: full definition; English in parentheses on first use)
            |## قواعد و نکات مهم
            |(numbered; include conditions and exceptions when present)
            |## جداول مهم
            |(IMPORTANT: if the source has a real data table, reproduce it as a GitHub-style Markdown table with | headers | and | --- | rows. Do not skip important tables.)
            |## شکل‌ها و ارجاعات
            |(Figure/Table numbers + one-line meaning)
            |## سؤالات مرور
            |(6–10 self-test questions)
            |## پاسخ سؤالات مرور
            |(brief answers matching the questions above, same numbering)
            |
            |Rules: Do NOT invent facts. Omit running headers/footers/copyright. Output ONLY Markdown.
        """.trimMargin()
        val intro = when (mode) {
            RangeMode.FULL ->
                "Create a complete, detailed study handout for pages ${from + 1}–${to + 1}.\n$structure"
            RangeMode.PART ->
                "Create DETAILED intermediate study notes for this part of pages ${from + 1}–${to + 1} in $tgt. " +
                    "Markdown with ## مفاهیم کلیدی, ## قواعد و نکات, ## جداول مهم. " +
                    "Include definitions, rules, and examples — do not over-compress."
            RangeMode.MERGE ->
                "Merge partial notes into ONE detailed final handout for pages ${from + 1}–${to + 1}.\n$structure\n" +
                    "Deduplicate, keep the fullest definitions, preserve any Markdown tables, keep Q&A sections."
        }
        return AiRequest(prompt = "$intro${hint(s)}\n\nTEXT:\n$text", task = AiTask.SUMMARIZE, maxOutputTokens = 8192)
    }

    fun buildChat(s: ReadingSettings, page: Int, pageText: String, history: String, question: String): AiRequest {
        val tgt = tgtName(s)
        val system = "You are a concise study assistant in a PDF reader. Answer questions about the provided page text first, then general knowledge if needed. Reply in language of question or $tgt. Keep answers clear and succinct." + hint(s)
        val ctx = if (pageText.isBlank()) "(Page has no body text)" else pageText
        val prompt = "PAGE ${page + 1} TEXT:\n$ctx\n\n" +
            (if (history.isBlank()) "" else "HISTORY:\n$history\n\n") +
            "QUESTION: $question"
        return AiRequest(prompt = prompt, system = system, task = AiTask.EXPLAIN, maxOutputTokens = 1024)
    }
}

val RTL_LANGS = setOf("fa", "ar")