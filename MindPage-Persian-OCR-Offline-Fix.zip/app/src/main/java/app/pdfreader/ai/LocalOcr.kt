package app.pdfreader.ai

import android.content.Context
import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import cz.adaptech.tesseract4android.TessBaseAPI
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import java.io.File

/**
 * On-device OCR. ML Kit handles Latin-script languages; bundled Tesseract `fas`
 * model handles Persian. Both run locally and do not require an API key/network.
 */
object LocalOcr {
    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    @Volatile private var persianApi: TessBaseAPI? = null
    private val persianLock = Any()

    suspend fun recognize(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val image = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(image)
            .addOnSuccessListener { result -> if (cont.isActive) cont.resume(result.text.orEmpty()) }
            .addOnFailureListener { if (cont.isActive) cont.resume("") }
    }

    /** Persian OCR using a model shipped in app assets; no runtime download. */
    fun recognizePersian(context: Context, bitmap: Bitmap): String = synchronized(persianLock) {
        val api = persianApi ?: createPersianApi(context.applicationContext).also { persianApi = it }
        api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO)
        api.setImage(bitmap)
        api.getUTF8Text().orEmpty().also { api.clear() }
    }

    private fun createPersianApi(context: Context): TessBaseAPI {
        val root = File(context.filesDir, "tesseract")
        val tessdata = File(root, "tessdata")
        if (!tessdata.exists()) tessdata.mkdirs()
        val model = File(tessdata, "fas.traineddata")
        if (!model.exists() || model.length() < 100_000L) {
            context.assets.open("tessdata/fas.traineddata").use { input -> model.outputStream().use(input::copyTo) }
        }
        return TessBaseAPI().also { api ->
            check(api.init(root.absolutePath, "fas")) { "Could not initialize Persian OCR model (fas.traineddata)." }
        }
    }
}
