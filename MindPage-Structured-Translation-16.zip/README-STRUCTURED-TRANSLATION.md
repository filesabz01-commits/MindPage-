# MindPage – Structured Translation Repair

This source is based on the uploaded `MindPage-Fixed-10.zip`.

## Changes
- Translation no longer applies the legacy "main text only" segment filter. Tables, short technical labels, captions, glossary entries, and exercises are no longer silently removed before translation.
- The obsolete "Main text only" switch was removed from the translation settings UI; translation now defaults to preserving meaningful page content.
- Gemini page translation now sends one structured page-level request instead of retrying the batch and then issuing one paid request per segment.
- The read-aloud segmented Gemini path now makes one batch request; malformed marker output falls back to Google Translate instead of retrying Gemini repeatedly.
- AI cleanup of selectable PDF text no longer immediately triggers a second AI repair request on the same page.
- Markdown tables with more than five columns are no longer flattened into prose.
- Gemini translation instructions now explicitly preserve tables, row/column relationships, formulas, code, captions, technical labels, and reading order.
- Translation cache versions were bumped so old flattened/incorrect translations are not reused.
- Added a regression test for wide Markdown table preservation.

## Verification
- Kotlin compiler parser check was run on the changed Kotlin sources. It reported dependency/classpath unresolved references because this environment does not have the Android/Gradle dependencies, but no Kotlin syntax/parse errors (`Expecting`, `Unexpected tokens`, etc.) were found.
- `./gradlew testDebugUnitTest` could not start because Gradle 8.9 could not be downloaded: DNS/network access to `services.gradle.org` is unavailable.
- Therefore a full Android build and unit-test run are **not verified** in this environment.

## Important limitation
The current translation output is structure-aware Markdown/PDF flow rendering. It preserves detected tables and content structure, but does not yet guarantee pixel-identical placement of every translated element over the original PDF page. Exact visual reconstruction requires a separate positioned-layout renderer and is not claimed in this delivery.
