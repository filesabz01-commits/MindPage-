plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "app.pdfreader"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.pdfreader"
        minSdk = 26
        targetSdk = 34
        versionCode = 14
        versionName = "0.1.14"
    }
    signingConfigs {
        // Stable debug key so CI APKs install over previous builds without uninstall.
        create("debug") {
            val debugKs = file("debug.keystore")
            if (debugKs.exists()) {
                storeFile = debugKs
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
        val keyFile = file("release.keystore")
        val ksPass = System.getenv("KEYSTORE_PASSWORD")
        val keyAliasEnv = System.getenv("KEY_ALIAS")
        val keyPass = System.getenv("KEY_PASSWORD")
        if (keyFile.exists() && !ksPass.isNullOrBlank() && !keyAliasEnv.isNullOrBlank() && !keyPass.isNullOrBlank()) {
            create("release") {
                storeFile = keyFile
                storePassword = ksPass
                keyAlias = keyAliasEnv
                keyPassword = keyPass
                enableV1Signing = true
                enableV2Signing = true
                enableV3Signing = true
                enableV4Signing = true
            }
        } else if (keyFile.exists()) {
            // Local legacy fallback (dev machines only)
            create("release") {
                storeFile = keyFile
                storePassword = "universalpassword"
                keyAlias = "universal"
                keyPassword = "universalpassword"
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            val releaseConfig = signingConfigs.findByName("release")
            signingConfig = releaseConfig ?: signingConfigs.getByName("debug")
        }
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    // PDFium: text positions for sentence highlighting (accessed by reflection in tts/PdfiumTextEngine.kt)
    implementation("io.legere:pdfiumandroid:1.0.19")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // On-device OCR for scanned PDFs (no API cost)
    implementation("com.google.mlkit:text-recognition:16.0.1")

}
