package app.pdfreader.core.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.IOException

/** Stage-1 engine based on the platform PdfRenderer (file-backed, no whole-file RAM load). */
class PdfRendererEngine(private val context: Context) : PdfEngine {

    override suspend fun open(uri: Uri): PdfOpenResult = withContext(Dispatchers.IO) {
        val pfd: ParcelFileDescriptor = try {
            context.contentResolver.openFileDescriptor(uri, "r")
        } catch (e: Exception) {
            null
        } ?: return@withContext PdfOpenResult.Error(PdfError.UNREADABLE, "cannot open descriptor")

        try {
            PdfOpenResult.Ok(RendererDocument(pfd, PdfRenderer(pfd)))
        } catch (e: SecurityException) {
            closeQuietly(pfd)
            PdfOpenResult.Error(PdfError.ENCRYPTED, e.message)
        } catch (e: IOException) {
            closeQuietly(pfd)
            PdfOpenResult.Error(PdfError.CORRUPT, e.message)
        } catch (e: Exception) {
            closeQuietly(pfd)
            PdfOpenResult.Error(PdfError.UNREADABLE, e.message)
        }
    }

    private fun closeQuietly(pfd: ParcelFileDescriptor) {
        try { pfd.close() } catch (e: Exception) { /* ignore */ }
    }
}

private class RendererDocument(
    private val pfd: ParcelFileDescriptor,
    private val renderer: PdfRenderer,
) : PdfDocument {
    // PdfRenderer allows only one open page at a time.
    private val mutex = Mutex()
    override val pageCount: Int = renderer.pageCount

    override suspend fun pageAspect(index: Int): Float = mutex.withLock {
        withContext(Dispatchers.IO) {
            renderer.openPage(index).use { it.height.toFloat() / it.width.toFloat() }
        }
    }

    override suspend fun render(index: Int, widthPx: Int): Bitmap = mutex.withLock {
        withContext(Dispatchers.IO) {
            renderer.openPage(index).use { page ->
                val h = (widthPx.toFloat() * page.height / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(widthPx, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(Color.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    }

    override fun close() {
        try { renderer.close() } catch (e: Exception) { /* ignore */ }
        try { pfd.close() } catch (e: Exception) { /* ignore */ }
    }
}
