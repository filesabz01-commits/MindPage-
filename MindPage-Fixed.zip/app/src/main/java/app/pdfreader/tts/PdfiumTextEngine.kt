package app.pdfreader.tts

import app.pdfreader.ui.TextPick

import android.content.Context
import android.graphics.RectF
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** A rectangle in page coordinates normalized to 0..1, origin at the top-left corner. */
class NRect(val l: Float, val t: Float, val r: Float, val b: Float)

/** The text layer of one page: the text, and the box of every character (null for characters without a box). */
class PageChars(val text: String, val boxes: Array<NRect?>)

/** Where every spoken sentence sits on the page: its line rectangles and its character range in the page text. */
class SentenceMap(val rects: List<List<NRect>>, val ranges: List<IntRange?>)

/**
 * Finds where spoken sentences sit on the PDF page, using the real text layer through PDFium.
 *
 * The PDFium wrapper is called by reflection on purpose: if a method is named differently in some version,
 * highlighting simply switches off (the reason is kept in [lastError]) and nothing else in the app is affected.
 * Scanned PDFs have no text layer, so there is nothing to highlight there.
 */
class PdfiumTextEngine(private val context: Context) {
    private val lock = Any()
    private var core: Any? = null
    private var coreFailed = false
    private var openUri: String? = null
    private var openDoc: Any? = null
    private var openPfd: ParcelFileDescriptor? = null

    @Volatile var lastError: String? = null
        private set

    /** One list of rectangles per sentence (empty when that sentence was not found), or null if unavailable. */
    suspend fun mapSentences(uri: String, pageIndex: Int, sentences: List<String>): SentenceMap? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    mapLocked(uri, pageIndex, sentences)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    /** Only the text of the page's text layer (fast, no positions); null when the layer cannot be read. */
    suspend fun pageText(uri: String, pageIndex: Int): String? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    textLocked(uri, pageIndex)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    private fun textLocked(uri: String, pageIndex: Int): String? {
        val doc = documentFor(uri) ?: return null
        val page = doc.call("openPage", pageIndex) ?: return null
        try {
            val tp = page.call("openTextPage") ?: return null
            try {
                val count = (tp.call("textPageCountChars") as? Number)?.toInt() ?: return null
                if (count < 1) return ""
                return tp.call("textPageGetText", 0, count) as? String
            } finally {
                close(tp)
            }
        } finally {
            close(page)
        }
    }

    private val charCache = LinkedHashMap<String, PageChars>() // used under [lock] only

    /** Every character of the page with its position (cached for a few pages); used for selection and word highlight. */
    suspend fun pageChars(uri: String, pageIndex: Int): PageChars? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    charsCachedLocked(uri, pageIndex)
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    null
                }
            }
        }

    fun release() = synchronized(lock) { closeDocument() }

    private fun charsCachedLocked(uri: String, pageIndex: Int): PageChars? {
        val key = "$uri#$pageIndex"
        charCache[key]?.let { return it }
        val pc = charsLocked(uri, pageIndex) ?: return null
        charCache[key] = pc
        while (charCache.size > 8) charCache.remove(charCache.keys.first())
        return pc
    }

    private fun charsLocked(uri: String, pageIndex: Int): PageChars? {
        val doc = documentFor(uri) ?: return null
        val page = doc.call("openPage", pageIndex)
        if (page == null) { lastError = "صفحه باز نشد"; return null }
        try {
            val w = (page.call("getPageWidthPoint") as? Number)?.toFloat() ?: return null
            val h = (page.call("getPageHeightPoint") as? Number)?.toFloat() ?: return null
            if (w <= 0f || h <= 0f) return null
            val xf = pageXf(page, w, h)
            val tp = page.call("openTextPage")
            if (tp == null) { lastError = "لایه‌ی متنی باز نشد"; return null }
            try {
                val count = (tp.call("textPageCountChars") as? Number)?.toInt() ?: return null
                if (count < 1) { lastError = "این PDF لایه‌ی متنی ندارد (اسکن‌شده)؛ انتخاب متن ممکن نیست"; return null }
                // Built character by character: getText() may skip or merge characters, which shifted every later
                // index (highlights and selections landed several characters off, more and more towards the page end).
                val sb = StringBuilder(count)
                var perChar = true
                for (i in 0 until count) {
                    val u = try { tp.call("textPageGetUnicode", i) as? Char } catch (e: NoSuchMethodException) { null }
                    if (u == null) { perChar = false; break }
                    sb.append(u)
                }
                val full = if (perChar) sb.toString() else (tp.call("textPageGetText", 0, count) as? String ?: return null)
                val boxes = arrayOfNulls<NRect>(count)
                for (i in 0 until count) {
                    val n = (tp.call("textPageCountRects", i, 1) as? Number)?.toInt() ?: 0
                    if (n > 0) {
                        val r = tp.call("textPageGetRect", 0) as? RectF
                        if (r != null) boxes[i] = toNRect(r, xf)
                    }
                }
                return PageChars(full, boxes)
            } finally {
                close(tp)
            }
        } finally {
            close(page)
        }
    }

    /** Page coordinates (PDF points) -> fractions of the rendered page (0..1, origin top-left). */
    private class PageXf(val a: Float, val b: Float, val c: Float, val d: Float, val e: Float, val f: Float) {
        fun x(px: Float, py: Float) = a * px + c * py + e
        fun y(px: Float, py: Float) = b * px + d * py + f
    }

    /**
     * PDF text boxes are in page space, whose origin is NOT always the corner of the visible page (crop box,
     * bleed, rotation). Dividing them by the page size shifted everything to the right and upwards. PDFium itself is
     * asked how it maps page space to the rendered page; three probe points give the whole transform.
     */
    private fun pageXf(page: Any, w: Float, h: Float): PageXf {
        try {
            val size = 100000
            fun dev(x: Double, y: Double): Pair<Float, Float>? {
                val pt = page.call("mapPageCoordsToDevice", 0, 0, size, size, 0, x, y) as? android.graphics.Point ?: return null
                return pt.x / size.toFloat() to pt.y / size.toFloat()
            }
            val o = dev(0.0, 0.0)
            val px = dev(1000.0, 0.0)
            val py = dev(0.0, 1000.0)
            if (o != null && px != null && py != null) {
                val a = (px.first - o.first) / 1000f
                val b = (px.second - o.second) / 1000f
                val c = (py.first - o.first) / 1000f
                val d = (py.second - o.second) / 1000f
                if (kotlin.math.abs(a) + kotlin.math.abs(c) > 1e-7f && kotlin.math.abs(b) + kotlin.math.abs(d) > 1e-7f) {
                    return PageXf(a, b, c, d, o.first, o.second)
                }
            }
        } catch (e: Exception) { /* fall through */ }
        try {
            val bb = page.call("getPageBoundingBox") as? RectF
            if (bb != null) {
                val bw = kotlin.math.abs(bb.right - bb.left)
                val bh = kotlin.math.abs(bb.top - bb.bottom)
                if (bw > 1f && bh > 1f) {
                    val x0 = minOf(bb.left, bb.right)
                    val yb = minOf(bb.top, bb.bottom)
                    return PageXf(1f / bw, 0f, 0f, -1f / bh, -x0 / bw, 1f + yb / bh)
                }
            }
        } catch (e: Exception) { /* fall through */ }
        return PageXf(1f / w, 0f, 0f, -1f / h, 0f, 1f)
    }

    private fun toNRect(r: RectF, xf: PageXf): NRect {
        val x1 = xf.x(r.left, r.top)
        val y1 = xf.y(r.left, r.top)
        val x2 = xf.x(r.right, r.bottom)
        val y2 = xf.y(r.right, r.bottom)
        return NRect(
            minOf(x1, x2).coerceIn(0f, 1f), minOf(y1, y2).coerceIn(0f, 1f),
            maxOf(x1, x2).coerceIn(0f, 1f), maxOf(y1, y2).coerceIn(0f, 1f),
        )
    }

    // ------------------------------------------------------------------ mapping

    private fun mapLocked(uri: String, pageIndex: Int, sentences: List<String>): SentenceMap? {
        val pc = charsCachedLocked(uri, pageIndex) ?: return null
        if (pc.text.length < 20) { lastError = "این PDF لایه‌ی متنی ندارد (اسکن‌شده)"; return null }
        val norm = normalize(pc.text)
        var cursor = 0
        val rects = ArrayList<List<NRect>>(sentences.size)
        val ranges = ArrayList<IntRange?>(sentences.size)
        for (sentence in sentences) {
            val needle = normalize(sentence).s
            // normally the sentences follow the page order; when the cleaned text was re-ordered, search the whole page
            val range = locate(norm.s, needle, cursor) ?: locate(norm.s, needle, 0)
            if (range == null || range.second <= range.first) {
                rects += emptyList<NRect>()
                ranges += null
                continue
            }
            if (range.first >= cursor) cursor = range.second
            val start = norm.map[range.first]
            val endIncl = norm.map[range.second - 1]
            rects += TextPick.rects(pc, start, endIncl)
            ranges += start..endIncl
        }
        return SentenceMap(rects, ranges)
    }

    /** Finds [needle] in [hay] at or after [from]; falls back to matching its beginning (and end). */
    private fun locate(hay: String, needle: String, from: Int): Pair<Int, Int>? {
        if (needle.length < 6) return null
        val exact = hay.indexOf(needle, from)
        if (exact >= 0) return exact to exact + needle.length
        if (needle.length < 24) return null
        val k = minOf(20, needle.length / 2)
        val head = hay.indexOf(needle.substring(0, k), from)
        if (head < 0) return null
        val tail = hay.indexOf(needle.substring(needle.length - k), head + k)
        if (tail >= 0 && tail + k - head <= needle.length * 1.6) return head to tail + k
        // the middle differs (re-worded join, dropped caption): the start is still right, the length is estimated
        return head to minOf(hay.length, head + needle.length)
    }

    // ------------------------------------------------------------------ text normalization

    private class Norm(val s: String, val map: IntArray)

    private fun normalize(text: String): Norm {
        val sb = StringBuilder(text.length)
        val idx = ArrayList<Int>(text.length)
        text.forEachIndexed { i, ch ->
            val expanded = when (ch) {
                '\uFB01' -> "fi"
                '\uFB02' -> "fl"
                '\uFB00' -> "ff"
                '\uFB03' -> "ffi"
                '\uFB04' -> "ffl"
                else -> null
            }
            if (expanded != null) {
                for (e in expanded) { sb.append(e); idx.add(i) }
            } else if (ch.isLetterOrDigit()) {
                sb.append(ch.lowercaseChar())
                idx.add(i)
            }
        }
        return Norm(sb.toString(), idx.toIntArray())
    }

    // ------------------------------------------------------------------ PDFium access (reflection)

    private fun documentFor(uri: String): Any? {
        if (openUri == uri && openDoc != null) return openDoc
        closeDocument()
        val c = core() ?: return null
        val pfd = context.contentResolver.openFileDescriptor(Uri.parse(uri), "r")
        if (pfd == null) { lastError = "فایل باز نشد"; return null }
        val doc = try {
            c.call("newDocument", pfd)
        } catch (e: Throwable) {
            try { pfd.close() } catch (ignored: Throwable) { }
            throw e
        }
        openPfd = pfd
        openDoc = doc
        openUri = uri
        return doc
    }

    private fun closeDocument() {
        close(openDoc)
        try { openPfd?.close() } catch (e: Throwable) { /* ignore */ }
        openDoc = null
        openPfd = null
        openUri = null
    }

    private fun core(): Any? {
        core?.let { return it }
        if (coreFailed) return null
        try {
            val cls = Class.forName("io.legere.pdfiumandroid.PdfiumCore")
            val inst: Any = try {
                cls.getConstructor(Context::class.java).newInstance(context)
            } catch (e: Throwable) {
                try {
                    cls.getConstructor().newInstance()
                } catch (e2: Throwable) {
                    // Kotlin "default argument" constructor: (Context, Config, int mask, DefaultConstructorMarker)
                    val ctor = cls.declaredConstructors.first { it.parameterTypes.firstOrNull() == Context::class.java }
                    ctor.isAccessible = true
                    val n = ctor.parameterTypes.size
                    val args = arrayOfNulls<Any>(n)
                    args[0] = context
                    if (n >= 3 && ctor.parameterTypes[n - 2] == Int::class.javaPrimitiveType) {
                        args[n - 2] = ((1 shl (n - 2)) - 1) and 1.inv()
                    }
                    ctor.newInstance(*args)
                }
            }
            core = inst
            return inst
        } catch (e: Throwable) {
            coreFailed = true
            lastError = "PDFium آماده نشد: " + (e.cause ?: e).javaClass.simpleName
            return null
        }
    }


    /**
     * Rebuild page text using character boxes so multi-column tables keep row/column structure.
     * Falls back to plain pageText when geometry is unavailable.
     * Tables are emitted as GitHub-style Markdown pipes so translators can work cell-wise.
     */
    suspend fun pageTextStructured(uri: String, pageIndex: Int): String? =
        withContext(Dispatchers.IO) {
            synchronized(lock) {
                try {
                    lastError = null
                    val pc = charsCachedLocked(uri, pageIndex)
                    if (pc == null) {
                        textLocked(uri, pageIndex)
                    } else {
                        rebuildStructured(pc)
                    }
                } catch (e: Throwable) {
                    lastError = (e.cause ?: e).let { it.javaClass.simpleName + ": " + (it.message ?: "") }.take(140)
                    try {
                        textLocked(uri, pageIndex)
                    } catch (_: Throwable) {
                        null
                    }
                }
            }
        }

    private data class WordBox(val text: String, val l: Float, val t: Float, val r: Float, val b: Float) {
        val cx: Float get() = (l + r) / 2f
        val cy: Float get() = (t + b) / 2f
    }

    private data class LineBox(val words: List<WordBox>, val t: Float, val b: Float) {
        val cy: Float get() = (t + b) / 2f
        val text: String get() = words.joinToString(" ") { it.text }
    }

    private fun rebuildStructured(pc: PageChars): String {
        val words = groupWords(pc)
        if (words.isEmpty()) return pc.text.trim()
        val lines = clusterLines(words)
        if (lines.isEmpty()) return pc.text.trim()

        val out = ArrayList<String>()
        var i = 0
        while (i < lines.size) {
            val table = tryExtractTable(lines, i)
            if (table != null) {
                out += table.first
                out += ""
                i += table.second
            } else {
                out += lines[i].text
                i++
            }
        }
        return out.joinToString("\n").trim()
    }

    private fun groupWords(pc: PageChars): List<WordBox> {
        val n = minOf(pc.text.length, pc.boxes.size)
        val words = ArrayList<WordBox>()
        var i = 0
        while (i < n) {
            val ch = pc.text[i]
            val box = pc.boxes[i]
            if (ch.isWhitespace() || box == null) {
                i++
                continue
            }
            val sb = StringBuilder().append(ch)
            var l = box.l
            var t = box.t
            var r = box.r
            var b = box.b
            var j = i + 1
            while (j < n) {
                val c2 = pc.text[j]
                val b2 = pc.boxes[j]
                if (c2.isWhitespace() || b2 == null) break
                val gap = b2.l - r
                val charW = (r - l).coerceAtLeast(0.002f) / sb.length.coerceAtLeast(1)
                if (gap > charW * 1.8f) break
                val midY = (t + b) / 2f
                val otherY = (b2.t + b2.b) / 2f
                if (kotlin.math.abs(otherY - midY) > (b - t).coerceAtLeast(0.005f) * 1.2f) break
                sb.append(c2)
                l = minOf(l, b2.l)
                t = minOf(t, b2.t)
                r = maxOf(r, b2.r)
                b = maxOf(b, b2.b)
                j++
            }
            words += WordBox(sb.toString(), l, t, r, b)
            i = j
        }
        return words
    }

    private fun clusterLines(words: List<WordBox>): List<LineBox> {
        if (words.isEmpty()) return emptyList()
        val sorted = words.sortedWith(compareBy<WordBox> { it.cy }.thenBy { it.l })
        val lines = ArrayList<LineBox>()
        var cur = ArrayList<WordBox>()
        var lineCy = sorted[0].cy
        var lineH = (sorted[0].b - sorted[0].t).coerceAtLeast(0.008f)
        for (w in sorted) {
            if (kotlin.math.abs(w.cy - lineCy) <= lineH * 0.55f) {
                cur += w
                lineCy = cur.map { it.cy }.average().toFloat()
                lineH = cur.map { (it.b - it.t).coerceAtLeast(0.006f) }.average().toFloat()
            } else {
                if (cur.isNotEmpty()) {
                    cur.sortBy { it.l }
                    lines += LineBox(cur.toList(), cur.minOf { it.t }, cur.maxOf { it.b })
                }
                cur = arrayListOf(w)
                lineCy = w.cy
                lineH = (w.b - w.t).coerceAtLeast(0.008f)
            }
        }
        if (cur.isNotEmpty()) {
            cur.sortBy { it.l }
            lines += LineBox(cur.toList(), cur.minOf { it.t }, cur.maxOf { it.b })
        }
        return lines
    }

    /**
     * Detect real multi-column tables only.
     * Continuous prose (even if words span the page width) must NOT become a Markdown table —
     * that was splitting every sentence into fake columns and ruining Google Translate output.
     */
    private fun tryExtractTable(lines: List<LineBox>, start: Int): Pair<String, Int>? {
        if (start >= lines.size) return null
        var j = start
        var caption: String? = null
        val firstText = lines[start].text
        val captionRe = Regex("^(Table|TABLE|table)\\s*\\d", RegexOption.IGNORE_CASE)
        val hasCaption = captionRe.containsMatchIn(firstText)
        if (hasCaption) {
            caption = firstText
            j = start + 1
        }

        val probe = ArrayList<List<WordBox>>()
        while (j < lines.size && probe.size < 16) {
            val ln = lines[j]
            // Stop on long narrative lines (typical body paragraph)
            if (ln.words.size >= 10 && ln.text.length > 90) {
                if (probe.isEmpty()) return null
                break
            }
            if (ln.words.size >= 2) {
                probe += ln.words
                j++
            } else if (ln.words.size == 1 && probe.size >= 2) {
                val only = ln.words[0].text
                if (only.length > 60 || only.endsWith('.')) break
                probe += ln.words
                j++
            } else {
                break
            }
        }
        if (probe.size < 3) return null

        val multi = probe.filter { it.size >= 2 }
        if (multi.size < 3) return null
        val centers = estimateColumnCenters(multi) ?: return null
        // Real tables: 2..5 columns with CLEAR horizontal gaps (not word spacing)
        if (centers.size < 2 || centers.size > 5) return null
        val sortedC = centers.sorted()
        val minGap = sortedC.zipWithNext().minOf { (a, b) -> b - a }
        if (minGap < 0.12f) return null // word gaps on prose lines are much smaller

        // Without a caption, require that most rows leave at least one column empty
        // (dense full-width text fills every column → prose, not a table)
        val rows = probe.map { assignToColumns(it, centers) }
        val sparse = rows.count { r -> r.count { it.isBlank() } >= 1 || r.count { it.isNotBlank() } <= centers.size - 1 }
        if (!hasCaption && sparse < rows.size / 2) return null

        val rich = rows.count { r -> r.count { cell -> cell.isNotBlank() } >= 2 }
        if (rich < 3) return null

        val cols = centers.size
        val norm = rows.map { r -> List(cols) { k -> r.getOrElse(k) { "" }.trim() } }
        // Reject if average cell looks like a full sentence fragment (prose split badly)
        val avgCellLen = norm.flatten().filter { it.isNotEmpty() }.map { it.length }.average()
        if (avgCellLen > 45 && !hasCaption) return null

        val sb = StringBuilder()
        if (caption != null) sb.append(caption).append("\n\n")
        sb.append("| ").append(norm[0].joinToString(" | ")).append(" |\n")
        sb.append("| ").append(List(cols) { "---" }.joinToString(" | ")).append(" |\n")
        for (r in norm.drop(1)) {
            sb.append("| ").append(r.joinToString(" | ")).append(" |\n")
        }
        return sb.toString().trimEnd() to (j - start)
    }

    private fun estimateColumnCenters(lines: List<List<WordBox>>): List<Float>? {
        val xs = lines.flatMap { row -> row.map { it.cx } }.sorted()
        if (xs.size < 2) return null
        val gapThresh = 0.06f
        val clusters = ArrayList<ArrayList<Float>>()
        for (x in xs) {
            if (clusters.isEmpty() || x - clusters.last().average() > gapThresh) {
                clusters += arrayListOf(x)
            } else {
                clusters.last() += x
            }
        }
        if (clusters.size < 2) return null
        if (clusters.size > 8) return null
        return clusters.map { it.average().toFloat() }
    }

    private fun assignToColumns(words: List<WordBox>, centers: List<Float>): List<String> {
        val cells = Array(centers.size) { StringBuilder() }
        for (w in words) {
            var best = 0
            var bestD = Float.MAX_VALUE
            for (c in centers.indices) {
                val d = kotlin.math.abs(w.cx - centers[c])
                if (d < bestD) {
                    bestD = d
                    best = c
                }
            }
            if (cells[best].isNotEmpty()) cells[best].append(' ')
            cells[best].append(w.text)
        }
        return cells.map { it.toString() }
    }

    private fun close(o: Any?) {
        try { (o as? AutoCloseable)?.close() } catch (e: Throwable) { /* ignore */ }
    }

    private val methodCache = HashMap<String, List<java.lang.reflect.Method>>() // used under [lock] only

    /** Calls a public method by name and argument count; Kotlin properties show up here as getX() methods too. */
    private fun Any.call(name: String, vararg args: Any?): Any? {
        val key = javaClass.name + "#" + name + "#" + args.size
        val candidates = methodCache.getOrPut(key) { javaClass.methods.filter { it.name == name && it.parameterTypes.size == args.size } }
        val m = candidates.firstOrNull { argsFit(it.parameterTypes, args) }
            ?: throw NoSuchMethodException("${javaClass.simpleName}.$name/${args.size}")
        return m.invoke(this, *args)
    }

    private fun argsFit(types: Array<Class<*>>, args: Array<out Any?>): Boolean = types.indices.all { i ->
        val a = args[i]
        val t = types[i]
        when {
            a == null -> !t.isPrimitive
            else -> (if (t.isPrimitive) t.kotlin.javaObjectType else t).isInstance(a)
        }
    }
}
