package app.pdfreader.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import app.pdfreader.ai.sha256
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Small first-page images for the library. Stored in the app's private files. */
object Thumbnails {
    private fun file(context: Context, uri: String): File {
        val dir = File(context.filesDir, "thumbs").also { it.mkdirs() }
        return File(dir, sha256(uri) + ".jpg")
    }

    suspend fun ensure(context: Context, uri: String, doc: PdfDocument) = withContext(Dispatchers.IO) {
        val f = file(context, uri)
        if (f.exists() && f.length() > 0) return@withContext
        try {
            val bmp = doc.render(0, 360)
            f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 80, it) }
            bmp.recycle()
        } catch (e: Exception) {
            // a missing thumbnail is not an error
        }
    }

    suspend fun load(context: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
        val f = file(context, uri)
        if (f.exists()) try { BitmapFactory.decodeFile(f.absolutePath) } catch (e: Exception) { null } else null
    }

    fun delete(context: Context, uri: String) {
        file(context, uri).delete()
    }
}
