package app.pdfreader.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "handouts")
data class HandoutEntity(
    @PrimaryKey val id: String,
    val docUri: String,
    val docName: String,
    val fromPage: Int,
    val toPage: Int,
    val title: String,
    val markdown: String,
    val pdfPath: String,
    val model: String,
    val createdAt: Long,
)

@Dao
interface HandoutDao {
    @Query("SELECT * FROM handouts WHERE docUri = :docUri ORDER BY createdAt DESC")
    fun observeForDoc(docUri: String): Flow<List<HandoutEntity>>

    @Query("SELECT * FROM handouts ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<HandoutEntity>>

    @Query("SELECT * FROM handouts WHERE docUri = :docUri ORDER BY createdAt DESC")
    suspend fun listForDoc(docUri: String): List<HandoutEntity>

    @Upsert
    suspend fun upsert(h: HandoutEntity)

    @Query("DELETE FROM handouts WHERE id = :id")
    suspend fun delete(id: String)

    @Query("DELETE FROM handouts WHERE docUri = :docUri")
    suspend fun deleteForDoc(docUri: String)

    @Query("SELECT * FROM handouts WHERE docUri = :docUri AND fromPage = :from AND toPage = :to ORDER BY createdAt DESC LIMIT 1")
    suspend fun findForRange(docUri: String, from: Int, to: Int): HandoutEntity?

    @Query("DELETE FROM handouts WHERE docUri = :docUri AND fromPage = :from AND toPage = :to AND id != :keepId")
    suspend fun deleteDuplicates(docUri: String, from: Int, to: Int, keepId: String)
}
