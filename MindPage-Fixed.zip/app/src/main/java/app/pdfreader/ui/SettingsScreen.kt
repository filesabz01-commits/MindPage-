package app.pdfreader.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.GeminiModels
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.Lang
import app.pdfreader.ai.Languages
import app.pdfreader.ai.ModelEntity
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.SecretBox
import app.pdfreader.ui.l10n.LocalAppLanguage
import app.pdfreader.ui.l10n.LocalStrings
import app.pdfreader.ui.l10n.NumberFormatter
import app.pdfreader.ui.l10n.localize

fun statusLabel(s: String, isFa: Boolean = true): String = when (s) {
    KeyStatus.ACTIVE.name -> if (isFa) "فعال" else "Active"
    KeyStatus.RATE_LIMITED.name -> if (isFa) "محدودیت نرخ (Rate Limit)" else "Rate Limited"
    KeyStatus.DAILY_QUOTA_EXCEEDED.name -> if (isFa) "سهمیه روزانه تمام شده" else "Daily Quota Exceeded"
    KeyStatus.INVALID.name -> if (isFa) "نامعتبر" else "Invalid"
    KeyStatus.TEMPORARILY_UNAVAILABLE.name -> if (isFa) "موقتاً خارج از دسترس" else "Temporarily Unavailable"
    KeyStatus.DISABLED.name -> if (isFa) "غیرفعال" else "Disabled"
    else -> s
}

fun effectiveStatus(k: ApiKeyEntity, now: Long): String =
    if (k.cooldownUntil in 1..now &&
        (k.status == KeyStatus.RATE_LIMITED.name || k.status == KeyStatus.DAILY_QUOTA_EXCEEDED.name ||
            k.status == KeyStatus.TEMPORARILY_UNAVAILABLE.name)
    ) KeyStatus.ACTIVE.name else k.status

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: AiViewModel, onBack: () -> Unit, onUsage: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val models by vm.models.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val cacheBytes by vm.cacheBytes.collectAsStateWithLifecycle()
    val tests by vm.testMessages.collectAsStateWithLifecycle()
    val audioBytes by vm.audioBytes.collectAsStateWithLifecycle()

    val appLang = LocalAppLanguage.current
    val str = LocalStrings.current
    val isFa = str.isFa

    var addModelFor by remember { mutableStateOf<ProviderEntity?>(null) }
    var addTtsModel by remember { mutableStateOf(false) }
    var addKeyFor by remember { mutableStateOf<ProviderEntity?>(null) }
    var deleteProvider by remember { mutableStateOf<ProviderEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(str.settingsTitle, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = str.back)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                ),
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            // ------------------------------------------------------------------
            // 1. APPLICATION LANGUAGE (Bilingual & Strict Number Localization)
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catLanguage,
                    icon = Icons.Default.Language,
                    subtitle = str.appLangDesc,
                ) {
                    Text(str.appLangLabel, style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = settings.appLanguage == "fa",
                            onClick = { vm.setAppLanguage("fa") },
                            label = { Text(str.langPersian) },
                            leadingIcon = if (settings.appLanguage == "fa") { { Icon(Icons.Default.Check, contentDescription = null, Modifier.size(16.dp)) } } else null,
                        )
                        FilterChip(
                            selected = settings.appLanguage == "en",
                            onClick = { vm.setAppLanguage("en") },
                            label = { Text(str.langEnglish) },
                            leadingIcon = if (settings.appLanguage == "en") { { Icon(Icons.Default.Check, contentDescription = null, Modifier.size(16.dp)) } } else null,
                        )
                    }

                    HorizontalDivider(Modifier.padding(vertical = 12.dp))

                    Text(str.pdfSourceLang, style = MaterialTheme.typography.labelLarge)
                    LangRow(selected = settings.sourceLanguage, options = Languages.all, onSelect = vm::setSourceLanguage)

                    Text(str.targetLang, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                    LangRow(selected = settings.targetLanguage, options = Languages.targets, onSelect = vm::setTargetLanguage)

                    Text(str.handoutLang, style = MaterialTheme.typography.labelLarge, modifier = Modifier.padding(top = 8.dp))
                    LangRow(selected = settings.handoutLanguage, options = Languages.targets, onSelect = vm::setHandoutLanguage)
                }
            }

            // ------------------------------------------------------------------
            // 2. TRANSLATION ENGINE SELECTION
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catTranslation,
                    icon = Icons.Default.Translate,
                    subtitle = if (settings.translationEngine == "google") str.googleEngineDesc else str.aiEngineDesc,
                ) {
                    Text(str.translationEngineLabel, style = MaterialTheme.typography.labelLarge)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        FilterChip(
                            selected = settings.translationEngine == "google",
                            onClick = { vm.setTranslationEngine("google") },
                            label = { Text("Google Translate") },
                        )
                        FilterChip(
                            selected = settings.translationEngine == "ai",
                            onClick = { vm.setTranslationEngine("ai") },
                            label = { Text("Gemini AI") },
                        )
                    }

                    Surface(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text(
                                if (settings.translationEngine == "google") str.googleEngineTitle else str.aiEngineTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            Text(
                                if (settings.translationEngine == "google") str.googleEngineDesc else str.aiEngineDesc,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // 3. GEMINI API CONFIGURATION & KEYS
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catApiKeys,
                    icon = Icons.Default.Key,
                    subtitle = if (isFa) "مدیریت کلیدهای API برای درخواست‌های هوش مصنوعی و صوت" else "Manage Gemini API keys and provider endpoints",
                ) {
                    providers.forEach { p ->
                        val pModels = models.filter { it.providerId == p.id }
                        val pKeys = keys.filter { it.providerId == p.id }
                        ProviderCard(
                            p = p,
                            models = pModels,
                            keys = pKeys,
                            tests = tests,
                            vm = vm,
                            onAddModel = { addModelFor = p },
                            onAddKey = { addKeyFor = p },
                            onDelete = { deleteProvider = p },
                            isFa = isFa,
                        )
                    }
                }
            }

            // ------------------------------------------------------------------
            // 4. GEMINI TEXT MODEL MANAGEMENT
            // ------------------------------------------------------------------
            item {
                val textModels = models.filter { it.providerId == "gemini" && it.supportsText }.sortedBy { it.position }
                val fetchMsg by vm.modelFetchMsg.collectAsStateWithLifecycle()
                ModernSettingsCard(
                    title = str.catTextModels,
                    icon = Icons.Default.Psychology,
                    subtitle = str.textModelPriorityDesc,
                ) {
                    Text(str.textModelLadderTitle, style = MaterialTheme.typography.labelLarge)
                    Text(
                        if (isFa) "ترتیب = اولویت fallback (ارزان‌تر بالاتر). قیمت رسمی در API موجود نیست → «نامشخص»."
                        else "Order = fallback priority (cheaper first). Official prices are not in the API → shown as Unknown.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    textModels.forEachIndexed { idx, m ->
                        ModelManageRow(
                            m = m,
                            index = idx,
                            isFa = isFa,
                            appLang = appLang,
                            costLabel = if (isFa) "هزینه: نامشخص" else "Cost: Unknown",
                            onToggle = { vm.setModelEnabled(m, it) },
                            onDelete = { vm.deleteModel(m) },
                            onMoveUp = { vm.moveModel(m, -1) },
                            onMoveDown = { vm.moveModel(m, +1) },
                        )
                    }
                    if (textModels.isEmpty()) {
                        Text(if (isFa) "مدل متنی‌ای نیست. اضافه کنید یا از API بگیرید." else "No text models. Add one or fetch from API.")
                    }
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { addModelFor = providers.firstOrNull { it.id == "gemini" } }) {
                            Text(if (isFa) "+ افزودن مدل" else "+ Add model")
                        }
                        OutlinedButton(onClick = { vm.fetchGeminiModelsFromApi() }) {
                            Text(if (isFa) "دریافت از API" else "Fetch from API")
                        }
                    }
                    fetchMsg?.let { msg ->
                        Text(msg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        TextButton(onClick = { vm.clearModelFetchMsg() }) { Text(if (isFa) "باشه" else "OK") }
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    Text(str.preferredModelLabel, style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.preferredModel.isBlank(),
                            onClick = { vm.setPreferredModel("") },
                            label = { Text(str.autoCheapest) },
                        )
                        textModels.filter { it.enabled }.forEach { m ->
                            FilterChip(
                                selected = settings.preferredModel == m.modelName,
                                onClick = { vm.setPreferredModel(m.modelName) },
                                label = { Text(m.modelName.removePrefix("gemini-")) },
                            )
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // 5. GEMINI TTS MODEL MANAGEMENT
            // ------------------------------------------------------------------
            item {
                val ttsModels = models.filter { it.providerId == "gemini" && it.supportsTts }.sortedBy { it.position }
                ModernSettingsCard(
                    title = if (isFa) "۵. مدل‌های صوتی Gemini TTS" else "5. Gemini TTS Models",
                    icon = Icons.Default.RecordVoiceOver,
                    subtitle = str.ttsModelPriorityDesc,
                ) {
                    Text(str.ttsModelLadderTitle, style = MaterialTheme.typography.labelLarge)
                    Text(
                        if (isFa) "فقط شناسه‌هایی که اضافه کرده‌اید یا از API آمده‌اند. هزینه رسمی: نامشخص."
                        else "Only IDs you added or fetched from API. Official cost: Unknown.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.height(8.dp))
                    ttsModels.forEachIndexed { idx, m ->
                        ModelManageRow(
                            m = m,
                            index = idx,
                            isFa = isFa,
                            appLang = appLang,
                            costLabel = if (isFa) "هزینه: نامشخص" else "Cost: Unknown",
                            onToggle = { vm.setModelEnabled(m, it) },
                            onDelete = { vm.deleteModel(m) },
                            onMoveUp = { vm.moveModel(m, -1) },
                            onMoveDown = { vm.moveModel(m, +1) },
                        )
                    }
                    if (ttsModels.isEmpty()) {
                        Text(if (isFa) "مدل TTSای نیست." else "No TTS models yet.")
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = {
                            // Reuse add dialog but mark TTS via special provider flag — dialog updated below
                            addTtsModel = true
                        },
                    ) {
                        Text(if (isFa) "+ افزودن مدل TTS" else "+ Add TTS model")
                    }
                    HorizontalDivider(Modifier.padding(vertical = 10.dp))
                    Text(str.preferredTtsLabel, style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = settings.preferredTtsModel.isBlank(),
                            onClick = { vm.setPreferredTtsModel("") },
                            label = { Text(str.autoCheapest) },
                        )
                        ttsModels.filter { it.enabled }.forEach { m ->
                            FilterChip(
                                selected = settings.preferredTtsModel == m.modelName,
                                onClick = { vm.setPreferredTtsModel(m.modelName) },
                                label = { Text(m.modelName.removePrefix("gemini-")) },
                            )
                        }
                    }
                }
            }

            // ------------------------------------------------------------------
            // 6. TTS VOICE & SMART HYBRID ROUTING
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catVoiceRouting,
                    icon = Icons.Default.RecordVoiceOver,
                    subtitle = str.hybridRoutingTitle,
                ) {
                    // Smart Hybrid Architecture Explanation Banner
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                    ) {
                        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                Text(str.hybridRoutingTitle, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                            }
                            Text("• ${str.hybridPersianRule}", style = MaterialTheme.typography.bodySmall)
                            Text("• ${str.hybridForeignRule}", style = MaterialTheme.typography.bodySmall)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(if (isFa) "انتخاب صدای Gemini (برای متن‌های فارسی)" else "Gemini Voice (for Persian narration)", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr").forEach { v ->
                            FilterChip(
                                selected = settings.voice == v,
                                onClick = { vm.setVoice(v) },
                                label = { Text(v) },
                            )
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Text(if (isFa) "ترجیح صدای Edge TTS (برای متن‌های انگلیسی و خارجی)" else "Edge TTS Voice Preference (Foreign Languages)", style = MaterialTheme.typography.labelLarge)
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(
                            "fa-IR-DilaraNeural" to (if (isFa) "صدای زن (Dilara/Jenny)" else "Female Voice"),
                            "fa-IR-FaridNeural" to (if (isFa) "صدای مرد (Farid/Guy)" else "Male Voice"),
                        ).forEach { (id, label) ->
                            FilterChip(
                                selected = settings.edgeVoice == id,
                                onClick = { vm.setEdgeVoice(id) },
                                label = { Text(label) },
                            )
                        }
                    }

                    Row(
                        Modifier.fillMaxWidth().padding(top = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(
                            if (isFa) "در صورت قطعی Edge در متون خارجی → تنزل به Gemini" else "Fallback to Gemini if Edge fails for foreign text",
                            Modifier.weight(1f),
                            style = MaterialTheme.typography.bodyMedium,
                        )
                        Switch(
                            checked = settings.ttsFallbackGemini,
                            onCheckedChange = vm::setTtsFallbackGemini,
                        )
                    }
                }
            }

            // ------------------------------------------------------------------
            // 7. AUDIO PLAYBACK SETTINGS
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catAudioPlayback,
                    icon = Icons.Default.VolumeUp,
                    subtitle = if (isFa) "کنترل هماهنگی صوت و متن و سرعت پخش" else "Sentence highlighting and playback options",
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(str.highlightPdfTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                if (isFa) "هایلایت زنده خطوط و کلمات همگام با صوت" else "Highlight sentences on page during speech",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = settings.highlightPdf, onCheckedChange = vm::setHighlightPdf)
                    }

                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(str.hideFallbackTextTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(
                                if (isFa) "در صفحاتی که متن روی PDF هایلایت نمی‌شود" else "When PDF text layer cannot be directly highlighted",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = settings.hideFallbackText, onCheckedChange = vm::setHideFallbackText)
                    }
                }
            }

            // ------------------------------------------------------------------
            // 8. PDF & READING PREFERENCES + STORAGE
            // ------------------------------------------------------------------
            item {
                ModernSettingsCard(
                    title = str.catPdfStorage,
                    icon = Icons.Default.Storage,
                    subtitle = if (isFa) "تنظیمات پردازش سند، OCR و مدیریت حافظه" else "Document processing, OCR, and storage management",
                ) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(str.persistOcrTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(str.persistOcrDesc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = settings.persistOcr, onCheckedChange = vm::setPersistOcr)
                    }

                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(str.bilingualTitle, style = MaterialTheme.typography.bodyLarge)
                            Text(if (isFa) "نمایش موازی ترجمه و متن سند" else "Show source and translated text side-by-side", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = settings.bilingual, onCheckedChange = vm::setBilingual)
                    }

                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(if (isFa) "حالت شب (Night Mode)" else "Night Mode", style = MaterialTheme.typography.bodyLarge)
                            Text(if (isFa) "پس‌زمینه تیره و کنتراست ملایم" else "Dark paper background for comfortable reading", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = settings.nightMode, onCheckedChange = vm::setNightMode)
                    }

                    HorizontalDivider(Modifier.padding(vertical = 12.dp))

                    Text("${str.cacheSizeLabel}: ${NumberFormatter.formatBytes(cacheBytes, appLang)}", style = MaterialTheme.typography.bodyMedium)
                    Text("${str.audioCacheSizeLabel}: ${NumberFormatter.formatBytes(audioBytes, appLang)}", style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(top = 2.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(onClick = vm::clearCache, modifier = Modifier.weight(1f)) {
                            Text(str.clearCacheBtn)
                        }
                        Button(onClick = onUsage, modifier = Modifier.weight(1f)) {
                            Text(str.usageScreenBtn)
                        }
                    }
                }
            }
        }
    }

    addModelFor?.let { p ->
        AddModelDialog(
            isFa = isFa,
            ttsMode = false,
            onDismiss = { addModelFor = null },
            onAdd = { n, text, vision, tts ->
                vm.addModel(p.id, n, text, vision, tts)
                addModelFor = null
            },
        )
    }
    if (addTtsModel) {
        AddModelDialog(
            isFa = isFa,
            ttsMode = true,
            onDismiss = { addTtsModel = false },
            onAdd = { n, _, _, _ ->
                vm.addModel("gemini", n, text = false, vision = false, tts = true)
                addTtsModel = false
            },
        )
    }

    addKeyFor?.let { p ->
        AddKeyDialog(onDismiss = { addKeyFor = null }, onAdd = { l, s -> vm.addKey(p.id, l, s); addKeyFor = null })
    }

    deleteProvider?.let { p ->
        AlertDialog(
            onDismissRequest = { deleteProvider = null },
            title = { Text(if (isFa) "حذف ${p.name}؟" else "Delete ${p.name}?") },
            text = { Text(if (isFa) "مدل‌ها و کلیدهای این provider نیز حذف می‌شوند." else "Models and keys of this provider will also be removed.") },
            confirmButton = { TextButton(onClick = { vm.deleteProvider(p); deleteProvider = null }) { Text(str.delete) } },
            dismissButton = { TextButton(onClick = { deleteProvider = null }) { Text(str.cancel) } },
        )
    }
}

@Composable
private fun ModernSettingsCard(
    title: String,
    icon: ImageVector,
    subtitle: String? = null,
    content: @Composable () -> Unit,
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface,
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.size(36.dp),
                ) {
                    Icon(
                        icon,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(8.dp),
                    )
                }
                Column(Modifier.weight(1f)) {
                    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    if (subtitle != null) {
                        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            content()
        }
    }
}

@Composable
private fun ProviderCard(
    p: ProviderEntity,
    models: List<ModelEntity>,
    keys: List<ApiKeyEntity>,
    tests: Map<String, String>,
    vm: AiViewModel,
    onAddModel: () -> Unit,
    onAddKey: () -> Unit,
    onDelete: () -> Unit,
    isFa: Boolean,
) {
    var showModels by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(p.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${ProviderTypes.label(p.type)} · ${p.baseUrl}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Switch(checked = p.enabled, onCheckedChange = { vm.setProviderEnabled(p, it) })
            }

            Text(
                "${if (isFa) "کلیدها" else "API Keys"} (${keys.size})",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
            )
            keys.forEach { k -> KeyRow(k, tests[k.id], vm, isFa) }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onAddKey, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Default.Add, contentDescription = null, Modifier.size(16.dp))
                    Text(if (isFa) "افزودن کلید" else "Add Key", Modifier.padding(start = 4.dp))
                }
                OutlinedButton(onClick = { showModels = !showModels }, modifier = Modifier.weight(1f)) {
                    Text(if (showModels) (if (isFa) "بستن مدل‌ها" else "Hide Models") else (if (isFa) "مشاهده مدل‌ها" else "Show Models"))
                }
            }

            if (showModels) {
                HorizontalDivider(Modifier.padding(vertical = 4.dp))
                Text(
                    "${if (isFa) "مدل‌های فعال" else "Active Models"} (${models.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                )
                models.forEach { m ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(m.modelName, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium)
                            Text(
                                listOfNotNull(
                                    "Text".takeIf { m.supportsText },
                                    "Vision/OCR".takeIf { m.supportsVision },
                                    "TTS".takeIf { m.supportsTts },
                                ).joinToString(" · "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                        Switch(checked = m.enabled, onCheckedChange = { vm.setModelEnabled(m, it) })
                    }
                }
            }
        }
    }
}

@Composable
private fun KeyRow(k: ApiKeyEntity, testMessage: String?, vm: AiViewModel, isFa: Boolean) {
    var reveal by remember { mutableStateOf(false) }
    val plain = remember(k.secret) { try { SecretBox.decrypt(k.secret) } catch (e: Exception) { "" } }
    val masked = if (plain.length > 8) "••••••••" + plain.takeLast(4) else "••••••••"
    val st = effectiveStatus(k, System.currentTimeMillis())

    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text(k.label, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (st == KeyStatus.ACTIVE.name) Color(0xFF2E7D32).copy(alpha = 0.2f) else MaterialTheme.colorScheme.errorContainer,
                ) {
                    Text(
                        statusLabel(st, isFa),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        color = if (st == KeyStatus.ACTIVE.name) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                    )
                }
            }

            Text(
                if (reveal) plain.ifEmpty { "(key unavailable)" } else masked,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { reveal = !reveal }) {
                    Text(if (reveal) (if (isFa) "مخفی" else "Hide") else (if (isFa) "نمایش" else "Reveal"), fontSize = 12.sp)
                }
                TextButton(onClick = { vm.testKey(k) }) {
                    Text(if (isFa) "تست اتصال" else "Test", fontSize = 12.sp)
                }
                TextButton(onClick = { vm.setKeyDisabled(k, k.status != KeyStatus.DISABLED.name) }) {
                    Text(if (k.status == KeyStatus.DISABLED.name) (if (isFa) "فعال‌سازی" else "Enable") else (if (isFa) "غیرفعال" else "Disable"), fontSize = 12.sp)
                }
                TextButton(onClick = { vm.deleteKey(k) }) {
                    Text(if (isFa) "حذف" else "Delete", fontSize = 12.sp, color = MaterialTheme.colorScheme.error)
                }
            }

            if (testMessage != null) {
                Text(
                    testMessage,
                    style = MaterialTheme.typography.bodySmall,
                    color = if (testMessage.contains("موفق") || testMessage.contains("OK")) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                )
            }
        }
    }
}

@Composable
private fun LangRow(selected: String, options: List<Lang>, onSelect: (String) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEach { lang ->
            FilterChip(
                selected = selected == lang.code,
                onClick = { onSelect(lang.code) },
                label = { Text(lang.label) },
            )
        }
    }
}

@Composable
private fun ModelManageRow(
    m: ModelEntity,
    index: Int,
    isFa: Boolean,
    appLang: String,
    costLabel: String,
    onToggle: (Boolean) -> Unit,
    onDelete: () -> Unit,
    onMoveUp: () -> Unit,
    onMoveDown: () -> Unit,
) {
    Surface(
        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
    ) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                    Text(
                        (index + 1).localize(appLang),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.width(8.dp))
                Text(m.modelName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                Switch(checked = m.enabled, onCheckedChange = onToggle)
            }
            Text(costLabel, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                TextButton(onClick = onMoveUp) { Text("↑") }
                TextButton(onClick = onMoveDown) { Text("↓") }
                TextButton(onClick = onDelete) { Text(if (isFa) "حذف" else "Delete") }
            }
        }
    }
}

@Composable
private fun AddModelDialog(
    isFa: Boolean,
    ttsMode: Boolean,
    onDismiss: () -> Unit,
    onAdd: (name: String, text: Boolean, vision: Boolean, tts: Boolean) -> Unit,
) {
    var name by remember { mutableStateOf("") }
    var text by remember { mutableStateOf(!ttsMode) }
    var vision by remember { mutableStateOf(!ttsMode) }
    var tts by remember { mutableStateOf(ttsMode) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isFa) (if (ttsMode) "افزودن مدل TTS" else "افزودن مدل متنی") else (if (ttsMode) "Add TTS model" else "Add text model")) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text(if (isFa) "شناسه مدل (دقیق، بدون حدس)" else "Exact model id (no guessing)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                if (!ttsMode) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = text, onCheckedChange = { text = it })
                        Text(if (isFa) "متن" else "Text")
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = vision, onCheckedChange = { vision = it })
                        Text(if (isFa) "تصویر / OCR" else "Vision / OCR")
                    }
                } else {
                    Text(if (isFa) "این مدل فقط برای TTS علامت می‌خورد." else "This model will be marked TTS-only.")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        if (ttsMode) onAdd(name.trim(), false, false, true)
                        else onAdd(name.trim(), text, vision, tts)
                    }
                },
            ) { Text(if (isFa) "افزودن" else "Add") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(if (isFa) "انصراف" else "Cancel") }
        },
    )
}

@Composable
private fun AddKeyDialog(onDismiss: () -> Unit, onAdd: (String, String) -> Unit) {
    var label by remember { mutableStateOf("") }
    var secret by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("افزودن کلید API") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = label,
                    onValueChange = { label = it },
                    label = { Text("نام یا برچسب کلید") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = secret,
                    onValueChange = { secret = it },
                    label = { Text("کلید API") },
                    visualTransformation = PasswordVisualTransformation(),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                )
            }
        },
        confirmButton = {
            Button(onClick = { if (secret.isNotBlank()) onAdd(label.ifBlank { "کلید" }, secret.trim()) }) {
                Text("ذخیره")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("انصراف") }
        },
    )
}
