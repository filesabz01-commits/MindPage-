package app.pdfreader.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.pdfreader.ai.AiAttemptEntity
import app.pdfreader.ui.l10n.LocalAppLanguage
import app.pdfreader.ui.l10n.LocalStrings
import app.pdfreader.ui.l10n.NumberFormatter
import app.pdfreader.ui.l10n.localize
import app.pdfreader.ui.l10n.localizeDigits
import java.time.LocalDate

private fun formatAttemptTime(ts: Long, lang: String = "fa"): String = NumberFormatter.formatDate(ts, lang)

private fun taskPersian(task: String): String = when (task.uppercase()) {
    "TRANSLATE" -> "ترجمه"
    "SUMMARIZE" -> "خلاصه‌سازی"
    "EXPLAIN" -> "چت / توضیح"
    "EXTRACT" -> "استخراج متن / OCR"
    "TTS" -> "صوت / TTS"
    else -> task
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsageScreen(vm: AiViewModel, onBack: () -> Unit) {
    val providers by vm.providers.collectAsStateWithLifecycle()
    val keys by vm.keys.collectAsStateWithLifecycle()
    val attempts by vm.attempts.collectAsStateWithLifecycle()
    val tokenTotals by vm.tokenTotals.collectAsStateWithLifecycle()
    val today = LocalDate.now().toString()
    val now = System.currentTimeMillis()
    val appLang = LocalAppLanguage.current
    val strings = LocalStrings.current

    var filter by remember { mutableStateOf("ALL") }

    val filteredAttempts = remember(attempts, filter) {
        when (filter) {
            "ERRORS" -> attempts.filter { it.outcome != "OK" }
            "TRANSLATE" -> attempts.filter { it.task.equals("TRANSLATE", ignoreCase = true) }
            "SUMMARIZE" -> attempts.filter { it.task.equals("SUMMARIZE", ignoreCase = true) }
            "EXPLAIN" -> attempts.filter { it.task.equals("EXPLAIN", ignoreCase = true) }
            "EXTRACT" -> attempts.filter { it.task.equals("EXTRACT", ignoreCase = true) }
            "TTS" -> attempts.filter { it.task.equals("TTS", ignoreCase = true) }
            else -> attempts
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (strings.isFa) "مصرف AI و تاریخچه تلاش‌ها" else "AI Usage & Attempt History") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = strings.back) }
                },
                actions = {
                    if (attempts.isNotEmpty()) {
                        IconButton(onClick = vm::clearAttempts) {
                            Icon(Icons.Default.Delete, contentDescription = strings.clear)
                        }
                    }
                },
            )
        },
    ) { pad ->
        LazyColumn(
            Modifier.padding(pad),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                val totalTokens = tokenTotals.promptTotal + tokenTotals.candidatesTotal + tokenTotals.thoughtsTotal
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
                ) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                if (strings.isFa) "مجموع کل توکن‌های مصرف‌شده" else "Total Tokens Consumed",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            )
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = MaterialTheme.colorScheme.primary,
                            ) {
                                Text(
                                    "${totalTokens.localize(appLang)} " + (if (strings.isFa) "توکن" else "tokens"),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                )
                            }
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Prompt", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.promptTotal).localizeDigits(appLang), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                            Column {
                                Text("Candidates", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.candidatesTotal).localizeDigits(appLang), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                            Column {
                                Text("Thoughts", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text("%,d".format(tokenTotals.thoughtsTotal).localizeDigits(appLang), style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                            }
                        }

                        val taskGroups = attempts.groupBy { it.task.uppercase() }
                        if (taskGroups.isNotEmpty()) {
                            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                            Text(if (strings.isFa) "مصرف بر اساس عملیات:" else "Usage by Task:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                taskGroups.forEach { (task, list) ->
                                    val taskTokens = list.sumOf { (it.promptTokens + it.candidatesTokens + it.thoughtsTokens).toLong() }
                                    SuggestionChip(
                                        onClick = {},
                                        label = { Text("${taskPersian(task)}: " + "%,d".format(taskTokens).localizeDigits(appLang)) },
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                val active = keys.count { effectiveStatus(it, now) == "ACTIVE" }
                val limited = keys.count { effectiveStatus(it, now).let { s -> s == "RATE_LIMITED" || s == "DAILY_QUOTA_EXCEEDED" } }
                val invalid = keys.count { it.status == "INVALID" }
                val last = keys.filter { it.lastUsedAt > 0 }.maxByOrNull { it.lastUsedAt }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(if (strings.isFa) "آمار کلیدها و درخواست‌های امروز" else "Today's Keys & Requests", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Text(if (strings.isFa) "درخواست‌های امروز: " + keys.filter { it.usageDay == today }.sumOf { it.requestsToday }.localize(appLang) else "Today requests: " + keys.filter { it.usageDay == today }.sumOf { it.requestsToday }.localize(appLang))
                        Text(if (strings.isFa) "خطاهای امروز: " + keys.filter { it.usageDay == today }.sumOf { it.errorsToday }.localize(appLang) else "Today errors: " + keys.filter { it.usageDay == today }.sumOf { it.errorsToday }.localize(appLang))
                        Text(if (strings.isFa) "کلیدهای فعال: ${active.localize(appLang)} · محدودشده: ${limited.localize(appLang)} · نامعتبر: ${invalid.localize(appLang)}" else "Active: ${active.localize(appLang)} · Limited: ${limited.localize(appLang)} · Invalid: ${invalid.localize(appLang)}")
                        Text(if (strings.isFa) "آخرین کلید استفاده‌شده: " + (last?.label ?: "—") else "Last used key: " + (last?.label ?: "—"))
                    }
                }
            }

            items(keys, key = { it.id }) { k ->
                val st = effectiveStatus(k, now)
                val wait = ((k.cooldownUntil - now) / 1000).coerceAtLeast(0)
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${providers.firstOrNull { it.id == k.providerId }?.name ?: "?"} · ${k.label}", style = MaterialTheme.typography.titleSmall)
                        Text(if (strings.isFa) "وضعیت: ${statusLabel(st, true)}" else "Status: ${statusLabel(st, false)}")
                        Text(if (strings.isFa) "درخواست امروز: ${(if (k.usageDay == today) k.requestsToday else 0).localize(appLang)} · خطا: ${(if (k.usageDay == today) k.errorsToday else 0).localize(appLang)}" else "Today: ${(if (k.usageDay == today) k.requestsToday else 0).localize(appLang)} req · ${(if (k.usageDay == today) k.errorsToday else 0).localize(appLang)} err")
                        if (wait > 0) Text(if (strings.isFa) "زمان باقی‌مانده‌ی محدودیت: ${formatWait(wait)}" else "Cooldown remaining: ${formatWait(wait)}")
                        k.lastError?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                    }
                }
            }

            item {
                HorizontalDivider(modifier = Modifier.padding(top = 8.dp))
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        if (strings.isFa) "لاگ تلاش‌های اخیر (${filteredAttempts.size.localize(appLang)})" else "Recent Attempts (${filteredAttempts.size.localize(appLang)})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    )
                    if (attempts.isNotEmpty()) {
                        TextButton(onClick = vm::clearAttempts) {
                            Text(strings.clear, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }

                Row(
                    Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    FilterChip(selected = filter == "ALL", onClick = { filter = "ALL" }, label = { Text(if (strings.isFa) "همه" else "All") })
                    FilterChip(selected = filter == "TRANSLATE", onClick = { filter = "TRANSLATE" }, label = { Text(if (strings.isFa) "ترجمه" else "Translate") })
                    FilterChip(selected = filter == "SUMMARIZE", onClick = { filter = "SUMMARIZE" }, label = { Text(if (strings.isFa) "خلاصه" else "Summarize") })
                    FilterChip(selected = filter == "EXPLAIN", onClick = { filter = "EXPLAIN" }, label = { Text(if (strings.isFa) "چت / توضیح" else "Explain") })
                    FilterChip(selected = filter == "EXTRACT", onClick = { filter = "EXTRACT" }, label = { Text(if (strings.isFa) "استخراج / OCR" else "OCR") })
                    FilterChip(selected = filter == "TTS", onClick = { filter = "TTS" }, label = { Text("TTS") })
                    FilterChip(selected = filter == "ERRORS", onClick = { filter = "ERRORS" }, label = { Text(if (strings.isFa) "فقط خطاها" else "Errors") })
                }
            }

            if (filteredAttempts.isEmpty()) {
                item {
                    Text(
                        if (strings.isFa) "هیچ تلاشی در این بخش ثبت نشده است." else "No attempts recorded yet.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp),
                    )
                }
            } else {
                items(filteredAttempts, key = { it.id }) { a ->
                    AttemptCard(a)
                }
            }
        }
    }
}

@Composable
private fun AttemptCard(a: AiAttemptEntity) {
    val isOk = a.outcome == "OK"
    val appLang = LocalAppLanguage.current
    val strings = LocalStrings.current

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isOk) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
            else MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.35f),
        ),
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                    ) {
                        Text(
                            taskPersian(a.task),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                        )
                    }
                    Text(a.model.removePrefix("gemini-"), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                }

                Surface(
                    shape = RoundedCornerShape(50),
                    color = if (isOk) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                ) {
                    Text(
                        if (isOk) (if (strings.isFa) "موفق" else "OK") else a.outcome,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color.White,
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text("${if (strings.isFa) "کلید" else "Key"}: ${a.keyLabel}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(formatAttemptTime(a.timestamp, appLang), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                Text(
                    if (strings.isFa) "اولین بایت: ${a.timeToFirstByteMs.localize(appLang)}ms · کل: ${a.totalTimeMs.localize(appLang)}ms"
                    else "TTFB: ${a.timeToFirstByteMs.localize(appLang)}ms · Total: ${a.totalTimeMs.localize(appLang)}ms",
                    style = MaterialTheme.typography.bodySmall,
                )
                if (isOk) {
                    Text(
                        if (strings.isFa) "توکن: ${a.promptTokens.localize(appLang)} ورودی | ${a.candidatesTokens.localize(appLang)} خروجی" + (if (a.thoughtsTokens > 0) " | ${a.thoughtsTokens.localize(appLang)} فکر" else "")
                        else "Tokens: ${a.promptTokens.localize(appLang)} in | ${a.candidatesTokens.localize(appLang)} out" + (if (a.thoughtsTokens > 0) " | ${a.thoughtsTokens.localize(appLang)} thoughts" else ""),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }

            a.errorMessage?.takeIf { it.isNotBlank() }?.let { err ->
                Text("${if (strings.isFa) "علت" else "Error"}: $err", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}