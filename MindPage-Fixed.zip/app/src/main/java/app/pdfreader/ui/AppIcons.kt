package app.pdfreader.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Small, soft, hand-drawn icons (no emoji): the same look on every phone and every language. */
enum class AppIcon { Speaker, ReadTranslate, Globe, Summary, Sparkle, More, Explain, Ocr, Range, Play, Pause, Next, Prev, Sun, Moon, Rotate, Mic, Shelf, Profile, Vocab, Grammar, Quiz, Exercise, Study, BookFlip, ContinuousScroll, SinglePage }

@Composable
fun AppIconView(icon: AppIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 24.dp) {
    Canvas(modifier.size(size)) {
        val u = this.size.minDimension / 24f // everything is designed on a 24 x 24 grid
        val stroke = Stroke(width = 1.9f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * u, y * u)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, p(x1, y1), p(x2, y2), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
        when (icon) {
            AppIcon.Speaker -> {
                speaker(tint, u)
                arc(tint, u, 12f, 12f, 4.5f, stroke)
                arc(tint, u, 12f, 12f, 8f, stroke)
            }
            AppIcon.Globe -> globe(tint, u, 12f, 12f, 9f, stroke)
            AppIcon.ReadTranslate -> {
                globe(tint, u, 10f, 12f, 7f, stroke)
                arc(tint, u, 17f, 12f, 3f, stroke)
                arc(tint, u, 17f, 12f, 6f, stroke)
            }
            AppIcon.Summary -> {
                line(4f, 7f, 20f, 7f); line(4f, 12f, 16f, 12f); line(4f, 17f, 11f, 17f)
            }
            AppIcon.Sparkle -> {
                val path = Path().apply {
                    moveTo(12f * u, 2f * u)
                    cubicTo(12.8f * u, 8f * u, 16f * u, 11.2f * u, 22f * u, 12f * u)
                    cubicTo(16f * u, 12.8f * u, 12.8f * u, 16f * u, 12f * u, 22f * u)
                    cubicTo(11.2f * u, 16f * u, 8f * u, 12.8f * u, 2f * u, 12f * u)
                    cubicTo(8f * u, 11.2f * u, 11.2f * u, 8f * u, 12f * u, 2f * u)
                    close()
                }
                drawPath(path, tint, style = Fill)
            }
            AppIcon.More -> {
                drawCircle(tint, 1.9f * u, p(5f, 12f)); drawCircle(tint, 1.9f * u, p(12f, 12f)); drawCircle(tint, 1.9f * u, p(19f, 12f))
            }
            AppIcon.Explain -> {
                drawCircle(tint, 6f * u, p(12f, 10f), style = stroke)
                line(9.5f, 18f, 14.5f, 18f); line(10.5f, 21f, 13.5f, 21f)
            }
            AppIcon.Ocr -> {
                line(4f, 8f, 4f, 4f); line(4f, 4f, 8f, 4f)
                line(16f, 4f, 20f, 4f); line(20f, 4f, 20f, 8f)
                line(20f, 16f, 20f, 20f); line(20f, 20f, 16f, 20f)
                line(8f, 20f, 4f, 20f); line(4f, 20f, 4f, 16f)
                line(8f, 12f, 16f, 12f)
            }
            AppIcon.Range -> {
                drawRoundRect(tint, p(3f, 7f), Size(12f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(3f * u, 3f * u), style = stroke)
                drawRoundRect(tint, p(9f, 3f), Size(12f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(3f * u, 3f * u), style = stroke)
            }
            AppIcon.Play -> {
                val path = Path().apply { moveTo(8f * u, 5f * u); lineTo(19f * u, 12f * u); lineTo(8f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
            }
            AppIcon.Pause -> {
                val r = androidx.compose.ui.geometry.CornerRadius(1.5f * u, 1.5f * u)
                drawRoundRect(tint, p(6.5f, 5f), Size(4f * u, 14f * u), r)
                drawRoundRect(tint, p(13.5f, 5f), Size(4f * u, 14f * u), r)
            }
            AppIcon.Next -> {
                val path = Path().apply { moveTo(6f * u, 5f * u); lineTo(16f * u, 12f * u); lineTo(6f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
                drawRoundRect(tint, p(17f, 5f), Size(2.6f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(1.3f * u, 1.3f * u))
            }
            AppIcon.Sun -> {
                drawCircle(tint, 4.5f * u, p(12f, 12f), style = stroke)
                line(12f, 2f, 12f, 5.5f)
                line(12f, 18.5f, 12f, 22f)
                line(2f, 12f, 5.5f, 12f)
                line(18.5f, 12f, 22f, 12f)
                line(5f, 5f, 7.5f, 7.5f)
                line(16.5f, 16.5f, 19f, 19f)
                line(5f, 19f, 7.5f, 16.5f)
                line(16.5f, 7.5f, 19f, 5f)
            }
            AppIcon.Moon -> {
                val path = Path().apply {
                    moveTo(12.5f * u, 3f * u)
                    cubicTo(17.5f * u, 3.5f * u, 21f * u, 7.5f * u, 21f * u, 12f * u)
                    cubicTo(21f * u, 17f * u, 17f * u, 21f * u, 12f * u, 21f * u)
                    cubicTo(7.5f * u, 21f * u, 3.8f * u, 17.8f * u, 3.1f * u, 13.5f * u)
                    cubicTo(7.8f * u, 14.5f * u, 12.5f * u, 11.5f * u, 12.5f * u, 6.5f * u)
                    cubicTo(12.5f * u, 5.2f * u, 12.1f * u, 4f * u, 11.5f * u, 3.1f * u)
                    close()
                }
                drawPath(path, tint, style = stroke)
            }
            AppIcon.Rotate -> {
                // Sleek, modern screen rotation icon with phone glyph and circular arrow
                val r = 7.5f * u
                drawArc(
                    color = tint,
                    startAngle = 25f,
                    sweepAngle = 240f,
                    useCenter = false,
                    topLeft = p(12f - 7.5f, 12f - 7.5f),
                    size = Size(15f * u, 15f * u),
                    style = stroke
                )
                val arrow = Path().apply {
                    moveTo(18f * u, 4.5f * u)
                    lineTo(19.5f * u, 9.5f * u)
                    lineTo(14.8f * u, 8f * u)
                }
                drawPath(arrow, tint, style = stroke)
                drawRoundRect(
                    color = tint.copy(alpha = 0.7f),
                    topLeft = p(9.5f, 8.5f),
                    size = Size(5f * u, 7f * u),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(1.2f * u, 1.2f * u),
                    style = Stroke(width = 1.4f * u)
                )
            }
            AppIcon.Mic -> {
                drawRoundRect(tint, p(9f, 3.5f), Size(6f * u, 10.5f * u), androidx.compose.ui.geometry.CornerRadius(3f * u, 3f * u), style = stroke)
                drawArc(tint, 0f, 180f, false, topLeft = p(5.5f, 7.5f), size = Size(13f * u, 9.5f * u), style = stroke)
                line(12f, 17f, 12f, 21.5f)
                line(8f, 21.5f, 16f, 21.5f)
            }
            AppIcon.Shelf -> {
                line(2f, 11f, 22f, 11f)
                line(2f, 21f, 22f, 21f)
                drawRoundRect(tint, p(4f, 4f), Size(3.2f * u, 7f * u), androidx.compose.ui.geometry.CornerRadius(0.8f * u, 0.8f * u), style = stroke)
                drawRoundRect(tint, p(8.2f, 5f), Size(3.2f * u, 6f * u), androidx.compose.ui.geometry.CornerRadius(0.8f * u, 0.8f * u), style = stroke)
                drawRoundRect(tint, p(12.4f, 3.5f), Size(3.2f * u, 7.5f * u), androidx.compose.ui.geometry.CornerRadius(0.8f * u, 0.8f * u), style = stroke)
                drawRoundRect(tint, p(4.5f, 13.5f), Size(3.5f * u, 7.5f * u), androidx.compose.ui.geometry.CornerRadius(0.8f * u, 0.8f * u), style = stroke)
                drawRoundRect(tint, p(9f, 14.5f), Size(3.5f * u, 6.5f * u), androidx.compose.ui.geometry.CornerRadius(0.8f * u, 0.8f * u), style = stroke)
            }
            AppIcon.Profile -> {
                drawCircle(tint, 4f * u, p(12f, 7.5f), style = stroke)
                drawArc(tint, 180f, 180f, false, topLeft = p(4f, 12.5f), size = Size(16f * u, 12f * u), style = stroke)
            }
            AppIcon.Vocab -> {
                // dictionary / A-Z card
                drawRoundRect(tint, p(5f, 4f), Size(14f * u, 16f * u), androidx.compose.ui.geometry.CornerRadius(2f * u), style = stroke)
                line(8f, 8f, 16f, 8f)
                line(8f, 11f, 14f, 11f)
                line(8f, 14f, 12f, 14f)
                // small A
                line(10f, 17f, 12f, 13.5f); line(12f, 13.5f, 14f, 17f)
            }
            AppIcon.Grammar -> {
                // chat + abc
                drawRoundRect(tint, p(3f, 5f), Size(13f * u, 10f * u), androidx.compose.ui.geometry.CornerRadius(2.5f * u), style = stroke)
                line(6f, 8.5f, 13f, 8.5f); line(6f, 11.5f, 11f, 11.5f)
                val path = Path().apply {
                    moveTo(8f * u, 15f * u); lineTo(10f * u, 15f * u); lineTo(7f * u, 18f * u); close()
                }
                drawPath(path, tint, style = Fill)
                // tiny letters
                line(17f, 7f, 17f, 14f); line(19f, 7f, 19f, 14f); line(17f, 10.5f, 19f, 10.5f)
            }
            AppIcon.Quiz -> {
                // rounded badge with ?
                drawRoundRect(tint, p(5f, 3f), Size(14f * u, 18f * u), androidx.compose.ui.geometry.CornerRadius(3f * u), style = stroke)
                drawCircle(tint, 1.3f * u, p(12f, 16f))
                // question curve
                line(9f, 9f, 11f, 7.5f); line(11f, 7.5f, 14f, 8.5f); line(14f, 8.5f, 12f, 11f); line(12f, 11f, 12f, 13f)
            }
            AppIcon.Exercise -> {
                // checklist with check
                drawRoundRect(tint, p(4f, 4f), Size(16f * u, 16f * u), androidx.compose.ui.geometry.CornerRadius(2f * u), style = stroke)
                line(7f, 9f, 10f, 12f); line(10f, 12f, 15f, 7f)
                line(7f, 16f, 17f, 16f)
            }
            AppIcon.Study -> {
                // graduation mortarboard (distinct from open-book page-flip icons)
                val board = Path().apply {
                    moveTo(3f * u, 11f * u)
                    lineTo(12f * u, 6f * u)
                    lineTo(21f * u, 11f * u)
                    lineTo(12f * u, 16f * u)
                    close()
                }
                drawPath(board, tint, style = stroke)
                // tassel
                line(18f, 12f, 18f, 18f)
                drawCircle(tint, 1.4f * u, p(18f, 19f))
                // head base
                line(8f, 15.5f, 16f, 15.5f)
            }
            AppIcon.Prev -> {
                val path = Path().apply { moveTo(18f * u, 5f * u); lineTo(8f * u, 12f * u); lineTo(18f * u, 19f * u); close() }
                drawPath(path, tint, style = Fill)
                drawRoundRect(tint, p(4.4f, 5f), Size(2.6f * u, 14f * u), androidx.compose.ui.geometry.CornerRadius(1.3f * u, 1.3f * u))
            }
            AppIcon.BookFlip -> {
                val left = Path().apply {
                    moveTo(3.5f * u, 6f * u)
                    quadraticTo(7.5f * u, 4.5f * u, 12f * u, 6.5f * u)
                    lineTo(12f * u, 19.5f * u)
                    quadraticTo(7.5f * u, 17.5f * u, 3.5f * u, 19f * u)
                    close()
                }
                val right = Path().apply {
                    moveTo(20.5f * u, 6f * u)
                    quadraticTo(16.5f * u, 4.5f * u, 12f * u, 6.5f * u)
                    lineTo(12f * u, 19.5f * u)
                    quadraticTo(16.5f * u, 17.5f * u, 20.5f * u, 19f * u)
                    close()
                }
                drawPath(left, tint, style = stroke)
                drawPath(right, tint, style = stroke)
                line(12f, 6.5f, 12f, 19.5f)
            }
            AppIcon.ContinuousScroll -> {
                drawRoundRect(tint, p(5f, 3.5f), Size(14f * u, 7.5f * u), androidx.compose.ui.geometry.CornerRadius(2f * u), style = stroke)
                drawRoundRect(tint, p(5f, 13f), Size(14f * u, 7.5f * u), androidx.compose.ui.geometry.CornerRadius(2f * u), style = stroke)
                line(8f, 7.2f, 16f, 7.2f)
                line(8f, 16.7f, 16f, 16.7f)
            }
            AppIcon.SinglePage -> {
                val path = Path().apply {
                    moveTo(5.5f * u, 3.5f * u)
                    lineTo(14.5f * u, 3.5f * u)
                    lineTo(18.5f * u, 7.5f * u)
                    lineTo(18.5f * u, 20.5f * u)
                    lineTo(5.5f * u, 20.5f * u)
                    close()
                }
                drawPath(path, tint, style = stroke)
                line(14.5f, 3.5f, 14.5f, 7.5f)
                line(14.5f, 7.5f, 18.5f, 7.5f)
                line(8.5f, 11.5f, 15.5f, 11.5f)
                line(8.5f, 15f, 15.5f, 15f)
            }
        }
    }
}

private fun DrawScope.speaker(tint: Color, u: Float) {
    val path = Path().apply {
        moveTo(3f * u, 9.5f * u); lineTo(7f * u, 9.5f * u); lineTo(12f * u, 5f * u)
        lineTo(12f * u, 19f * u); lineTo(7f * u, 14.5f * u); lineTo(3f * u, 14.5f * u); close()
    }
    drawPath(path, tint, style = Fill)
}

/** A sound wave: an arc on the right of the point (cx, cy). */
private fun DrawScope.arc(tint: Color, u: Float, cx: Float, cy: Float, r: Float, stroke: Stroke) {
    drawArc(
        color = tint, startAngle = -40f, sweepAngle = 80f, useCenter = false,
        topLeft = Offset((cx - r + 4f) * u, (cy - r) * u), size = Size(2 * r * u, 2 * r * u), style = stroke,
    )
}

private fun DrawScope.globe(tint: Color, u: Float, cx: Float, cy: Float, r: Float, stroke: Stroke) {
    drawCircle(tint, r * u, Offset(cx * u, cy * u), style = stroke)
    drawOval(tint, Offset((cx - r * 0.42f) * u, (cy - r) * u), Size(r * 0.84f * u, 2 * r * u), style = stroke)
    drawLine(tint, Offset((cx - r) * u, cy * u), Offset((cx + r) * u, cy * u), strokeWidth = 1.9f * u, cap = StrokeCap.Round)
}
