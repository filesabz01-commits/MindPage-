package app.pdfreader.ui

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.pdfreader.ui.l10n.AppStrings
import app.pdfreader.ui.l10n.LocalAppLanguage
import app.pdfreader.ui.l10n.LocalStrings

// Warm, soft palette: cream paper in light mode, warm charcoal in dark mode, one orange accent.
private val LightColors = lightColorScheme(
    primary = Color(0xFFD9622B),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDCC9),
    onPrimaryContainer = Color(0xFF3A1200),
    secondary = Color(0xFF8A6D3B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF3E3C3),
    onSecondaryContainer = Color(0xFF2B1D00),
    tertiary = Color(0xFF5E7A4E),
    background = Color(0xFFFAF4EA),
    surface = Color(0xFFFFFBF5),
    surfaceVariant = Color(0xFFF1E7D8),
    onSurface = Color(0xFF211A14),
    onSurfaceVariant = Color(0xFF51453A),
    outline = Color(0xFF85766A),
    outlineVariant = Color(0xFFD8C9B8),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFF08A52),
    onPrimary = Color(0xFF3A1200),
    primaryContainer = Color(0xFF6B2F10),
    onPrimaryContainer = Color(0xFFFFDCC9),
    secondary = Color(0xFFE0C28A),
    onSecondary = Color(0xFF3F2E00),
    secondaryContainer = Color(0xFF58441A),
    onSecondaryContainer = Color(0xFFF3E3C3),
    tertiary = Color(0xFFABC99A),
    background = Color(0xFF1B1917),
    surface = Color(0xFF242220),
    surfaceVariant = Color(0xFF34302C),
    onSurface = Color(0xFFEDE3D8),
    onSurfaceVariant = Color(0xFFCFC3B6),
    outline = Color(0xFF9A8D80),
    outlineVariant = Color(0xFF4A443E),
)

private val BaseType = Typography()

// Roomier text: Persian and English paragraphs stay readable on a phone.
private val PersianFont = FontFamily.SansSerif
private val AppTypography = Typography(
    headlineSmall = BaseType.headlineSmall.copy(fontFamily = PersianFont, fontWeight = FontWeight.Bold, letterSpacing = (-0.2).sp),
    titleLarge = BaseType.titleLarge.copy(fontFamily = PersianFont, fontWeight = FontWeight.Bold, letterSpacing = (-0.1).sp),
    titleMedium = BaseType.titleMedium.copy(fontFamily = PersianFont, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 26.sp),
    titleSmall = BaseType.titleSmall.copy(fontFamily = PersianFont, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = BaseType.bodyLarge.copy(fontFamily = PersianFont, fontSize = 16.5.sp, lineHeight = 28.sp),
    bodyMedium = BaseType.bodyMedium.copy(fontFamily = PersianFont, fontSize = 14.5.sp, lineHeight = 24.sp),
    bodySmall = BaseType.bodySmall.copy(fontFamily = PersianFont, fontSize = 12.5.sp, lineHeight = 19.sp),
    labelLarge = BaseType.labelLarge.copy(fontFamily = PersianFont, fontWeight = FontWeight.SemiBold),
    labelMedium = BaseType.labelMedium.copy(fontFamily = PersianFont, fontWeight = FontWeight.Medium),
    labelSmall = BaseType.labelSmall.copy(fontFamily = PersianFont, fontWeight = FontWeight.Medium),
)

private val AppShapes = Shapes(
    extraSmall = RoundedCornerShape(14.dp),
    small = RoundedCornerShape(18.dp),
    medium = RoundedCornerShape(24.dp),
    large = RoundedCornerShape(30.dp),
    extraLarge = RoundedCornerShape(40.dp),
)

@Composable
fun ReaderTheme(
    appLanguage: String = "fa",
    content: @Composable () -> Unit,
) {
    val isRtl = appLanguage == "fa"
    val direction = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val strings = AppStrings.get(appLanguage)

    CompositionLocalProvider(
        LocalLayoutDirection provides direction,
        LocalAppLanguage provides appLanguage,
        LocalStrings provides strings,
    ) {
        MaterialTheme(
            colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors,
            typography = AppTypography,
            shapes = AppShapes,
            content = content,
        )
    }
}
