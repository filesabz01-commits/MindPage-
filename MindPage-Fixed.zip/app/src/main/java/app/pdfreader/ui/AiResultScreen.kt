package app.pdfreader.ui

import android.content.Intent
import app.pdfreader.ui.l10n.LocalStrings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import app.pdfreader.ai.AiTask
import java.io.File
import kotlinx.coroutines.delay

/**
 * Reusable, animated Full-Screen / Modal Result Dialog/Screen component for displaying
 * AI-generated outputs (Summary, OCR, Page Explanation, Translation).
 *
 * Requirements:
 * 1. Animation: Smooth enter/exit transition using Jetpack Compose AnimatedVisibility
 *    (slide in from bottom + fade in, and slide out to bottom + fade out).
 * 2. UI Layout:
 *    - Top App Bar with a clear dynamic title, Copy text button, and Close (✕) button.
 *    - Body: Scrollable container (verticalScroll) supporting clean typography and markdown-like formatting.
 *    - Loading State: Shimmer skeleton placeholder animation while data is being fetched.
 * 3. Styling: Material 3 design, rounded top corners (28.dp), matching dark/light theme surfaces.
 */
@Composable
fun AiResultScreen(
    visible: Boolean,
    title: String,
    content: String,
    isLoading: Boolean = false,
    loadingPhase: String = "",
    currentModel: String = "",
    elapsedSeconds: Int = 0,
    isRtl: Boolean = true,
    originalText: String? = null,
    bilingual: Boolean = false,
    onBilingualChange: ((Boolean) -> Unit)? = null,
    onDismiss: () -> Unit,
    onRetry: (() -> Unit)? = null,
    onCancel: (() -> Unit)? = null,
    handoutPdfPath: String? = null,
    modifier: Modifier = Modifier,
) {
    val clipboard = LocalClipboardManager.current
    val context = LocalContext.current
    var copied by remember { mutableStateOf(false) }

    LaunchedEffect(copied) {
        if (copied) {
            delay(2000L)
            copied = false
        }
    }

    // Modal Scrim + Animated Bottom Sheet/Screen
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(250)),
        exit = fadeOut(tween(200)),
        modifier = modifier.fillMaxSize(),
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onDismiss,
                ),
            contentAlignment = Alignment.BottomCenter,
        ) {
            AnimatedVisibility(
                visible = visible,
                enter = slideInVertically(initialOffsetY = { it }, animationSpec = tween(300)) + fadeIn(tween(200)),
                exit = slideOutVertically(targetOffsetY = { it }, animationSpec = tween(250)) + fadeOut(tween(180)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(top = 36.dp)
                        .clickable(
                            interactionSource = remember { MutableInteractionSource() },
                            indication = null,
                            onClick = {}, // Catch clicks inside surface
                        ),
                    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shadowElevation = 24.dp,
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .navigationBarsPadding(),
                    ) {
                        // Drag Handle Pill
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .padding(top = 12.dp, bottom = 4.dp)
                                .size(width = 36.dp, height = 4.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f))
                        )

                        // Top App Bar
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                        ) {
                            // Title & Task Badge
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f),
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.size(36.dp),
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        AppIconView(
                                            icon = AppIcon.Sparkle,
                                            tint = MaterialTheme.colorScheme.primary,
                                            size = 20.dp,
                                        )
                                    }
                                }
                                Column {
                                    Text(
                                        text = title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface,
                                        maxLines = 1,
                                    )
                                    if (currentModel.isNotBlank()) {
                                        Text(
                                            text = currentModel,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.primary,
                                        )
                                    }
                                }
                            }

                            // Actions: Copy & Close Button
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                            ) {
                                if (!isLoading && content.isNotBlank()) {
                                    FilledTonalButton(
                                        onClick = {
                                            clipboard.setText(AnnotatedString(content))
                                            copied = true
                                        },
                                        shape = RoundedCornerShape(14.dp),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(
                                            horizontal = 12.dp,
                                            vertical = 4.dp,
                                        ),
                                    ) {
                                        Text(
                                            text = if (copied) "کپی شد ✓" else "کپی",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                        )
                                    }
                                }

                                // Close Button (✕)
                                IconButton(
                                    onClick = onDismiss,
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)),
                                ) {
                                    Text(
                                        text = "✕",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                }
                            }
                        }

                        // Bilingual Toggle Switch (if applicable)
                        if (originalText != null && onBilingualChange != null) {
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                ) {
                                    Text(
                                        text = "نمایش متن اصلی در کنار ترجمه",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    )
                                    Switch(
                                        checked = bilingual,
                                        onCheckedChange = onBilingualChange,
                                    )
                                }
                            }
                        }

                        // Body Container (Scrollable)
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp),
                        ) {
                            if (isLoading) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .verticalScroll(rememberScrollState())
                                        .padding(vertical = 12.dp),
                                    verticalArrangement = Arrangement.spacedBy(16.dp),
                                ) {
                                    // Progress info card
                                    Surface(
                                        shape = RoundedCornerShape(18.dp),
                                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                                        modifier = Modifier.fillMaxWidth(),
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(14.dp),
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        ) {
                                            CircularProgressIndicator(
                                                modifier = Modifier.size(24.dp),
                                                strokeWidth = 2.5.dp,
                                                color = MaterialTheme.colorScheme.primary,
                                            )
                                            Column {
                                                Text(
                                                    text = loadingPhase,
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    fontWeight = FontWeight.SemiBold,
                                                )
                                                Text(
                                                    text = "${elapsedSeconds} ثانیه سپری شده",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                                )
                                            }
                                        }
                                    }

                                    // Shimmer Skeleton Placeholder
                                    AiShimmerSkeleton()

                                    if (onCancel != null) {
                                        OutlinedButton(
                                            onClick = onCancel,
                                            modifier = Modifier.align(Alignment.CenterHorizontally),
                                            shape = RoundedCornerShape(14.dp),
                                        ) {
                                            Text("لغو درخواست", style = MaterialTheme.typography.labelMedium)
                                        }
                                    }
                                }
                            } else {
                                SelectionContainer {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxSize()
                                            .verticalScroll(rememberScrollState())
                                            .padding(vertical = 12.dp),
                                        verticalArrangement = Arrangement.spacedBy(12.dp),
                                    ) {
                                        if (bilingual && originalText != null) {
                                            val str = LocalStrings.current
                                            Text(
                                                text = if (str.isFa) "متن اصلی:" else "Original text:",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                            )
                                            AiMarkdownBody(text = originalText, isRtl = false, isMuted = true)
                                            Spacer(Modifier.height(8.dp))
                                            Text(
                                                text = str.aiTranslationLabel,
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontWeight = FontWeight.Bold,
                                            )
                                        }

                                        AiMarkdownBody(text = content, isRtl = isRtl)
                                    }
                                }
                            }
                        }

                        // Bottom Action Footer Bar
                        if (!isLoading && (onRetry != null || handoutPdfPath != null)) {
                            Surface(
                                tonalElevation = 3.dp,
                                color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.95f),
                                modifier = Modifier.fillMaxWidth(),
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 16.dp, vertical = 10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    if (handoutPdfPath != null) {
                                        Button(
                                            onClick = {
                                                try {
                                                    val f = File(handoutPdfPath)
                                                    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", f)
                                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                                        setDataAndType(uri, "application/pdf")
                                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                                    }
                                                    context.startActivity(Intent.createChooser(intent, "باز کردن جزوه PDF"))
                                                } catch (_: Exception) {}
                                            },
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.weight(1f),
                                        ) {
                                            Text("مشاهده جزوه در ریدر", fontWeight = FontWeight.Bold)
                                        }
                                    }

                                    if (onRetry != null) {
                                        OutlinedButton(
                                            onClick = onRetry,
                                            shape = RoundedCornerShape(14.dp),
                                        ) {
                                            Text("تولید دوباره")
                                        }
                                    }

                                    TextButton(onClick = onDismiss) {
                                        Text("بستن")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

/**
 * Convenience overload that integrates directly with [AiUi] state from the app's ViewModel.
 */
@Composable
fun AiResultScreen(
    state: AiUi,
    bilingual: Boolean = false,
    onBilingualChange: (Boolean) -> Unit = {},
    onDismiss: () -> Unit,
    onRetry: ((AiUi.Done) -> Unit)? = null,
    onCancel: (() -> Unit)? = null,
    modifier: Modifier = Modifier,
) {
    if (state is AiUi.Idle) return

    val title = when (state) {
        is AiUi.Loading -> taskTitleFor(state.task, state.page, state.rangeTo)
        is AiUi.Streaming -> taskTitleFor(state.task, state.page, state.rangeTo)
        is AiUi.Done -> taskTitleFor(state.task, state.page, state.rangeTo)
        is AiUi.Error -> "خطا در پردازش"
        AiUi.Idle -> ""
    }

    val content = when (state) {
        is AiUi.Streaming -> state.text
        is AiUi.Done -> state.text
        is AiUi.Error -> state.message
        else -> ""
    }

    val isLoading = state is AiUi.Loading
    val isRtl = when (state) {
        is AiUi.Streaming -> state.rtl
        is AiUi.Done -> state.rtl
        else -> true
    }

    val originalText = when (state) {
        is AiUi.Streaming -> state.original
        is AiUi.Done -> state.original
        else -> null
    }

    val currentModel = when (state) {
        is AiUi.Loading -> state.currentModel
        is AiUi.Done -> state.model
        else -> ""
    }

    val phase = if (state is AiUi.Loading) state.phase else LocalStrings.current.aiProcessing
    val elapsed = if (state is AiUi.Loading) state.elapsedSeconds else 0
    val pdfPath = (state as? AiUi.Done)?.handoutPdfPath

    AiResultScreen(
        visible = true,
        title = title,
        content = content,
        isLoading = isLoading,
        loadingPhase = phase,
        currentModel = currentModel,
        elapsedSeconds = elapsed,
        isRtl = isRtl,
        originalText = originalText,
        bilingual = bilingual,
        onBilingualChange = onBilingualChange,
        onDismiss = onDismiss,
        onRetry = if (state is AiUi.Done && onRetry != null) { { onRetry(state) } } else null,
        onCancel = onCancel,
        handoutPdfPath = pdfPath,
        modifier = modifier,
    )
}

@Composable
private fun taskTitleFor(t: AiTask, page: Int, rangeTo: Int): String {
    val str = LocalStrings.current
    return when {
        rangeTo >= 0 -> str.taskTitleRangeSummary(page + 1, rangeTo + 1)
        t == AiTask.EXTRACT -> str.taskTitleExtract(page + 1)
        t == AiTask.TRANSLATE -> str.taskTitleTranslate(page + 1)
        t == AiTask.EXPLAIN -> str.taskTitleExplain(page + 1)
        else -> str.taskTitleSummary(page + 1)
    }
}

/**
 * Modern Shimmer Skeleton Animation for loading state.
 */
@Composable
fun AiShimmerSkeleton(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "shimmer_transition")
    val translateAnim by transition.animateFloat(
        initialValue = -300f,
        targetValue = 1200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1300, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
        ),
        label = "shimmer_translate",
    )

    val baseColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    val highlightColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.95f)

    val brush = Brush.linearGradient(
        colors = listOf(baseColor, highlightColor, baseColor),
        start = Offset(translateAnim, translateAnim),
        end = Offset(translateAnim + 260f, translateAnim + 260f),
    )

    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        Box(
            Modifier
                .fillMaxWidth(0.55f)
                .height(24.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.96f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.90f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.72f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )

        Spacer(Modifier.height(8.dp))
        Box(
            Modifier
                .fillMaxWidth(0.40f)
                .height(20.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.92f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.85f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )
        Box(
            Modifier
                .fillMaxWidth(0.58f)
                .height(16.dp)
                .clip(RoundedCornerShape(6.dp))
                .background(brush)
        )
    }
}


sealed interface AiContentBlock {
    data class Header(val text: String) : AiContentBlock
    data class Bullet(val text: String) : AiContentBlock
    data class Paragraph(val text: String) : AiContentBlock
    data class Table(val rows: List<List<String>>) : AiContentBlock
}

/** Pure parser — must NOT call any @Composable. */
private fun parseAiContentBlocks(text: String): List<AiContentBlock> {
    val blocks = mutableListOf<AiContentBlock>()
    val tableRows = mutableListOf<List<String>>()
    val sepRegex = Regex("^[|\\s:\\-]+$")

    fun flushTable() {
        if (tableRows.isNotEmpty()) {
            blocks.add(AiContentBlock.Table(tableRows.toList()))
            tableRows.clear()
        }
    }

    for (rawLine in text.lines()) {
        val line = rawLine.trim()
        val isTableLine = (line.startsWith("|") && line.indexOf('|', 1) >= 0) ||
            (line.contains("|") && line.split("|").count { it.trim().isNotEmpty() } >= 2)
        if (isTableLine) {
            if (sepRegex.matches(line)) {
                continue
            }
            val parts = line.split("|")
            val cells = parts.map { it.trim() }.filter { it.isNotEmpty() && !sepRegex.matches(it) }
            if (cells.isNotEmpty()) {
                tableRows.add(cells)
            }
            continue
        }
        flushTable()
        if (line.isBlank()) continue
        when {
            line.startsWith("#") -> {
                val clean = line.replace(Regex("^#+\\s*"), "")
                blocks.add(AiContentBlock.Header(clean))
            }
            line.startsWith("- ") || line.startsWith("* ") || line.startsWith("• ") -> {
                val bullet = if (line.startsWith("• ")) line.substring(2).trim() else line.substring(2).trim()
                blocks.add(AiContentBlock.Bullet(bullet))
            }
            else -> blocks.add(AiContentBlock.Paragraph(line))
        }
    }
    flushTable()
    return blocks
}

/**
 * Clean Markdown renderer with typography support for headings, bullets, tables, and paragraphs.
 */
@Composable
fun AiMarkdownBody(
    text: String,
    isRtl: Boolean,
    isMuted: Boolean = false,
    modifier: Modifier = Modifier,
) {
    val dir = if (isRtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    val textColor = if (isMuted) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface
    val blocks = remember(text) { parseAiContentBlocks(text) }

    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        Column(
            modifier = modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            for (block in blocks) {
                when (block) {
                    is AiContentBlock.Header -> {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        ) {
                            Text(
                                text = block.text,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            )
                        }
                    }
                    is AiContentBlock.Bullet -> {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(start = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                        ) {
                            Text(
                                text = "•",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                            )
                            Text(
                                text = block.text,
                                style = MaterialTheme.typography.bodyLarge,
                                color = textColor,
                                lineHeight = 26.sp,
                            )
                        }
                    }
                    is AiContentBlock.Paragraph -> {
                        Text(
                            text = block.text,
                            style = MaterialTheme.typography.bodyLarge,
                            color = textColor,
                            lineHeight = 27.sp,
                            textAlign = if (isRtl) TextAlign.Right else TextAlign.Left,
                        )
                    }
                    is AiContentBlock.Table -> {
                        AiMarkdownTable(rows = block.rows)
                    }
                }
            }
        }
    }
}

/**
 * Styled table for structured AI outputs.
 */
@Composable
fun AiMarkdownTable(rows: List<List<String>>) {
    if (rows.isEmpty()) return
    Surface(
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
    ) {
        Column(
            modifier = Modifier
                .horizontalScroll(rememberScrollState())
                .padding(8.dp),
        ) {
            rows.forEachIndexed { rowIndex, row ->
                val isHeader = rowIndex == 0
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(
                            if (isHeader) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                            else if (rowIndex % 2 == 1) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                            else Color.Transparent,
                        )
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                ) {
                    for (cell in row) {
                        Text(
                            text = cell,
                            style = if (isHeader) MaterialTheme.typography.labelLarge else MaterialTheme.typography.bodyMedium,
                            fontWeight = if (isHeader) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.width(120.dp),
                        )
                    }
                }
            }
        }
    }
}
