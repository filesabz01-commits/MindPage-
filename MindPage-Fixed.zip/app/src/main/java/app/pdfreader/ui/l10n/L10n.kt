package app.pdfreader.ui.l10n

import androidx.compose.runtime.compositionLocalOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Strict Number Localization utility.
 * Enforces requirement 7:
 * - When application language is English: all numbers use Western digits (0-9).
 * - When application language is Persian: all numbers use Persian digits (۰-۹).
 * Applies to dates, page numbers, counters, percentages, timestamps, and numerical labels.
 * Underlying values and API payloads remain unmutated; formatting occurs strictly at presentation layer.
 */
object NumberFormatter {

    fun toPersianDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                '0' -> sb.append('۰')
                '1' -> sb.append('۱')
                '2' -> sb.append('۲')
                '3' -> sb.append('۳')
                '4' -> sb.append('۴')
                '5' -> sb.append('۵')
                '6' -> sb.append('۶')
                '7' -> sb.append('۷')
                '8' -> sb.append('۸')
                '9' -> sb.append('۹')
                '%' -> sb.append('٪')
                ',' -> sb.append('،')
                '.' -> sb.append('٫')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun toWesternDigits(text: String): String {
        val sb = StringBuilder(text.length)
        for (ch in text) {
            when (ch) {
                '۰' -> sb.append('0')
                '۱' -> sb.append('1')
                '۲' -> sb.append('2')
                '۳' -> sb.append('3')
                '۴' -> sb.append('4')
                '۵' -> sb.append('5')
                '۶' -> sb.append('6')
                '۷' -> sb.append('7')
                '۸' -> sb.append('8')
                '۹' -> sb.append('9')
                '٪' -> sb.append('%')
                '،' -> sb.append(',')
                '٫' -> sb.append('.')
                else -> sb.append(ch)
            }
        }
        return sb.toString()
    }

    fun format(num: Long, lang: String): String =
        if (lang == "fa") toPersianDigits(num.toString()) else num.toString()

    fun format(num: Int, lang: String): String = format(num.toLong(), lang)

    fun format(num: Double, lang: String, decimals: Int = 1): String {
        val formatted = String.format(Locale.US, "%.${decimals}f", num)
        return if (lang == "fa") toPersianDigits(formatted) else formatted
    }

    fun formatPercent(percent: Int, lang: String): String =
        if (lang == "fa") "${toPersianDigits(percent.toString())}٪" else "$percent%"

    fun formatClock(ms: Long, lang: String): String {
        val totalSec = (ms / 1000).coerceAtLeast(0)
        val minutes = totalSec / 60
        val seconds = totalSec % 60
        val str = "%d:%02d".format(Locale.US, minutes, seconds)
        return if (lang == "fa") toPersianDigits(str) else str
    }

    fun formatSpeed(speed: Float, lang: String): String {
        val s = if (speed == speed.toInt().toFloat()) "${speed.toInt()}x" else "${speed}x"
        return if (lang == "fa") toPersianDigits(s) else s
    }

    fun formatBytes(bytes: Long, lang: String): String {
        val mb = bytes / (1024.0 * 1024.0)
        val s = if (mb >= 1.0) String.format(Locale.US, "%.1f MB", mb)
        else String.format(Locale.US, "%.0f KB", bytes / 1024.0)
        return if (lang == "fa") toPersianDigits(s) else s
    }

    fun formatDate(timestamp: Long, lang: String): String {
        if (timestamp <= 0) return "—"
        val sdf = SimpleDateFormat("HH:mm (MM/dd)", Locale.US)
        val str = sdf.format(Date(timestamp))
        return if (lang == "fa") toPersianDigits(str) else str
    }

    fun localizeString(text: String, lang: String): String =
        if (lang == "fa") toPersianDigits(text) else toWesternDigits(text)
}

fun Int.localize(lang: String): String = NumberFormatter.format(this, lang)
fun Long.localize(lang: String): String = NumberFormatter.format(this, lang)
fun Double.localize(lang: String, decimals: Int = 1): String = NumberFormatter.format(this, lang, decimals)
fun Float.localizeSpeed(lang: String): String = NumberFormatter.formatSpeed(this, lang)
fun String.localizeDigits(lang: String): String = NumberFormatter.localizeString(this, lang)

/**
 * Centralized Bilingual String Catalog.
 */
class AppStrings(val lang: String) {
    val isFa: Boolean = lang == "fa"

    val appName: String get() = "MindPage"
    val back: String get() = if (isFa) "بازگشت" else "Back"
    val ok: String get() = if (isFa) "تأیید" else "OK"
    val cancel: String get() = if (isFa) "انصراف" else "Cancel"
    val close: String get() = if (isFa) "بستن" else "Close"
    val delete: String get() = if (isFa) "حذف" else "Delete"
    val copied: String get() = if (isFa) "کپی شد" else "Copied"
    val copy: String get() = if (isFa) "کپی متن" else "Copy"
    val share: String get() = if (isFa) "اشتراک‌گذاری" else "Share"
    val search: String get() = if (isFa) "جستجو" else "Search"
    val clear: String get() = if (isFa) "پاک‌کردن" else "Clear"

    // Library
    val openPdf: String get() = if (isFa) "باز کردن PDF" else "Open PDF"
    val recent: String get() = if (isFa) "اخیر" else "Recent"
    val favorites: String get() = if (isFa) "مورد علاقه" else "Favorites"
    val resume: String get() = if (isFa) "ادامه مطالعه" else "Resume Reading"
    val emptyRecent: String get() = if (isFa) "هنوز فایلی باز نکرده‌اید. روی «باز کردن PDF» بزنید." else "No files opened yet. Tap 'Open PDF' to begin."
    val emptyFav: String get() = if (isFa) "فایل مورد علاقه‌ای ندارید." else "No favorite files."
    val removeFromList: String get() = if (isFa) "حذف از فهرست" else "Remove from list"
    fun pagesFmt(count: Int): String =
        if (isFa) "${count.localize("fa")} صفحه" else "${count.localize("en")} pages"
    fun pageOf(current: Int, total: Int): String =
        if (isFa) "صفحه ${current.localize("fa")} از ${total.localize("fa")}"
        else "Page ${current.localize("en")} of ${total.localize("en")}"
    fun readProgressFmt(page: Int, total: Int, percent: Int): String =
        if (isFa) "صفحه ${page.localize("fa")} از ${total.localize("fa")}  ·  ${percent.localize("fa")}٪ خوانده شده"
        else "Page ${page.localize("en")} of ${total.localize("en")}  ·  $percent% read"

    // Reader
    val goToPage: String get() = if (isFa) "رفتن به صفحه" else "Go to page"
    val pageNumber: String get() = if (isFa) "شماره صفحه" else "Page number"
    val dayNightMode: String get() = if (isFa) "حالت شب / روز" else "Day / Night Mode"
    val studyModeActive: String get() = if (isFa) "حالت مطالعه هوشمند MindPage" else "MindPage Smart Study Mode"

    // Settings
    val settingsTitle: String get() = if (isFa) "تنظیمات" else "Settings"
    fun highlightsNotes(count: Int): String =
        if (isFa) "هایلایت‌ها و یادداشت‌ها (${count.localize("fa")})"
        else "Highlights & Notes (${count.localize("en")})"
    val more: String get() = if (isFa) "بیشتر" else "More"
    val favorite: String get() = if (isFa) "علاقه‌مندی" else "Favorite"
    val emptyAnnots: String get() = if (isFa) "هنوز هایلایت یا یادداشتی ندارید. روی متن نگه دارید تا انتخاب شود." else "No highlights or notes yet. Long-press text to select."
    val catLanguage: String get() = if (isFa) "۱. زبان برنامه و محتوا" else "1. Language & Content"
    val catTranslation: String get() = if (isFa) "۲. موتور ترجمه" else "2. Translation Engine"
    val catApiKeys: String get() = if (isFa) "۳. تنظیمات کلیدهای API" else "3. Gemini API Keys"
    val catTextModels: String get() = if (isFa) "۴. مدل‌های متنی Gemini" else "4. Gemini Text Models"
    val catTtsPriority: String get() = if (isFa) "۵. اولویت مدل‌های صوتی Gemini" else "5. Gemini TTS Priority"
    val catVoiceRouting: String get() = if (isFa) "۶. صدا و مسیریابی هوشمند صوت" else "6. Voice & Smart Routing"
    val catAudioPlayback: String get() = if (isFa) "۷. تنظیمات پخش صوتی" else "7. Audio Playback Settings"
    val catPdfStorage: String get() = if (isFa) "۸. تنظیمات مطالعه و حافظه" else "8. Reading & Storage Preferences"

    val appLangLabel: String get() = if (isFa) "زبان رابط کاربری (App Language)" else "App Interface Language"
    val appLangDesc: String get() = if (isFa) "جهت چیدمان برنامه (RTL/LTR) و نمایش اعداد بر اساس این تنظیم تغییر می‌کند." else "Controls UI layout direction (RTL/LTR) and strict number localization."
    val langPersian: String get() = "فارسی (RTL - ارقام فارسی)"
    val langEnglish: String get() = "English (LTR - Western Digits)"

    val translationEngineLabel: String get() = if (isFa) "موتور ترجمه پیش‌فرض" else "Default Translation Engine"
    val googleEngineTitle: String get() = if (isFa) "Google Translate (سریع و بدون مصرف توکن)" else "Google Translate (Fast & Zero-Token)"
    val googleEngineDesc: String get() = if (isFa) "حفظ ساختار پاراگراف‌ها و جداول Markdown بدون هزینه API." else "Preserves paragraph and Markdown table structures with zero API cost."
    val aiEngineTitle: String get() = if (isFa) "Gemini AI (هوشمند و مبتنی بر متن)" else "Gemini AI (Contextual & Deep)"
    val aiEngineDesc: String get() = if (isFa) "ترجمه عمیق با سلسله‌مراتب مدل‌های بهینه و قابلیت تنزل خودکار." else "Deep translation using cost-optimized model hierarchy and automatic fallback."

    val pdfSourceLang: String get() = if (isFa) "زبان اصلی سند PDF" else "PDF Document Source Language"
    val targetLang: String get() = if (isFa) "زبان مقصد ترجمه و توضیح" else "Target Translation & Explanation Language"
    val handoutLang: String get() = if (isFa) "زبان جزوهٔ مرور" else "Handout Language"

    val hybridRoutingTitle: String get() = if (isFa) "معماری دوگانه هوشمند (Smart Hybrid TTS)" else "Smart Hybrid TTS Architecture"
    val hybridPersianRule: String get() = if (isFa) "متن‌های فارسی (اصلی یا ترجمه‌شده) منحصراً به Gemini TTS فرستاده می‌شوند و Edge TTS کاملاً دور زده می‌شود." else "Persian content (original or translated) is routed exclusively to Gemini TTS. Edge TTS is completely bypassed."
    val hybridForeignRule: String get() = if (isFa) "متن‌های خارجی (انگلیسی و...) مستقیماً به Edge TTS ارسال می‌شوند تا هزینه API کاهش یابد." else "Foreign language content is synthesized via native Edge TTS to minimize API spending."

    val textModelLadderTitle: String get() = if (isFa) "سلسله‌مراتب مدل‌های متنی (کم‌هزینه‌ترین در ابتدا)" else "Text Model Hierarchy (Cheapest First)"
    val ttsModelLadderTitle: String get() = if (isFa) "سلسله‌مراتب مدل‌های صوتی Gemini TTS" else "Gemini TTS Model Priority Order"
    val textModelPriorityDesc: String get() = if (isFa) "مدل‌های متنی — ارزان‌تر اول، در صورت خطا به بعدی می‌رود" else "Text models — cheapest first, automatic fallback on error"
    val ttsModelPriorityDesc: String get() = if (isFa) "اولویت مدل‌های صوتی Gemini TTS" else "Gemini TTS model priority order"
    val preferredModelLabel: String get() = if (isFa) "مدل متنی ترجیحی" else "Preferred Text Model"
    val preferredTtsLabel: String get() = if (isFa) "مدل صوتی ترجیحی" else "Preferred TTS Model"
    val autoCheapest: String get() = if (isFa) "خودکار (ارزان‌ترین در دسترس)" else "Auto (Cheapest Available)"

    // AI task titles & status
    val translating: String get() = if (isFa) "ترجمه" else "Translate"
    val summarizing: String get() = if (isFa) "خلاصه" else "Summary"
    val explaining: String get() = if (isFa) "توضیح" else "Explain"
    val extractingOcr: String get() = if (isFa) "استخراج متن (OCR)" else "Extract text (OCR)"
    fun taskTitleTranslate(page: Int): String =
        if (isFa) "ترجمه‌ی صفحه ${page.localize("fa")}" else "Translate page ${page.localize("en")}"
    fun taskTitleExplain(page: Int): String =
        if (isFa) "توضیح صفحه ${page.localize("fa")}" else "Explain page ${page.localize("en")}"
    fun taskTitleSummary(page: Int): String =
        if (isFa) "خلاصه‌ی صفحه ${page.localize("fa")}" else "Summary of page ${page.localize("en")}"
    fun taskTitleExtract(page: Int): String =
        if (isFa) "استخراج متن صفحه ${page.localize("fa")} (OCR)" else "Extract text page ${page.localize("en")} (OCR)"
    fun taskTitleRangeSummary(from: Int, to: Int): String =
        if (isFa) "خلاصه‌ی بازه‌ی صفحات ${from.localize("fa")} تا ${to.localize("fa")}"
        else "Summary of pages ${from.localize("en")}–${to.localize("en")}"
    val aiProcessing: String get() = if (isFa) "در حال پردازش هوش مصنوعی…" else "AI is processing…"
    val preparing: String get() = if (isFa) "در حال آماده‌سازی…" else "Preparing…"
    val processingText: String get() = if (isFa) "در حال پردازش متن…" else "Processing text…"
    val receiving: String get() = if (isFa) "در حال دریافت…" else "Receiving…"
    val testingKey: String get() = if (isFa) "در حال تست…" else "Testing…"
    val aiTranslationLabel: String get() = if (isFa) "ترجمه هوش مصنوعی:" else "AI translation:"
    val explainThisPage: String get() = if (isFa) "توضیح این صفحه" else "Explain this page"
    val extractPageOcr: String get() = if (isFa) "استخراج متن صفحه (OCR)" else "Extract page text (OCR)"
    val rangeSummary: String get() = if (isFa) "خلاصه‌ی بازه‌ی صفحه‌ها" else "Range summary"
    val fromPage: String get() = if (isFa) "از صفحه" else "From page"
    val toPage: String get() = if (isFa) "تا صفحه" else "To page"
    val save: String get() = if (isFa) "ذخیره" else "Save"

    val navRecent: String get() = if (isFa) "اخیر" else "Recent"
    val navShelf: String get() = if (isFa) "قفسه" else "Shelf"
    val navMe: String get() = if (isFa) "من" else "Me"
    val shelfTitle: String get() = if (isFa) "قفسه کتاب‌ها" else "Bookshelf"
    val profileTitle: String get() = if (isFa) "نمایه من" else "My Profile"
    val continueReading: String get() = if (isFa) "ادامه‌ی مطالعه" else "Continue reading"
    val resumeReading: String get() = if (isFa) "ادامه مطالعه" else "Resume"
    val emptyLibrary: String get() = if (isFa) "هنوز سندی باز نشده است.\nبرای شروع، یک فایل PDF انتخاب کنید." else "No documents yet.\nOpen a PDF to get started."
    val emptyShelf: String get() = if (isFa) "قفسه خالی است." else "Shelf is empty."
    val emptyFavorites: String get() = if (isFa) "هنوز کتابی به موردعلاقه‌ها اضافه نشده است." else "No favorites yet."
    fun elapsedSeconds(sec: Int): String =
        if (isFa) "${sec.localize("fa")} ثانیه سپری شده" else "${sec.localize("en")} s elapsed"
    val cancelRequest: String get() = if (isFa) "لغو درخواست" else "Cancel request"
    val googleTranslateError: String get() = if (isFa) "خطا در ارتباط با Google Translate" else "Google Translate connection error"

    val thinkingReply: String get() = if (isFa) "در حال اندیشیدن و تولید پاسخ…" else "Thinking and generating a reply…"
    val writingReply: String get() = if (isFa) "در حال نوشتن…" else "Writing…"
    val preparingReply: String get() = if (isFa) "در حال آماده‌سازی پاسخ…" else "Preparing reply…"
    val speakingReply: String get() = if (isFa) "دستیار در حال پاسخ صوتی است…" else "Assistant is speaking…"
    fun readingLabel(label: String): String =
        if (isFa) "در حال خواندن $label…" else "Reading $label…"
    fun readyToPlaySec(sec: Long): String =
        if (isFa) "آماده‌ی پخش: ${sec.localize("fa")} ثانیه" else "Ready to play: ${sec.localize("en")} s"
    val preparingAudio: String get() = if (isFa) "در حال آماده‌سازی…" else "Preparing…"
    fun preparingPage(page: Int): String =
        if (isFa) "در حال آماده‌سازی صفحه ${page.localize("fa")}…" else "Preparing page ${page.localize("en")}…"
    fun prepPageFailed(page: Int): String =
        if (isFa) "آماده‌سازی صفحه ${page.localize("fa")} ممکن نشد. دوباره تلاش کنید."
        else "Could not prepare page ${page.localize("en")}. Please try again."
    fun prepPageTimeout(page: Int): String =
        if (isFa) "آماده‌سازی صفحه ${page.localize("fa")} بیش از حد طول کشید."
        else "Preparing page ${page.localize("en")} took too long."
    val translatingParagraphs: String get() = if (isFa) "در حال ترجمه‌ی پاراگراف‌به‌پاراگراف…" else "Translating paragraph by paragraph…"
    val segmentTranslateFailed: String get() = if (isFa) "ترجمه‌ی قطعه‌ای ناموفق؛ در حال ترجمه‌ی یک‌جا…" else "Segment translation failed; translating in one pass…"
    val translatingForAudio: String get() = if (isFa) "در حال ترجمه برای تولید صدا…" else "Translating for speech synthesis…"
    val generatingGeminiVoice: String get() = if (isFa) "در حال تولید صدای Gemini…" else "Generating Gemini voice…"
    val prepPlaybackFailed: String get() = if (isFa) "آماده‌سازی پخش ناموفق بود." else "Could not prepare playback."
    fun checkingTextLayer(page: Int): String =
        if (isFa) "در حال بررسی لایه‌ی متنی صفحه ${page.localize("fa")}…"
        else "Checking text layer of page ${page.localize("en")}…"
    fun readingPageProgress(page: Int, cur: Int, total: Int): String =
        if (isFa) "در حال خواندن صفحه ${page.localize("fa")} (${cur.localize("fa")} از ${total.localize("fa")})…"
        else "Reading page ${page.localize("en")} (${cur.localize("en")} of ${total.localize("en")})…"
    fun generatingHandout(from: Int, to: Int): String =
        if (isFa) "در حال تولید جزوهٔ مرور هوشمند صفحات ${from.localize("fa")} تا ${to.localize("fa")}…"
        else "Generating smart review handout for pages ${from.localize("en")}–${to.localize("en")}…"
    val mergingHandout: String get() = if (isFa) "در حال ادغام نهایی جزوه…" else "Merging final handout…"
    val segmentTranslateError: String get() = if (isFa) "ترجمه‌ی قطعه‌ای ناموفق بود" else "Segment translation failed"

    val persistOcrTitle: String get() = if (isFa) "ذخیره‌سازی دائمی نتایج OCR" else "Persist OCR Results"
    val persistOcrDesc: String get() = if (isFa) "جلوگیری از اسکن مجدد صفحات تصویرپایه." else "Prevents redundant OCR scans of image-based pages."
    val bilingualTitle: String get() = if (isFa) "نمایش دوزبانه (متن اصلی کنار ترجمه)" else "Bilingual View (Original + Translation)"
    val highlightPdfTitle: String get() = if (isFa) "هایلایت هماهنگ متن در صفحه PDF" else "Synchronized PDF Text Highlighting"
    val hideFallbackTextTitle: String get() = if (isFa) "مخفی‌سازی متن صوتی در صورت عدم امکان هایلایت" else "Hide audio fallback text panel"

    val cacheSizeLabel: String get() = if (isFa) "حجم حافظه موقت متن و ترجمه‌ها" else "Text & Translation Cache Size"
    val audioCacheSizeLabel: String get() = if (isFa) "حجم فایل‌های صوتی تولیدشده" else "Synthesized Audio Cache Size"
    val clearCacheBtn: String get() = if (isFa) "پاک‌سازی حافظه کش" else "Clear Text Cache"
    val clearAudioBtn: String get() = if (isFa) "حذف فایل‌های صوتی" else "Clear Audio Files"
    val usageScreenBtn: String get() = if (isFa) "مشاهده گزارش و آمار مصرف API" else "View API Usage & Logs"

    companion object {
        private val fa = AppStrings("fa")
        private val en = AppStrings("en")
        fun get(lang: String): AppStrings = if (lang == "en") en else fa
    }
}

val LocalAppLanguage = compositionLocalOf { "fa" }
val LocalStrings = compositionLocalOf { AppStrings.get("fa") }
