// Room version policy: every version bump MUST add a Migration. Destructive fallback is not used for ai.db.
package app.pdfreader.ai

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import androidx.room.Upsert
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "providers")
data class ProviderEntity(
    @PrimaryKey val id: String,
    val name: String,
    val type: String,
    val baseUrl: String,
    val enabled: Boolean = true,
    val position: Int,
)

@Entity(tableName = "models")
data class ModelEntity(
    @PrimaryKey val id: String,
    val providerId: String,
    val modelName: String,
    val supportsText: Boolean,
    val supportsVision: Boolean,
    val enabled: Boolean = true,
    val position: Int,
    @ColumnInfo(defaultValue = "0") val supportsTts: Boolean = false,
) {
    fun supports(c: Capability) = when (c) {
        Capability.TEXT -> supportsText
        Capability.VISION -> supportsVision
        Capability.TTS -> supportsTts
    }
}

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey val id: String,
    val providerId: String,
    val label: String,
    /** AES-GCM ciphertext (Base64). Never the plain key. */
    val secret: String,
    val status: String = KeyStatus.ACTIVE.name,
    val cooldownUntil: Long = 0,
    val usageDay: String = "",
    val requestsToday: Int = 0,
    val errorsToday: Int = 0,
    val lastUsedAt: Long = 0,
    val lastError: String? = null,
    val position: Int,
)

@Entity(tableName = "ai_cache")
data class CacheEntity(
    @PrimaryKey val cacheKey: String,
    val text: String,
    val model: String,
    val createdAt: Long,
)

@Entity(tableName = "ai_attempts")
data class AiAttemptEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val task: String,
    val model: String,
    val keyLabel: String,
    val timeToFirstByteMs: Long,
    val totalTimeMs: Long,
    val outcome: String,
    val promptTokens: Int = 0,
    val candidatesTokens: Int = 0,
    val thoughtsTokens: Int = 0,
    val errorMessage: String? = null,
)

data class TokenTotalsTuple(
    val promptTotal: Long = 0,
    val candidatesTotal: Long = 0,
    val thoughtsTotal: Long = 0,
) {
    val promptTokens: Long get() = promptTotal
    val candidatesTokens: Long get() = candidatesTotal
    val thoughtsTokens: Long get() = thoughtsTotal
}

@Dao
interface AiDao {
    @Query("SELECT * FROM providers ORDER BY position") fun observeProviders(): Flow<List<ProviderEntity>>
    @Query("SELECT * FROM providers ORDER BY position") suspend fun providers(): List<ProviderEntity>
    @Query("SELECT * FROM providers WHERE id = :id") suspend fun provider(id: String): ProviderEntity?
    @Query("SELECT COUNT(*) FROM providers") suspend fun providerCount(): Int

    @Query("SELECT * FROM models ORDER BY position") fun observeModels(): Flow<List<ModelEntity>>
    @Query("SELECT * FROM models ORDER BY position") suspend fun models(): List<ModelEntity>

    @Query("SELECT * FROM api_keys ORDER BY position") fun observeKeys(): Flow<List<ApiKeyEntity>>
    @Query("SELECT * FROM api_keys WHERE providerId = :pid ORDER BY position") suspend fun keysFor(pid: String): List<ApiKeyEntity>
    @Query("SELECT * FROM api_keys WHERE id = :id") suspend fun key(id: String): ApiKeyEntity?
    @Query("UPDATE api_keys SET cooldownUntil = 0 WHERE cooldownUntil > 0 AND status != 'INVALID' AND status != 'DISABLED'") suspend fun clearCooldowns()

    @Upsert suspend fun upsertProvider(p: ProviderEntity)
    @Upsert suspend fun upsertModel(m: ModelEntity)
    @Upsert suspend fun upsertKey(k: ApiKeyEntity)

    @Query("DELETE FROM providers WHERE id = :id") suspend fun deleteProvider(id: String)
    @Query("DELETE FROM models WHERE providerId = :id") suspend fun deleteModelsOf(id: String)
    @Query("DELETE FROM api_keys WHERE providerId = :id") suspend fun deleteKeysOf(id: String)
    @Query("DELETE FROM models WHERE id = :id") suspend fun deleteModel(id: String)
    @Query("DELETE FROM api_keys WHERE id = :id") suspend fun deleteKey(id: String)

    @Query("SELECT * FROM ai_cache WHERE cacheKey = :k") suspend fun cached(k: String): CacheEntity?
    @Upsert suspend fun upsertCache(c: CacheEntity)
    @Query("SELECT COALESCE(SUM(LENGTH(text)), 0) FROM ai_cache") fun observeCacheBytes(): Flow<Long>
    @Query("DELETE FROM ai_cache") suspend fun clearCache()

    @Upsert suspend fun insertAttempt(a: AiAttemptEntity)
    @Query("SELECT * FROM ai_attempts ORDER BY timestamp DESC LIMIT 100") fun observeAttempts(): Flow<List<AiAttemptEntity>>
    @Query("SELECT * FROM ai_attempts ORDER BY timestamp DESC LIMIT 100") suspend fun attempts(): List<AiAttemptEntity>
    @Query("SELECT COALESCE(SUM(promptTokens), 0) AS promptTotal, COALESCE(SUM(candidatesTokens), 0) AS candidatesTotal, COALESCE(SUM(thoughtsTokens), 0) AS thoughtsTotal FROM ai_attempts")
    fun observeTokenTotals(): Flow<TokenTotalsTuple>
    @Query("DELETE FROM ai_attempts") suspend fun clearAttempts()
}

@Database(
    entities = [ProviderEntity::class, ModelEntity::class, ApiKeyEntity::class, CacheEntity::class, AiAttemptEntity::class],
    version = 3,
    exportSchema = false,
)
abstract class AiDatabase : RoomDatabase() {
    abstract fun aiDao(): AiDao
}

val MIGRATION_1_2 = object : Migration(1, 2) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE models ADD COLUMN supportsTts INTEGER NOT NULL DEFAULT 0")
    }
}

val MIGRATION_2_3 = object : Migration(2, 3) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE IF NOT EXISTS ai_attempts (
                id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                timestamp INTEGER NOT NULL,
                task TEXT NOT NULL,
                model TEXT NOT NULL,
                keyLabel TEXT NOT NULL,
                timeToFirstByteMs INTEGER NOT NULL,
                totalTimeMs INTEGER NOT NULL,
                outcome TEXT NOT NULL,
                promptTokens INTEGER NOT NULL DEFAULT 0,
                candidatesTokens INTEGER NOT NULL DEFAULT 0,
                thoughtsTokens INTEGER NOT NULL DEFAULT 0,
                errorMessage TEXT
            )
        """.trimIndent())
    }
}
