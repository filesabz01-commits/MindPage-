package app.pdfreader.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * Google Translate (no AI tokens) with structure preservation:
 * - paragraphs
 * - Markdown tables (| a | b |)
 * - space/tab-aligned multi-column rows detected as tables → emitted as Markdown tables
 * Applies the same localClean rules as AI path before translating.
 */
object GoogleTranslateService {

    private sealed class Block {
        class Para(val text: String) : Block()
        class Table(val rows: List<List<String>>) : Block()
    }

    /**
     * Translate full page text. Cleans junk first (same rules as AI translate),
     * keeps tables as Markdown tables after cell-wise translation.
     */
    suspend fun translate(text: String, sourceLang: String = "auto", targetLang: String = "fa"): String =
        withContext(Dispatchers.IO) {
            val cleaned = TextQuality.localClean(text).ifBlank { text.trim() }
            if (cleaned.isEmpty()) return@withContext ""
            // Promote loose multi-column lines (common in PDF text layer) into Markdown tables
            val structured = TextQuality.promoteTables(cleaned)
            val normalized = coalesceTableLines(structured)
            val blocks = splitBlocks(normalized)
            val out = mutableListOf<String>()
            for (b in blocks) {
                when (b) {
                    is Block.Para -> {
                        val t = b.text.trim()
                        if (t.isEmpty()) {
                            out += ""
                        } else {
                            out += translateParagraph(t, sourceLang, targetLang)
                        }
                    }
                    is Block.Table -> {
                        out += translateTable(b.rows, sourceLang, targetLang)
                    }
                }
            }
            out.joinToString("\n\n").trim()
        }

    private fun translateParagraph(text: String, sl: String, tl: String): String {
        if (text.length <= 2500) return translateChunk(text, sl, tl)
        val sentences = text.split(Regex("(?<=[.!?\\n])\\s+"))
        val chunk = StringBuilder()
        val parts = mutableListOf<String>()
        for (s in sentences) {
            if (chunk.length + s.length > 2000 && chunk.isNotEmpty()) {
                parts += translateChunk(chunk.toString(), sl, tl)
                chunk.clear()
            }
            if (chunk.isNotEmpty()) chunk.append(' ')
            chunk.append(s)
        }
        if (chunk.isNotEmpty()) parts += translateChunk(chunk.toString(), sl, tl)
        return parts.joinToString(" ")
    }

    private fun translateTable(rows: List<List<String>>, sl: String, tl: String): String {
        if (rows.isEmpty()) return ""
        val colCount = rows.maxOf { it.size }.coerceAtLeast(1)
        // Keep tag-like ids, pure numbers/units, and short codes untranslated so columns stay aligned.
        val keepAsIs = Regex(
            """^(?:[A-Z]{1,4}[\-\s]?\d{1,4}[A-Z]?(?:/[A-Z])?|[\d\.\,\+\-\u00D7x×\^\/\s]+(?:[A-Za-z°µ%Ω\/0-9]{0,12})?|[A-Z]{1,6}\.?)$"""
        )
        val translated = rows.map { row ->
            List(colCount) { c ->
                val cell = row.getOrElse(c) { "" }.trim()
                when {
                    cell.isEmpty() -> ""
                    keepAsIs.matches(cell) -> cell
                    cell.length <= 2 -> cell
                    else -> translateChunk(cell, sl, tl).replace("|", "/").trim()
                }
            }
        }
        val sb = StringBuilder()
        translated.forEachIndexed { i, row ->
            sb.append("| ").append(row.joinToString(" | ")).append(" |\n")
            if (i == 0) {
                sb.append("| ").append(List(colCount) { "---" }.joinToString(" | ")).append(" |\n")
            }
        }
        return sb.toString().trimEnd()
    }

    /**
     * If localClean emitted each table row as its own paragraph, group consecutive
     * table-like lines into one multi-line block so splitBlocks sees a real table.
     */
    private fun coalesceTableLines(text: String): String {
        val paras = text.split(Regex("\\n\\s*\\n"))
        val out = mutableListOf<String>()
        val buf = mutableListOf<String>()
        fun flushBuf() {
            if (buf.isEmpty()) return
            out += if (buf.size >= 2) buf.joinToString("\n") else buf[0]
            buf.clear()
        }
        for (p in paras) {
            val lines = p.trim().split('\n').map { it.trim() }.filter { it.isNotEmpty() }
            val allTable = lines.isNotEmpty() && lines.all { TextQuality.looksLikeTableRow(it) || it.startsWith("|") }
            if (allTable) {
                buf.addAll(lines)
            } else {
                flushBuf()
                out += p.trim()
            }
        }
        flushBuf()
        return out.filter { it.isNotBlank() }.joinToString("\n\n")
    }

    /** Split cleaned text into paragraph / table blocks. */
    private fun splitBlocks(text: String): List<Block> {
        val lines = text.replace("\r\n", "\n").split('\n')
        val blocks = mutableListOf<Block>()
        val para = StringBuilder()
        val tableRows = mutableListOf<List<String>>()

        fun flushPara() {
            val t = para.toString().trim()
            if (t.isNotEmpty()) blocks += Block.Para(t)
            para.clear()
        }

        fun flushTable() {
            if (tableRows.isNotEmpty()) {
                blocks += Block.Table(tableRows.toList())
                tableRows.clear()
            }
        }

        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            val md = parseMarkdownRow(line)
            if (md != null) {
                flushPara()
                // consume consecutive markdown rows (skip separator lines)
                while (i < lines.size) {
                    val r = parseMarkdownRow(lines[i])
                    if (r != null) {
                        tableRows += r
                        i++
                    } else if (isMarkdownSeparator(lines[i])) {
                        i++
                    } else break
                }
                flushTable()
                continue
            }

            // Space/tab aligned table: look ahead for ≥2 consecutive multi-column lines
            val cells = parseAlignedRow(line)
            if (cells != null && cells.size >= 2) {
                var j = i + 1
                val probe = mutableListOf(cells)
                while (j < lines.size) {
                    val next = parseAlignedRow(lines[j])
                    if (next != null && next.size >= 2) {
                        probe += next
                        j++
                    } else if (lines[j].isBlank()) {
                        break
                    } else break
                }
                if (probe.size >= 2) {
                    flushPara()
                    tableRows.addAll(probe)
                    flushTable()
                    i = j
                    continue
                }
            }

            if (line.isBlank()) {
                flushPara()
                // keep paragraph break
                if (blocks.isNotEmpty() && blocks.last() is Block.Para) {
                    // blank already separates paras via join
                }
            } else {
                if (para.isNotEmpty()) para.append('\n')
                para.append(line)
            }
            i++
        }
        flushPara()
        flushTable()
        return blocks
    }

    private fun isMarkdownSeparator(line: String): Boolean {
        val t = line.trim()
        return t.matches(Regex("^\\|?[\\s:\\-]+\\|([\\s:\\-]+\\|)*[\\s:\\-]*\\|?$"))
    }

    private fun parseMarkdownRow(line: String): List<String>? {
        val t = line.trim()
        if (!t.startsWith("|") || t.indexOf('|', startIndex = 1) < 0) return null
        if (isMarkdownSeparator(t)) return null
        val parts = t.trim('|').split("|").map { it.trim() }
        return if (parts.any { it.isNotEmpty() }) parts else null
    }

    /**
     * Detect rows with 2+ columns separated by tabs or 2+ spaces.
     * Ignores short single-token lines and pure list markers.
     */
    private fun parseAlignedRow(line: String): List<String>? {
        val t = line.trim()
        if (t.length < 3) return null
        if (t.startsWith("#") || t.startsWith("- ") || t.startsWith("* ") || t.startsWith("•")) return null
        if (t.contains('\t')) {
            val cells = t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            return if (cells.size >= 2) cells else null
        }
        // 2+ spaces as column gap
        val cells = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (cells.size >= 2) {
            // Avoid splitting normal sentences that happen to have double spaces
            // Heuristic: at least 2 cells and most cells are short (≤40 chars) OR ≥3 cells
            val shortish = cells.count { it.length <= 40 }
            if (cells.size >= 3 || shortish >= 2) return cells
        }
        return null
    }

    private fun translateChunk(chunk: String, sl: String, tl: String): String {
        val textToTranslate = chunk.trim()
        if (textToTranslate.isEmpty()) return ""

        val sLang = if (sl.isBlank() || sl == "auto") "auto" else sl
        val tLang = if (tl.isBlank()) "fa" else tl
        val encoded = URLEncoder.encode(textToTranslate, "UTF-8")
        val urlStr =
            "https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sLang&tl=$tLang&dt=t&q=$encoded"

        val conn = URL(urlStr).openConnection() as HttpURLConnection
        return try {
            conn.requestMethod = "GET"
            conn.connectTimeout = 12_000
            conn.readTimeout = 18_000
            conn.setRequestProperty(
                "User-Agent",
                "Mozilla/5.0 (Android; Mobile; rv:109.0) Gecko/109.0 Firefox/119.0",
            )
            val code = conn.responseCode
            if (code !in 200..299) throw IOException("Google Translate HTTP $code")
            val resp = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONArray(resp)
            val sentences = root.optJSONArray(0) ?: return textToTranslate
            val sb = StringBuilder()
            for (i in 0 until sentences.length()) {
                val part = sentences.optJSONArray(i) ?: continue
                val str = part.optString(0, "")
                if (str.isNotEmpty()) sb.append(str)
            }
            sb.toString().ifEmpty { textToTranslate }
        } finally {
            try {
                conn.disconnect()
            } catch (_: Exception) {
            }
        }
    }
}
