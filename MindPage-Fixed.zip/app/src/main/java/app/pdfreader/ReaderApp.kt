package app.pdfreader

import android.app.Application
import android.content.Context
import android.util.Log
import androidx.room.Room
import app.pdfreader.core.pdf.PdfEngine
import app.pdfreader.core.pdf.PdfRendererEngine
import app.pdfreader.ai.AiDatabase
import app.pdfreader.ai.AiRouter
import app.pdfreader.ai.MIGRATION_1_2
import app.pdfreader.ai.MIGRATION_2_3
import app.pdfreader.ai.GeminiProvider
import app.pdfreader.ai.OpenAiCompatProvider
import app.pdfreader.ai.PageTextService
import app.pdfreader.tts.PdfiumTextEngine
import app.pdfreader.tts.ReadAloudController
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.SettingsRepo
import app.pdfreader.data.AnnotationStore
import app.pdfreader.data.AppDatabase
import java.io.File

class AppContainer(context: Context) {
    val db: AppDatabase =
        Room.databaseBuilder(context, AppDatabase::class.java, "reader.db")
            .fallbackToDestructiveMigration()
            .build()
    val handoutDao get() = db.handoutDao()
    val engine: PdfEngine = PdfRendererEngine(context)
    val aiDb: AiDatabase = Room.databaseBuilder(context, AiDatabase::class.java, "ai.db")
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
        .fallbackToDestructiveMigration()
        .build()
    val aiDao = aiDb.aiDao()
    val settings = SettingsRepo(context)
    val router = AiRouter(
        aiDao,
        mapOf(ProviderTypes.GEMINI to GeminiProvider(), ProviderTypes.OPENAI to OpenAiCompatProvider()),
    )
    val pdfiumText = PdfiumTextEngine(context)
    val pageText = PageTextService(aiDao, router, pdfiumText)
    val annotations = AnnotationStore(context)
    val readAloud = ReadAloudController(context, router, pageText, settings, pdfiumText)
}

class ReaderApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            Log.e("UniversalPdfReader", "Uncaught exception on thread ${thread.name}", throwable)
            try {
                val f = File(filesDir, "crash.log")
                f.writeText("Time: ${System.currentTimeMillis()}\nThread: ${thread.name}\n${throwable.stackTraceToString()}\n")
            } catch (ignored: Exception) {}
            defaultHandler?.uncaughtException(thread, throwable)
        }
        container = AppContainer(this)
    }
}
