package app.pdfreader.ai

import android.graphics.Bitmap
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import android.util.LruCache
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.tts.PdfiumTextEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.ByteArrayOutputStream

sealed interface PT {
    class Ok(val text: String, val model: String = "", val fromCache: Boolean = false, val source: String? = null, val via: String? = null) : PT
    data object NoText : PT
    class Fail(val message: String) : PT
}

class PageTextService(
    private val dao: AiDao,
    private val router: AiRouter,
    private val engine: PdfiumTextEngine,
    private val appContext: Context,
) {
    private val session = LruCache<String, String>(300)
    private val googleSemaphore = Semaphore(2)

    fun clearSession() = session.evictAll()

        private fun uiFa(s: ReadingSettings): Boolean = s.appLanguage != "en"

private fun extractKey(docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v9|$docUri|$page|${s.sourceLanguage}|${s.ocrEngine}|${s.textRepair}|${s.stripHeaders}"
    )

    private fun finalKey(task: AiTask, docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v6|$docUri|$page|${task.name}|${if (task == AiTask.TRANSLATE) s.translationEngine else "ai"}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
    )

    private fun contentKey(task: AiTask, s: ReadingSettings, text: String): String = sha256(
        "v6|content|${task.name}|${if (task == AiTask.TRANSLATE) s.translationEngine else "ai"}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "") + "|" +
            sha256(text.trim().lowercase())
    )

    suspend fun cached(task: AiTask, docUri: String, page: Int, s: ReadingSettings): PT.Ok? {
        val k = finalKey(task, docUri, page, s)
        return dao.cached(k)?.let { PT.Ok(it.text, it.model, true, dao.cached("$k|src")?.text) }
    }

    /**
     * Check if text is already written in the target language (avoiding wasteful translation calls).
     */
    fun isAlreadyTargetLanguage(text: String, targetLang: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 20) return false
        if (targetLang in RTL_LANGS) {
            val rtlLetters = letters.count { ch ->
                ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\uFB50'..'\uFDFF' || ch in '\uFE70'..'\uFEFF'
            }
            return (rtlLetters.toDouble() / letters.length) > 0.65
        }
        if (targetLang == "en") {
            val latinLetters = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
            return (latinLetters.toDouble() / letters.length) > 0.80
        }
        return false
    }

    suspend fun extract(
        doc: PdfDocument, docUri: String, page: Int, s: ReadingSettings,
        force: Boolean = false, onPhase: (String) -> Unit = {},
    ): PT {
        val key = extractKey(docUri, page, s)
        if (!force) {
            session.get(key)?.let { return if (it == Prompts.NO_TEXT) PT.NoText else PT.Ok(it) }
            if (s.persistOcr) {
                dao.cached("ocr|${s.ocrEngine}|$key")?.let {
                    session.put(key, it.text)
                    return PT.Ok(it.text)
                }
            }
        }
        var verdict = TextVerdict(PageTextKind.NONE, if (force) "OCR درخواستی" else "")
        var layer = ""
        if (!force) {
            onPhase(if (uiFa(s)) "در حال بررسی لایه‌ی متنی صفحه ${page + 1}…" else "Checking text layer on page ${page + 1}…")
            val raw = try {
                // Geometry-aware extraction keeps multi-column tables as Markdown
                engine.pageTextStructured(docUri, page) ?: engine.pageText(docUri, page)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (raw != null) {
                layer = raw
                verdict = TextQuality.assess(raw)
            }
        }
        if (verdict.kind == PageTextKind.CLEAN) {
            val cleaned = cleanLayer(layer, key, page, s, onPhase)
            // localClean wiped a non-empty layer → treat as suspicious, try OCR once
            if (cleaned is PT.NoText && layer.trim().length >= 40) {
                onPhase(if (uiFa(s)) "پاک‌سازی محلی متن را خالی کرد؛ OCR صفحه ${page + 1}…" else "Local clean emptied text; OCR page ${page + 1}…")
                return ocrPage(doc, key, page, s, "OCR (پس از پاک‌سازی خالی)", onPhase)
            }
            return cleaned
        }
        onPhase(
            if (verdict.kind == PageTextKind.GARBLED) "متن PDF مخدوش است (${verdict.reason})؛ OCR صفحه ${page + 1}…"
            else "صفحه‌ی اسکن‌شده؛ OCR فشرده‌ی صفحه ${page + 1}…"
        )
        return ocrPage(doc, key, page, s, if (verdict.kind == PageTextKind.GARBLED) "OCR (متن مخدوش)" else "OCR", onPhase)
    }

    
    /** Optional low-token AI repair shared by every tool that calls extract(). */
    private fun wantsRepair(s: ReadingSettings, localGood: Boolean): Boolean = when (s.textRepair) {
        "always" -> true
        "weak" -> !localGood
        else -> false
    }

    private suspend fun maybeRepair(
        text: String,
        localGood: Boolean,
        s: ReadingSettings,
        onPhase: (String) -> Unit,
    ): Pair<String, String> {
        if (text.isBlank() || text == Prompts.NO_TEXT) return text to ""
        if (!wantsRepair(s, localGood)) return text to ""
        val fa = uiFa(s)
        onPhase(if (fa) "آماده‌سازی متن با AI (پاکسازی + جدول)…" else "AI text prep (cleanup + tables)…")
        return when (val o = router.run(Capability.TEXT, Prompts.buildOcrRepair(s, text.take(12000)), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var out = o.text.trim()
                if (out.contains(Prompts.NO_TEXT) && out.length < 32) return text to ""
                if (out.isBlank()) return text to ""
                // Reject pathological shrink
                if (out.length < text.length / 4 && text.length > 200) return text to ""
                if (s.stripHeaders) out = TextQuality.stripPageFurniture(out)
                else out = TextQuality.localClean(out)
                // Local geometry table promotion as a second pass on residual grids
                out = TextQuality.promoteTables(out)
                if (out.isBlank()) text to "" else out to (o.model.ifBlank { "repair" })
            }
            is AiRouter.Outcome.Failed -> text to ""
        }
    }

    private suspend fun commitPageText(
        key: String,
        text: String,
        localGood: Boolean,
        engine: String,
        s: ReadingSettings,
        via: String,
        onPhase: (String) -> Unit,
    ): PT {
        val (finalText, repairModel) = maybeRepair(text, localGood, s, onPhase)
        if (finalText.isBlank() || finalText == Prompts.NO_TEXT) {
            session.put(key, Prompts.NO_TEXT)
            return PT.NoText
        }
        session.put(key, finalText)
        val label = if (repairModel.isNotBlank()) "$engine+repair" else engine
        if (s.persistOcr) dao.upsertCache(CacheEntity("ocr|${s.ocrEngine}|$key", finalText, label, System.currentTimeMillis()))
        val via2 = if (repairModel.isNotBlank()) "$via · AI repair" else via
        return PT.Ok(finalText, label, false, null, via2)
    }

    /** Grayscale + mild contrast boost for OCR. */
    private fun enhanceForOcr(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply {
            setSaturation(0f)
            val c = 1.25f
            val t = (-0.125f * 255f)
            postConcat(ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )))
        }
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    private suspend fun cleanLayer(layer: String, key: String, page: Int, s: ReadingSettings, onPhase: (String) -> Unit): PT {
        onPhase(if (uiFa(s)) "متن سالم PDF؛ پردازش سریع محلی…" else "Clean PDF text; local processing…")
        val local = if (s.stripHeaders) TextQuality.stripPageFurniture(layer) else TextQuality.localClean(layer)
        if (local.isBlank()) return PT.NoText
        // PDF text layer is usually already good; repair only if textRepair=always
        return commitPageText(key, local, localGood = true, engine = "pdf-layer", s = s, via = "متن PDF", onPhase = onPhase)
    }

    /** Normalizes OCR mode: "local" (local, online backup), "local_only", "online". Legacy values are mapped. */
    /**
     * online | local_only | local (on-device first, optional online backup)
     * local_fa / local_en are on-device-only script locks unless ocrOnlineFallback and mode is auto-like.
     */
    private fun ocrMode(s: ReadingSettings): String = when (s.ocrEngine) {
        "online", "gemini" -> "online"
        "local_only", "local_fa", "local_en" -> "local_only"
        else -> if (s.ocrOnlineFallback) "local" else "local_only"
    }

    private class LocalOcrOutcome(val text: String, val engine: String, val good: Boolean, val failure: String?)

    private fun engineLabel(engine: String): String =
        if (engine == "mlkit") "ML Kit" else "Tesseract فارسی (آفلاین)"

    /**
     * Runs the on-device recognizers. Source language decides which one runs:
     * fa/ar -> Tesseract (fas) only, other explicit languages -> ML Kit only,
     * auto -> ML Kit first, Tesseract only if the Latin result is weak.
     */
    private suspend fun runLocalOcr(doc: PdfDocument, bmp: Bitmap, page: Int, s: ReadingSettings): LocalOcrOutcome {
        val fa = uiFa(s)
        val forceFa = s.ocrEngine == "local_fa"
        val forceEn = s.ocrEngine == "local_en"
        val explicitlyRtl = forceFa || (!forceEn && (s.sourceLanguage == "fa" || s.sourceLanguage == "ar"))
        val isAuto = !forceFa && !forceEn && s.sourceLanguage == "auto"
        var failure: String? = null

        var latinText = ""
        if (!explicitlyRtl) {
            val raw = try {
                withContext(Dispatchers.Default) { LocalOcr.recognize(bmp) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
                ""
            }
            if (raw.isNotBlank()) {
                latinText = if (s.stripHeaders) TextQuality.stripPageFurniture(raw) else TextQuality.localClean(raw)
            }
        }
        val latinGood = latinText.isNotBlank() && TextQuality.ocrQuality(latinText, OcrScript.LATIN, null)

        var persianText = ""
        var persianConf: Int? = null
        val needPersian = explicitlyRtl || (isAuto && !latinGood)
        if (needPersian) {
            // Tesseract reads small Persian print better from a larger render.
            val big: Bitmap? = try {
                withContext(Dispatchers.IO) { doc.render(page, 2200) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            }
            val src = big ?: bmp
            try {
                val r = withContext(Dispatchers.Default) { LocalOcr.recognizePersian(appContext, src) }
                persianConf = if (r.confidence >= 0) r.confidence else null
                if (r.text.isNotBlank()) {
                    persianText = if (s.stripHeaders) TextQuality.stripPageFurniture(r.text) else TextQuality.localClean(r.text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                Log.e("PageTextService", "Persian OCR failed", t)
                failure = if (fa) "OCR فارسی محلی اجرا نشد: ${t.message ?: t.javaClass.simpleName}" else "Local Persian OCR failed: ${t.message ?: t.javaClass.simpleName}"
            } finally {
                big?.recycle()
            }
        }

        val persianLetters = persianText.count { it in '\u0600'..'\u06FF' || it in '\uFB50'..'\uFEFF' }
        val latinLetters = latinText.count { it in 'A'..'Z' || it in 'a'..'z' }
        val usePersian = persianText.isNotBlank() && (
            explicitlyRtl ||
                (persianLetters >= 12 && persianLetters > latinLetters / 2) ||
                (latinText.length < 40 && persianLetters >= 8)
            )
        return if (usePersian) {
            LocalOcrOutcome(persianText, "tesseract-fas", TextQuality.ocrQuality(persianText, OcrScript.PERSIAN, persianConf), failure)
        } else {
            LocalOcrOutcome(latinText, if (latinText.isBlank()) "" else "mlkit", latinGood, failure)
        }
    }

    /**
     * OCR path. Mode (Settings → OCR engine):
     *  - local:      on-device first; if empty or low quality, try online (Gemini Vision);
     *                if online is unavailable, keep the best local text (marked low quality).
     *  - local_only: on-device only, never goes online.
     *  - online:     Gemini Vision only.
     */
    private suspend fun ocrPage(
        doc: PdfDocument, key: String, page: Int, s: ReadingSettings, via: String,
        onPhase: (String) -> Unit = {},
    ): PT {
        val mode = ocrMode(s)
        val fa = uiFa(s)
        val bmp = try {
            withContext(Dispatchers.IO) {
                val raw = doc.render(page, 1800)
                val enhanced = enhanceForOcr(raw)
                if (enhanced !== raw) raw.recycle()
                enhanced
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return PT.Fail(if (fa) "رندر صفحه برای OCR ممکن نشد." else "Could not render page for OCR.")
        }

        var local: LocalOcrOutcome? = null
        if (mode != "online") {
            onPhase(if (fa) "OCR محلی صفحه ${page + 1}…" else "On-device OCR of page ${page + 1}…")
            val lo = try {
                runLocalOcr(doc, bmp, page, s)
            } catch (e: CancellationException) {
                bmp.recycle(); throw e
            } catch (t: Throwable) {
                Log.e("PageTextService", "Local OCR failed", t)
                LocalOcrOutcome("", "", false, t.message)
            }
            local = lo
            lo.failure?.let { onPhase(it) }
            if (lo.text.isNotBlank() && (lo.good || mode == "local_only")) {
                bmp.recycle()
                val weak = if (lo.good) "" else if (fa) " · کیفیت پایین" else " · low quality"
                return commitPageText(
                    key, lo.text, localGood = lo.good, engine = lo.engine, s = s,
                    via = "$via · ${engineLabel(lo.engine)}$weak", onPhase = onPhase,
                )
            }
            if (mode == "local_only") {
                bmp.recycle()
                return if (lo.failure != null) PT.Fail(lo.failure) else PT.NoText
            }
            onPhase(
                if (fa) "OCR محلی کافی نبود؛ تلاش با OCR آنلاین…" else "Local OCR was not good enough; trying online OCR…"
            )
        }

        val localText = local?.text.orEmpty()
        val localEngine = local?.engine.orEmpty()

        val jpeg = try {
            withContext(Dispatchers.IO) {
                val gray = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(gray)
                val paint = Paint().apply {
                    colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
                }
                canvas.drawBitmap(bmp, 0f, 0f, paint)
                bmp.recycle()
                val out = ByteArrayOutputStream()
                gray.compress(Bitmap.CompressFormat.JPEG, 70, out)
                gray.recycle()
                out.toByteArray()
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return if (localText.isNotBlank()) {
                commitPageText(key, localText, localGood = false, engine = localEngine, s = s,
                    via = "$via · ${engineLabel(localEngine)}", onPhase = onPhase)
            } else PT.Fail(if (fa) "OCR متن کافی نداد." else "OCR produced insufficient text.")
        }

        return when (val o = router.run(Capability.VISION, Prompts.buildExtract(s, jpeg), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var text = o.text.trim()
                if (text.contains("NO_TEXT")) text = Prompts.NO_TEXT
                if (text != Prompts.NO_TEXT) {
                    text = if (s.stripHeaders) TextQuality.stripPageFurniture(text) else TextQuality.localClean(text)
                }
                if (text.isBlank() || text == Prompts.NO_TEXT) {
                    if (localText.isNotBlank()) {
                        commitPageText(key, localText, localGood = false, engine = localEngine, s = s,
                            via = "$via · ${engineLabel(localEngine)}", onPhase = onPhase)
                    } else {
                        session.put(key, Prompts.NO_TEXT)
                        PT.NoText
                    }
                } else {
                    // Vision output: treat as good enough; repair only if textRepair=always
                    commitPageText(key, text, localGood = true, engine = o.model, s = s, via = via, onPhase = onPhase)
                }
            }
            is AiRouter.Outcome.Failed -> {
                if (localText.isNotBlank()) {
                    val weak = if (fa) " · کیفیت پایین" else " · low quality"
                    commitPageText(
                        key, localText, localGood = false, engine = localEngine, s = s,
                        via = "$via · ${engineLabel(localEngine)}$weak", onPhase = onPhase,
                    )
                } else PT.Fail(describe(o))
            }
        }
    }


    /** Unified cache methods */
    suspend fun cachedText(key: String): String? = dao.cached(key)?.text
    suspend fun loadSavedText(key: String): String? = cachedText(key)

    suspend fun saveText(key: String, text: String) =
        dao.upsertCache(CacheEntity(key, text, "", System.currentTimeMillis()))

    /**
     * Persist a translation produced by the read-aloud path under the same keys
     * that the plain "ترجمه" button uses, so the two features share one cache and
     * never spend tokens twice for the same page.
     */
    suspend fun saveTranslation(docUri: String, page: Int, s: ReadingSettings, translated: String, source: String) {
        val pageKey = finalKey(AiTask.TRANSLATE, docUri, page, s)
        val cKey = contentKey(AiTask.TRANSLATE, s, source)
        val now = System.currentTimeMillis()
        dao.upsertCache(CacheEntity(pageKey, translated, "segment", now))
        dao.upsertCache(CacheEntity(cKey, translated, "segment", now))
        dao.upsertCache(CacheEntity("$pageKey|src", source, "", now))
    }

    class SegmentResult(val items: List<String>?, val error: String?)

    suspend fun translateSegments(docUri: String, page: Int, s: ReadingSettings, segments: List<String>): SegmentResult {
        if (segments.isEmpty()) return SegmentResult(emptyList(), null)
        val engine = s.translationEngine
        val key = sha256("seg|v6|$docUri|$page|$engine|${s.sourceLanguage}|${s.targetLanguage}|${s.translateMainTextOnly}|${s.profile.name}|${if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else ""}|" + segments.joinToString(""))
        dao.cached(key)?.let { c -> parseSegments(c.text, segments.size)?.let { return SegmentResult(it, null) } }

        if (s.translationEngine == "google") {
            return googleSegments(segments, key, s)
        }

        // Gemini AI path: try buildSegments with [[N]]
        var lastModel = s.preferredModel.ifBlank { "Gemini" }
        for (attempt in 0 until 2) {
            when (val o = router.run(Capability.TEXT, Prompts.buildSegments(s, segments), s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    lastModel = o.model
                    val items = parseSegments(o.text, segments.size)
                    if (items != null) {
                        dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                        return SegmentResult(items, null)
                    }
                }
                is AiRouter.Outcome.Failed -> {
                    if (o.reason == AiRouter.Reason.NOT_CONFIGURED || o.reason == AiRouter.Reason.ALL_COOLING_DOWN) {
                        return googleSegments(segments, key, s)
                    }
                }
            }
        }

        // Retried once and still no match -> fallback to translating each segment individually with Gemini
        val fallbackItems = mutableListOf<String>()
        var fallbackFailed = false
        for (seg in segments) {
            val req = Prompts.buildText(AiTask.TRANSLATE, s, seg)
            when (val o = router.run(Capability.TEXT, req, s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    lastModel = o.model
                    fallbackItems.add(o.text.trim())
                }
                is AiRouter.Outcome.Failed -> {
                    fallbackFailed = true
                    break
                }
            }
        }
        if (!fallbackFailed && fallbackItems.size == segments.size) {
            val joined = fallbackItems.mapIndexed { i, t -> "[[${i + 1}]] $t" }.joinToString("\n\n")
            dao.upsertCache(CacheEntity(key, joined, lastModel, System.currentTimeMillis()))
            return SegmentResult(fallbackItems, null)
        }

        // Final fallback: Google Translate
        return googleSegments(segments, key, s)
    }

    private suspend fun googleSegments(
        segments: List<String>,
        key: String,
        s: ReadingSettings,
    ): SegmentResult = try {
        val translatedList = coroutineScope {
            segments.map { seg ->
                async(Dispatchers.IO) {
                    val segHash = sha256(seg)
                    val segKey = "gt_seg|v6|${s.sourceLanguage}|${s.targetLanguage}|$segHash"
                    val cached = dao.cached(segKey)?.text
                    if (!cached.isNullOrBlank()) {
                        cached
                    } else {
                        googleSemaphore.withPermit {
                            val t = GoogleTranslateService.translate(
                                seg,
                                s.sourceLanguage,
                                s.targetLanguage,
                                s.googleTranslateBase,
                                s.stripHeaders
                            )
                            dao.upsertCache(CacheEntity(segKey, t, "Google Translate", System.currentTimeMillis()))
                            t
                        }
                    }
                }
            }.awaitAll()
        }
        val joined = translatedList.mapIndexed { i, t -> "[[${i + 1}]] $t" }.joinToString("\n\n")
        dao.upsertCache(CacheEntity(key, joined, "Google Translate", System.currentTimeMillis()))
        SegmentResult(translatedList, null)
    } catch (e: Exception) {
        SegmentResult(null, "Google Translate: ${e.message}")
    }

    /**
     * More tolerant parser: accepts [[1]], [[ 1 ]], [1], 1. etc. and reconstructs by number order.
     * Falls back to sequential split if markers are missing but count of paragraphs matches.
     */
    private fun parseSegments(raw: String, n: Int): List<String>? {
        if (n <= 0) return null
        // Primary: numbered markers [[N]] or [N] or N.
        val markRegex = Regex("""(?:\[\[|\[)\s*(\d+)\s*(?:\]\]|\])|(?:^|\n)\s*(\d+)[\.\)]\s+""", RegexOption.MULTILINE)
        val marks = markRegex.findAll(raw).mapNotNull { m ->
            val num = (m.groupValues[1].ifBlank { m.groupValues[2] }).toIntOrNull() ?: return@mapNotNull null
            num to m.range
        }.toList()
        if (marks.isNotEmpty()) {
            val byNum = sortedMapOf<Int, String>()
            for ((i, pair) in marks.withIndex()) {
                val (num, range) = pair
                val end = if (i + 1 < marks.size) marks[i + 1].second.first else raw.length
                val t = raw.substring(range.last + 1, end).trim()
                    .removePrefix("\n").trim()
                if (t.isNotBlank()) byNum[num] = t
            }
            if (byNum.size == n && byNum.keys.first() == 1 && byNum.keys.last() == n) {
                return (1..n).map { byNum[it]!! }
            }
            // Accept if we got exactly the expected consecutive numbers even if start is not 1 (rare)
            if (byNum.size == n) {
                val sorted = byNum.toList().sortedBy { it.first }
                if (sorted.zipWithNext().all { (a, b) -> b.first == a.first + 1 }) {
                    return sorted.map { it.second }
                }
            }
        }
        // Fallback: split on blank lines if the model ignored numbering but produced the right count of blocks
        val blocks = raw.split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotBlank() && !it.matches(Regex("^\\[\\[?\\d+\\]?\\]$")) }
        if (blocks.size == n) return blocks
        return null
    }

    suspend fun process(
        task: AiTask, docUri: String, page: Int, s: ReadingSettings, text: String,
        force: Boolean = false,
        onModelActive: ((String) -> Unit)? = null,
        onPartial: ((String) -> Unit)? = null,
    ): PT {
        if (task == AiTask.TRANSLATE && isAlreadyTargetLanguage(text, s.targetLanguage)) {
            return PT.Ok(text, "متن از قبل به زبان مقصد است", true, text)
        }

        val pageKey = finalKey(task, docUri, page, s)
        val cKey = contentKey(task, s, text)

        if (!force) {
            dao.cached(pageKey)?.let { return PT.Ok(it.text, it.model, true, dao.cached("$pageKey|src")?.text) }
            dao.cached(cKey)?.let { return PT.Ok(it.text, it.model, true, text) }
        }

        if (task == AiTask.TRANSLATE) {
            onModelActive?.invoke(if (s.translationEngine == "google") "Google Translate" else "Gemini AI")
            var rawSegments = TextQuality.segmentPageText(text)
            if (rawSegments.isEmpty()) rawSegments = listOf(text)
            val segmentsToTranslate = if (s.translateMainTextOnly) {
                TextQuality.filterMainTextOnly(rawSegments)
            } else rawSegments

            val segResult = translateSegments(docUri, page, s, segmentsToTranslate)
            if (segResult.items != null) {
                val origJoined = segmentsToTranslate.joinToString("\n\n")
                val transJoined = segResult.items.joinToString("\n\n")
                val modelName = if (s.translationEngine == "google") "Google Translate" else s.preferredModel.ifBlank { "Gemini" }
                val now = System.currentTimeMillis()
                dao.upsertCache(CacheEntity(pageKey, transJoined, modelName, now))
                dao.upsertCache(CacheEntity(cKey, transJoined, modelName, now))
                dao.upsertCache(CacheEntity("$pageKey|src", origJoined, "", now))
                onPartial?.invoke(transJoined)
                return PT.Ok(transJoined, modelName, false, origJoined)
            } else {
                return PT.Fail(segResult.error ?: "خطا در ترجمه")
            }
        }

        val req = Prompts.buildText(task, s, text)
        return when (val o = router.run(Capability.TEXT, req, s.preferredModel, onModelActive, onPartial)) {
            is AiRouter.Outcome.Ok -> {
                val now = System.currentTimeMillis()
                dao.upsertCache(CacheEntity(pageKey, o.text, o.model, now))
                dao.upsertCache(CacheEntity(cKey, o.text, o.model, now))
                if (task == AiTask.TRANSLATE) dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
                PT.Ok(o.text, o.model, false, text)
            }
            is AiRouter.Outcome.Failed -> {
                // AI translation failed → optional Google fallback (only when engine is AI)
                if (task == AiTask.TRANSLATE && s.translationEngine == "ai") {
                    onModelActive?.invoke("Google Translate (fallback)")
                    return googleTranslateAndCache(text, pageKey, cKey, s, onPartial)
                }
                PT.Fail(describe(o))
            }
        }
    }

    private suspend fun googleTranslateAndCache(
        text: String,
        pageKey: String,
        cKey: String,
        s: ReadingSettings,
        onPartial: ((String) -> Unit)?,
    ): PT = try {
        val translated = GoogleTranslateService.translate(text, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders)
        val now = System.currentTimeMillis()
        val engineName = "Google Translate"
        dao.upsertCache(CacheEntity(pageKey, translated, engineName, now))
        dao.upsertCache(CacheEntity(cKey, translated, engineName, now))
        dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
        onPartial?.invoke(translated)
        PT.Ok(translated, engineName, false, text)
    } catch (e: Exception) {
        PT.Fail((if (uiFa(s)) "خطا در ارتباط با Google Translate: " else "Google Translate error: ") + (e.message ?: (if (uiFa(s)) "اتصال اینترنت را بررسی کنید" else "Check your internet connection")))
    }

    suspend fun summarizeRange(
        doc: PdfDocument, docUri: String, from: Int, to: Int, s: ReadingSettings, force: Boolean,
        onProgress: (String) -> Unit, onPartial: ((String) -> Unit)?,
    ): PT {
        val key = sha256(
            "v6|handout|$docUri|$from|$to|${s.handoutLanguage}|${s.targetLanguage}|${s.profile.name}|" +
                (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        )
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true) }
        val n = to - from + 1
        val pageTexts = mutableListOf<Pair<Int, String>>() // pageIndex to text
        for (p in from..to) {
            onProgress("در حال خواندن صفحه ${p + 1} (${p - from + 1} از $n)…")
            when (val ex = extract(doc, docUri, p, s)) {
                is PT.Fail -> return PT.Fail("صفحه ${p + 1}: " + ex.message)
                PT.NoText -> {}
                is PT.Ok -> pageTexts += (p to "[Page ${p + 1}]\n${ex.text}")
            }
        }
        if (pageTexts.isEmpty()) return PT.NoText

        suspend fun ask(mode: Prompts.RangeMode, text: String, partial: ((String) -> Unit)?): PT =
            when (val o = router.run(Capability.TEXT, Prompts.buildRangeSummary(s, from, to, text, mode), s.preferredModel, null, partial)) {
                is AiRouter.Outcome.Ok -> PT.Ok(o.text, o.model)
                is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
            }

        // For ranges up to 15 pages (standard chapter/section study range): single direct call with live streaming!
        // This keeps the full document context, streams tokens in 1-2s, and prevents false timeouts.
        val result: PT = if (pageTexts.size <= 15) {
            onProgress("در حال تولید جزوهٔ مرور هوشمند صفحات ${from + 1} تا ${to + 1}…")
            ask(Prompts.RangeMode.FULL, pageTexts.joinToString("\n\n") { it.second }, onPartial)
        } else {
            val groups = pageTexts.chunked(10)
            val partial = mutableListOf<String>()
            for ((i, g) in groups.withIndex()) {
                val pStart = g.first().first + 1
                val pEnd = g.last().first + 1
                onProgress("جزوهٔ بخش ${i + 1} از ${groups.size} (صفحات $pStart تا $pEnd)…")
                when (val r = ask(Prompts.RangeMode.PART, g.joinToString("\n\n") { it.second }, onPartial)) {
                    is PT.Ok -> partial += r.text
                    else -> return r
                }
            }
            onProgress("در حال ادغام نهایی جزوه…")
            ask(Prompts.RangeMode.MERGE, partial.joinToString("\n\n---\n\n"), onPartial)
        }
        if (result is PT.Ok) dao.upsertCache(CacheEntity(key, result.text, result.model, System.currentTimeMillis()))
        return result
    }

    fun describe(f: AiRouter.Outcome.Failed, isFa: Boolean = true): String {
        fun humanizeDetail(raw: String): String {
            val d = raw
            return when {
                d.contains("RECITATION", ignoreCase = true) ->
                    if (isFa) "محتوای صفحه به‌عنوان متن دارای حق‌نشر شناسایی شد. دوباره تلاش کنید؛ پاسخ بدون نقل‌قول مستقیم از کتاب خواهد بود."
                    else "The page text triggered a copyright/recitation filter. Retry — the answer will paraphrase instead of quoting the book."
                d.contains("DAILY_QUOTA", ignoreCase = true) || d.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ->
                    if (isFa) "سهمیهٔ روزانهٔ کلید API تمام شده است. کلید دیگری اضافه کنید یا فردا دوباره تلاش کنید."
                    else "Daily API quota exceeded. Add another key or try again tomorrow."
                d.contains("MODEL_UNAVAILABLE", ignoreCase = true) || d.contains("\"code\": 404") ->
                    if (isFa) "برخی مدل‌ها در این کلید در دسترس نیستند؛ مدل‌های دیگر را هم امتحان کردیم."
                    else "Some models are unavailable on this key; other models were also tried."
                d.contains("429") ->
                    if (isFa) "محدودیت نرخ درخواست (429). کمی صبر کنید و دوباره بزنید."
                    else "Rate limited (429). Wait a moment and retry."
                d.contains("timeout", ignoreCase = true) || d.contains("socket", ignoreCase = true) || d.contains("connection closed", ignoreCase = true) ->
                    if (isFa)
                        "اتصال به سرور Gemini برقرار نشد (timeout / قطع ارتباط).\n" +
                        "اگر در ایران هستید معمولاً نیاز به VPN دارید. VPN را روشن کنید و دوباره تلاش کنید.\n" +
                        "کلید API احتمالاً سالم است؛ مشکل از شبکه است نه اتمام سهمیه."
                    else
                        "Could not reach Gemini servers (timeout / connection closed).\n" +
                        "If Google APIs are blocked on your network, turn on a VPN and retry.\n" +
                        "This is usually a network issue, not an exhausted API key."
                else -> d.lines().take(6).joinToString("\n").take(400)
            }
        }
        return when (f.reason) {
            AiRouter.Reason.NOT_CONFIGURED ->
                if (isFa) "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
                else "No valid API key configured. Add a Gemini key in Settings."
            AiRouter.Reason.ALL_COOLING_DOWN -> {
                val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
                if (sec > 0) {
                    if (isFa) "محدودیت موقت اعمال شده است (حدود ${waitText(sec, true)}). برای ارسال مجدد دکمهٔ تلاش دوباره را بزنید."
                    else "Temporary limit applied (about ${waitText(sec, false)}). Tap Retry to send again."
                } else {
                    if (isFa) "سرویس آماده است. دکمهٔ تلاش دوباره را بزنید."
                    else "Service is ready. Tap Retry."
                }
            }
            AiRouter.Reason.NETWORK ->
                if (isFa) "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
                else "No internet connection or the service is unreachable."
            AiRouter.Reason.TIMEOUT ->
                if (isFa) "پاسخ سرویس بیش از حد طول کشید. مدل‌های دیگر را امتحان کنید."
                else "The service timed out. Try other models."
            AiRouter.Reason.CANCELLED ->
                if (isFa) "عملیات توسط کاربر لغو شد."
                else "Cancelled by user."
            AiRouter.Reason.ALL_FAILED ->
                (if (isFa) "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" else "Request failed on all keys and models.\n") +
                    humanizeDetail(f.detail)
        }
    }

    private fun waitText(seconds: Long, isFa: Boolean): String = when {
        seconds < 90 -> if (isFa) "$seconds ثانیه" else "$seconds s"
        seconds < 5400 -> if (isFa) "${seconds / 60} دقیقه" else "${seconds / 60} min"
        else -> if (isFa) "${seconds / 3600} ساعت" else "${seconds / 3600} h"
    }
}
