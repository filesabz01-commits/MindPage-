# Universal PDF Reader — مرحله ۳
Kotlin + Compose + Material 3 + Room. ساخت: `gradle assembleDebug` (Gradle 8.9، JDK 17، Android SDK 34).

## این مرحله
- ارزیابی ۳‌حالتی صفحه پیش از پردازش: متن سالم (بدون OCR + یک پاکسازی ساختاری) / اسکن (OCR) / متن مخدوش (کنار گذاشتن لایه‌ی خراب + OCR). دکمه‌ی «OCR این صفحه» همیشه OCR اجباری است.
- حذف نویز: DC offset، فید، حذف کلیک/پرش لبه‌ها، مکث بین تکه‌ها، پخش‌کننده‌ی بعدی از قبل آماده، تحویل بدون وقفه حتی بین صفحه‌ها.
- انتخاب متن: دسته‌های کشیدنی، هایلایت چندرنگ، خط‌زیر، خط‌خورده، کپی، یادداشت، فهرست هایلایت‌ها با پرش به صفحه.
- هایلایت صوتی: جمله (از مکث‌های واقعی صدا) + کلمه‌ی در حال خواندن؛ صفحه خودکار دنبال خط خوانده‌شده می‌رود.
- پیش‌بارگذاری: صفحه‌ی بعد (OCR/ترجمه/صدا) هم‌زمان آماده می‌شود، تکه‌ی در حال پخش اولویت دارد، تلاش مجدد با فاصله‌ی فزاینده، نمایش «آماده‌ی پخش: n ثانیه».

## Persian offline OCR
- ML Kit Text Recognition remains the local OCR engine for Latin-script pages.
- Persian scans use the bundled Tesseract `fas` traineddata model through `tess-two`; the model is copied to app-private storage on first use and works without network access.
- OCR runs in the normal PDF page extraction path (including the explicit page OCR action), not only in Study Mode.
- In `auto` source-language mode the app compares Latin and Persian-script OCR output; choosing Persian as the source language skips the Latin recognizer.
- First OCR on a Persian page may take longer while the model is copied and initialized. Better image resolution, straight pages, and clear print still improve results.
