package app.pdfreader.ai

import app.pdfreader.ui.parseVocabCards
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class VocabRegexTest {

    @Test
    fun parseVocabCards_acceptsAllThreeFieldFormats() {
        val md = """
### set an example
- **POS:** verb phrase
- **EN:** to behave in a way that other people should copy
- **FA:** الگو بودن، سرمشق شدن
- **Example:** You should be setting an example for your sister.
- **Synonyms:** be a role model
- **Antonyms:** mislead

### take the blame
- **POS**: idiom
- **EN**: to accept responsibility for something bad
- **FA**: تقصیر را گردن گرفتن
- **Example**: He was ready to take the blame for the mistake.

### role model
- POS: noun
- EN: a person looked to by others as an example
- FA: الگوی رفتاری
- Example: She is a great role model for youth.
        """.trimIndent()

        val cards = parseVocabCards(md)
        assertEquals(3, cards.size)

        // Card 1: - **POS:** format
        assertEquals("set an example", cards[0].head)
        assertEquals("verb phrase", cards[0].pos)
        assertEquals("to behave in a way that other people should copy", cards[0].en)
        assertEquals("الگو بودن، سرمشق شدن", cards[0].fa)

        // Card 2: - **POS**: format
        assertEquals("take the blame", cards[1].head)
        assertEquals("idiom", cards[1].pos)
        assertEquals("to accept responsibility for something bad", cards[1].en)
        assertEquals("تقصیر را گردن گرفتن", cards[1].fa)

        // Card 3: - POS: format
        assertEquals("role model", cards[2].head)
        assertEquals("noun", cards[2].pos)
        assertEquals("a person looked to by others as an example", cards[2].en)
        assertEquals("الگوی رفتاری", cards[2].fa)
    }

    @Test
    fun parseVocabCards_dropsTruncatedLastCard() {
        val md = """
### achieve
- **POS:** verb
- **EN:** to reach or attain
- **FA:** به دست آوردن
- **Example:** She achieved her goal.

### incomplete word
- **POS:** noun
- **EN:** broken definition
        """.trimIndent()

        val cards = parseVocabCards(md)
        assertEquals(1, cards.size)
        assertEquals("achieve", cards[0].head)
    }
}
