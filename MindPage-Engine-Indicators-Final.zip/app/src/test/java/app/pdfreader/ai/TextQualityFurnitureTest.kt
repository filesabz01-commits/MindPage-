package app.pdfreader.ai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class TextQualityFurnitureTest {
    @Test
    fun keepsEquipmentTagsAndFormulasAndCaptions() {
        val src = """
            FIC-101
            P-102A
            P = ρgh
            150 psi
            Figure 4-2. Centrifugal pump arrangement on the skid
            Normal process description continues here with enough words to form a paragraph about the design of the system.
        """.trimIndent()
        val out = TextQuality.stripPageFurniture(src)
        assertTrue(out.contains("FIC-101"))
        assertTrue(out.contains("P-102A"))
        assertTrue(out.contains("150 psi") || out.contains("150"))
        assertTrue(out.contains("Figure 4-2") || out.contains("Centrifugal"))
        assertTrue(out.contains("Normal process description"))
    }

    @Test
    fun doesNotDeleteWatermarkWordsEmbeddedInTechnicalProse() {
        val src = "The Wiley online library interface was used to verify this technical reference."
        val out = TextQuality.stripPublisherNoise(src)
        assertTrue(out.contains("Wiley online library"))
        assertTrue(out.contains("technical reference"))
    }

    @Test
    fun manualCleanupKeepsFigureCaptions() {
        val src = "Figure 2.1\nThe pump performance curve is shown below."
        val out = TextQuality.manualPageCleanup(src)
        assertTrue(out.contains("Figure 2.1"))
    }

    @Test
    fun dropsPageOnlyAndLicenseOnly() {
        val src = """
            42
            All rights reserved
            © 2020
            Useful body text about piping remains on this line for the reader.
            xii
        """.trimIndent()
        val out = TextQuality.stripPageFurniture(src)
        assertFalse(out.lines().any { it.trim() == "42" })
        assertFalse(out.lines().any { it.trim().equals("All rights reserved", true) })
        assertTrue(out.contains("Useful body text"))
    }
}
