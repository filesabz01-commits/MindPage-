package app.pdfreader.ui

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class StudyModeVocabTest {

    @Test
    fun parseVocabCardsAcceptsAllThreeFieldFormats() {
        val markdown = """
            ### set an example
            - **POS:** phrase
            - **EN:** behave in a way that others should copy
            - **FA:** الگو قرار دادن
            - **Example:** She wanted to set an example for the younger kids.
            - **Synonyms:** be a role model
            - **Antonyms:** mislead

            ### take the blame
            - **POS**: verb
            - **EN**: accept responsibility for a mistake
            - **FA**: تقصیر را به گردن گرفتن
            - **Example**: He was willing to take the blame.
            - **Synonyms**: accept fault
            - **Antonyms**: shift blame

            ### promise
            - POS: noun
            - EN: a statement that you will do something
            - FA: قول و وعده
            - Example: She kept her promise.
            - Synonyms: pledge / vow
            - Antonyms: breach
        """.trimIndent()

        val cards = parseVocabCards(markdown)
        assertEquals(3, cards.size)

        // Card 1: - **POS:** format
        assertEquals("set an example", cards[0].head)
        assertEquals("phrase", cards[0].pos)
        assertEquals("behave in a way that others should copy", cards[0].en)
        assertEquals("الگو قرار دادن", cards[0].fa)
        assertTrue(cards[0].example.contains("younger kids"))

        // Card 2: - **POS**: format
        assertEquals("take the blame", cards[1].head)
        assertEquals("verb", cards[1].pos)
        assertEquals("accept responsibility for a mistake", cards[1].en)
        assertEquals("تقصیر را به گردن گرفتن", cards[1].fa)

        // Card 3: - POS: format
        assertEquals("promise", cards[2].head)
        assertEquals("noun", cards[2].pos)
        assertEquals("a statement that you will do something", cards[2].en)
        assertEquals("قول و وعده", cards[2].fa)
    }

    @Test
    fun dropsIncompleteCardTruncatedAtEnd() {
        val markdown = """
            ### complete entry
            - **POS:** noun
            - **EN:** finished item
            - **FA:** کامل
            - **Example:** A complete entry test.

            ### incomplete cut off entry
            - **POS:** noun
            - **EN:** 
        """.trimIndent()

        val cards = parseVocabCards(markdown)
        assertEquals(1, cards.size)
        assertEquals("complete entry", cards[0].head)
    }
}
