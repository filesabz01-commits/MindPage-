package app.pdfreader.ui.l10n

import org.junit.Assert.assertEquals
import org.junit.Test

class RelativeTimeTest {
    private val now = 1_800_000_000_000L
    private val minute = 60_000L
    private val hour = 60 * minute
    private val day = 24 * hour

    @Test
    fun persianMinutesUsePersianDigitsAndWords() {
        assertEquals("۷ دقیقه پیش", relativeTime(now - 7 * minute, now, "fa"))
    }

    @Test
    fun englishMinutes() {
        assertEquals("7 min ago", relativeTime(now - 7 * minute, now, "en"))
    }

    @Test
    fun justNowAndYesterday() {
        assertEquals("هم‌اکنون", relativeTime(now - 10_000L, now, "fa"))
        assertEquals("Just now", relativeTime(now - 10_000L, now, "en"))
        assertEquals("دیروز", relativeTime(now - 30 * hour, now, "fa"))
        assertEquals("Yesterday", relativeTime(now - 30 * hour, now, "en"))
    }

    @Test
    fun hoursAndDays() {
        assertEquals("۳ ساعت پیش", relativeTime(now - 3 * hour, now, "fa"))
        assertEquals("3 days ago", relativeTime(now - 3 * day, now, "en"))
    }
}
