package app.pdfreader.ui

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class MarkdownInlineTest {

    @Test
    fun cleanLatexRemovesDollarSignsAndSimplifiesCommands() {
        val latex = """Formula: ${'$'}E = mc^2${'$'} and ${'$'}${'$'}\frac{a}{b}${'$'}${'$'} with \text{Result} and A \rightarrow B \times C."""
        val cleaned = cleanLatexAndSymbols(latex)

        assertFalse("No dollar sign should remain", cleaned.contains("$"))
        assertFalse("No backslash should remain", cleaned.contains("\\"))
        assertTrue("Fraction simplified", cleaned.contains("a/b"))
        assertTrue("Text command simplified", cleaned.contains("Result"))
        assertTrue("Arrow simplified", cleaned.contains("→"))
        assertTrue("Multiplication simplified", cleaned.contains("×"))
    }

    @Test
    fun parseMarkdownInlineHandlesUnclosedMarkersGracefully() {
        // Dangling / unclosed formatting markers must never appear as raw ** or * in the final text
        val raw = "This is **bold and this is *italic but unclosed **"
        val annotated = parseMarkdownInline(raw)
        val text = annotated.text

        assertFalse("No raw double asterisks should remain", text.contains("**"))
        assertTrue("Clean text preserved", text.contains("This is bold and this is italic but unclosed"))
    }
}
