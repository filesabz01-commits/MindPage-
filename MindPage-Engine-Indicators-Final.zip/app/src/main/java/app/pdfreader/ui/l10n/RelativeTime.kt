package app.pdfreader.ui.l10n

import java.util.Date
import java.util.Locale

/**
 * Relative time in the APP language (not the phone's language), e.g. «۷ دقیقه پیش» / "7 min ago".
 * Older than a week falls back to a date (Persian/Jalali calendar when the app is Persian).
 */
fun relativeTime(thenMs: Long, nowMs: Long, lang: String): String {
    if (thenMs <= 0L) return "—"
    val fa = lang.equals("fa", ignoreCase = true) || lang.startsWith("fa-", ignoreCase = true) || lang.equals("persian", ignoreCase = true)
    val diff = (nowMs - thenMs).coerceAtLeast(0L)
    val minutes = diff / 60_000L
    val hours = diff / 3_600_000L
    val days = diff / 86_400_000L
    fun n(v: Long): String = NumberFormatter.format(v, lang)
    return when {
        minutes < 1L -> if (fa) "هم‌اکنون" else "Just now"
        minutes < 60L -> if (fa) "${n(minutes)} دقیقه پیش" else "$minutes min ago"
        hours < 24L -> if (fa) "${n(hours)} ساعت پیش" else "$hours hr ago"
        days == 1L -> if (fa) "دیروز" else "Yesterday"
        days < 7L -> if (fa) "${n(days)} روز پیش" else "$days days ago"
        else -> absoluteDate(thenMs, fa)
    }
}

private fun absoluteDate(ms: Long, fa: Boolean): String = try {
    if (fa) {
        android.icu.text.DateFormat
            .getDateInstance(android.icu.text.DateFormat.LONG, android.icu.util.ULocale("fa_IR@calendar=persian"))
            .format(Date(ms))
    } else {
        java.text.DateFormat.getDateInstance(java.text.DateFormat.MEDIUM, Locale.ENGLISH).format(Date(ms))
    }
} catch (_: Throwable) {
    NumberFormatter.formatDate(ms, if (fa) "fa" else "en")
}
