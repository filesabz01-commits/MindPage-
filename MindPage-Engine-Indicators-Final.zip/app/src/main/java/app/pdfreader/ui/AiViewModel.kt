package app.pdfreader.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import app.pdfreader.ReaderApp
import app.pdfreader.ai.PT
import app.pdfreader.ai.RTL_LANGS
import app.pdfreader.ai.AiTask
import app.pdfreader.ai.ApiKeyEntity
import app.pdfreader.ai.GeminiModels
import app.pdfreader.ai.GeminiProvider
import app.pdfreader.ai.KeyStatus
import app.pdfreader.ai.ModelEntity
import app.pdfreader.ai.ProviderEntity
import app.pdfreader.ai.ProviderTypes
import app.pdfreader.ai.ReadingProfile
import app.pdfreader.ai.ReadingSettings
import app.pdfreader.ai.SecretBox
import app.pdfreader.ai.TokenTotalsTuple
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.data.HandoutEntity
import app.pdfreader.data.MarkdownPdf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

sealed interface AiUi {
    data object Idle : AiUi
    class Loading(
        val task: AiTask,
        val page: Int,
        val phase: String,
        val currentModel: String = "",
        val elapsedSeconds: Int = 0,
        val rangeTo: Int = -1,
    ) : AiUi
    class Streaming(val task: AiTask, val page: Int, val text: String, val rtl: Boolean, val original: String? = null, val rangeTo: Int = -1) : AiUi
    class Done(
        val task: AiTask,
        val page: Int,
        val text: String,
        val fromCache: Boolean,
        val model: String,
        val rtl: Boolean,
        val original: String? = null,
        val rangeTo: Int = -1,
        /** Absolute path to generated handout PDF when range summary succeeded. */
        val handoutPdfPath: String? = null,
        val handoutId: String? = null,
        val removedText: String? = null,
    ) : AiUi
    class Error(val message: String) : AiUi
}

class AiViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as ReaderApp).container
    private val dao = container.aiDao
    private val router = container.router
    private val settingsRepo = container.settings
    private val texts = container.pageText

    val providers = dao.observeProviders().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val models = dao.observeModels().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val keys = dao.observeKeys().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val cacheBytes = dao.observeCacheBytes().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0L)
    val settings: StateFlow<ReadingSettings> = settingsRepo.state

    val attempts = dao.observeAttempts().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val tokenTotals = dao.observeTokenTotals().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), TokenTotalsTuple(0, 0, 0))

    private val _audioBytes = MutableStateFlow(0L)
    val audioBytes: StateFlow<Long> = _audioBytes.asStateFlow()
    fun refreshAudioBytes() { _audioBytes.value = container.readAloud.audioBytes() }

    private val _ui = MutableStateFlow<AiUi>(AiUi.Idle)
    val ui: StateFlow<AiUi> = _ui.asStateFlow()

    private val _testMessages = MutableStateFlow<Map<String, String>>(emptyMap())
    val testMessages: StateFlow<Map<String, String>> = _testMessages.asStateFlow()

    private var job: Job? = null
    private var timerJob: Job? = null

    init {
        viewModelScope.launch { seedModels() }
        refreshAudioBytes()
    }

    private suspend fun seedModels() {
        // v11: text + TTS ladders with full user management
        if (settingsRepo.seedVersion() >= 11) return
        if (dao.provider("gemini") == null) {
            dao.upsertProvider(
                ProviderEntity("gemini", "Gemini", ProviderTypes.GEMINI, ProviderTypes.defaultBaseUrl(ProviderTypes.GEMINI), true, 0)
            )
        }
        dao.deleteModelsOf("gemini")
        GeminiModels.TEXT.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-t-$i", providerId = "gemini", modelName = m,
                    supportsText = true, supportsVision = true, enabled = true, position = i, supportsTts = false)
            )
        }
        GeminiModels.TTS.forEachIndexed { i, m ->
            dao.upsertModel(
                ModelEntity(id = "gemini-s-$i", providerId = "gemini", modelName = m,
                    supportsText = false, supportsVision = false, enabled = true, position = 100 + i, supportsTts = true)
            )
        }
        settingsRepo.setSeedVersion(11)
    }

    private fun startElapsedTimer(task: AiTask, page: Int, rangeTo: Int = -1) {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            var sec = 0
            while (isActive) {
                delay(1000)
                sec++
                val curr = _ui.value
                if (curr is AiUi.Loading) {
                    _ui.value = AiUi.Loading(task, page, curr.phase, curr.currentModel, sec, rangeTo)
                }
            }
        }
    }

    fun cancelTask() {
        job?.cancel()
        timerJob?.cancel()
        _ui.value = AiUi.Idle
    }

    fun nextModel() {
        router.requestSkipCurrentModel()
    }

    fun runPageTask(doc: PdfDocument, docUri: String, requestedPage: Int, task: AiTask, force: Boolean = false) {
        cancelTask()
        val page = requestedPage.coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0))
        _ui.value = AiUi.Loading(task, page, phasePreparing())
        startElapsedTimer(task, page)

        job = viewModelScope.launch {
          try {
            val s = settings.value
            val targetRtl = s.targetLanguage in RTL_LANGS
            if (!force && task != AiTask.EXTRACT) {
                texts.cached(task, docUri, page, s)?.let {
                    timerJob?.cancel()
                    val cachedMethod = if (task == AiTask.TRANSLATE) {
                        listOfNotNull(texts.cachedOcrMethod(docUri, page, s), it.model).filter { v -> v.isNotBlank() }.distinct().joinToString(" + ")
                    } else it.model
                    _ui.value = AiUi.Done(
                        task, page, it.text, true, cachedMethod, targetRtl, it.source,
                        removedText = texts.removedTextForPage(docUri, page, s)
                    )
                    return@launch
                }
            }
            val ex = texts.extract(doc, docUri, page, s, force) { phase ->
                if (isActive) {
                    val curr = _ui.value as? AiUi.Loading
                    _ui.value = AiUi.Loading(task, page, phase, curr?.currentModel.orEmpty(), curr?.elapsedSeconds ?: 0)
                }
            }
            val extractionResult = ex as? PT.Ok
            val text = when (ex) {
                is PT.Fail -> {
                    timerJob?.cancel()
                    _ui.value = AiUi.Error(ex.message)
                    return@launch
                }
                PT.NoText -> {
                    timerJob?.cancel()
                    _ui.value = AiUi.Done(task, page, "این صفحه فقط شکل، عکس یا نمودار دارد و متن اصلی قابل‌توجهی ندارد؛ نادیده گرفته شد.", false, "—", false)
                    return@launch
                }
                is PT.Ok -> ex.text
            }
            if (task == AiTask.EXTRACT) {
                timerJob?.cancel()
                _ui.value = AiUi.Done(
                    task, page, text, false, ex.let { (it as PT.Ok).model.ifEmpty { "—" } },
                    isRtlParagraph(text), removedText = texts.removedTextForPage(docUri, page, s)
                )
                return@launch
            }

            val curModelRef = StringBuilder()
            val curr = _ui.value as? AiUi.Loading
            _ui.value = AiUi.Loading(task, page, phaseProcessingText(), "", curr?.elapsedSeconds ?: 0)

            val r = texts.process(
                task, docUri, page, s, text, force,
                onModelActive = { modelName ->
                    curModelRef.setLength(0)
                    curModelRef.append(modelName)
                    val c = _ui.value as? AiUi.Loading
                    if (c != null) {
                        _ui.value = AiUi.Loading(task, page, c.phase, modelName, c.elapsedSeconds)
                    }
                },
                onPartial = { partial ->
                    if (isActive) _ui.value = AiUi.Streaming(task, page, partial, targetRtl, text)
                },
            )

            timerJob?.cancel()
            _ui.value = when (r) {
                is PT.Ok -> {
                    val method = if (task == AiTask.TRANSLATE) {
                        listOfNotNull(extractionResult?.model?.takeIf { it.isNotBlank() }, r.model.takeIf { it.isNotBlank() })
                            .distinct().joinToString(" + ").ifBlank { r.model }
                    } else r.model
                    AiUi.Done(
                        task, page, r.text, r.fromCache, method, targetRtl,
                        if (task == AiTask.TRANSLATE) (r.source ?: text) else null,
                        removedText = texts.removedTextForPage(docUri, page, s)
                    )
                }
                is PT.Fail -> AiUi.Error(r.message)
                PT.NoText -> AiUi.Idle
            }
          } catch (e: CancellationException) {
            timerJob?.cancel()
            _ui.value = AiUi.Idle
            throw e
          } catch (e: Exception) {
            timerJob?.cancel()
            _ui.value = AiUi.Error("خطای غیرمنتظره: " + (e.message ?: e.javaClass.simpleName) + "\nدوباره تلاش کنید.")
          } finally {
            timerJob?.cancel()
            if (_ui.value is AiUi.Loading) {
                _ui.value = AiUi.Idle
            }
          }
        }
    }

    fun runRangeSummary(doc: PdfDocument, docUri: String, fromPage: Int, toPage: Int, force: Boolean = false) {
        cancelTask()
        val last = (doc.pageCount - 1).coerceAtLeast(0)
        val from = minOf(fromPage, toPage).coerceIn(0, last)
        val to = maxOf(fromPage, toPage).coerceIn(0, last)
        _ui.value = AiUi.Loading(AiTask.SUMMARIZE, from, phasePreparing(), "", 0, to)
        startElapsedTimer(AiTask.SUMMARIZE, from, to)

        job = viewModelScope.launch {
          try {
            val s = settings.value
            val rtl = s.targetLanguage in RTL_LANGS
            val r = texts.summarizeRange(
                doc, docUri, from, to, s, force,
                onProgress = { phase ->
                    if (isActive) {
                        val curr = _ui.value as? AiUi.Loading
                        _ui.value = AiUi.Loading(AiTask.SUMMARIZE, from, phase, curr?.currentModel.orEmpty(), curr?.elapsedSeconds ?: 0, to)
                    }
                },
                onPartial = { partial -> if (isActive) _ui.value = AiUi.Streaming(AiTask.SUMMARIZE, from, partial, rtl, null, to) },
            )
            timerJob?.cancel()
            _ui.value = when (r) {
                is PT.Ok -> {
                    val handoutRtl = (s.handoutLanguage.ifBlank { s.targetLanguage }) in RTL_LANGS
                    val saved = saveHandoutPdf(
                        docUri = docUri,
                        docName = docUri.substringAfterLast('/').take(80),
                        from = from,
                        to = to,
                        markdown = r.text,
                        model = r.model,
                        rtl = handoutRtl,
                    )
                    AiUi.Done(
                        AiTask.SUMMARIZE, from, r.text, r.fromCache, r.model, rtl, null, to,
                        handoutPdfPath = saved?.pdfPath,
                        handoutId = saved?.id,
                    )
                }
                is PT.Fail -> AiUi.Error(r.message)
                PT.NoText -> AiUi.Done(AiTask.SUMMARIZE, from, "در این بازه متن قابل‌توجهی پیدا نشد (فقط شکل یا تصویر).", false, "—", false, null, to)
            }
          } catch (e: CancellationException) {
            timerJob?.cancel()
            _ui.value = AiUi.Idle
            throw e
          } catch (e: Exception) {
            timerJob?.cancel()
            _ui.value = AiUi.Error("خطای غیرمنتظره: " + (e.message ?: e.javaClass.simpleName) + "\nدوباره تلاش کنید.")
          } finally {
            timerJob?.cancel()
            if (_ui.value is AiUi.Loading) {
                _ui.value = AiUi.Idle
            }
          }
        }
    }

    fun dismissResult() {
        cancelTask()
    }

    val handouts = container.handoutDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun handoutsFor(docUri: String) = container.handoutDao.observeForDoc(docUri)

    fun deleteHandout(h: HandoutEntity) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                try { File(h.pdfPath).delete() } catch (_: Exception) {}
                container.handoutDao.delete(h.id)
            }
        }
    }

    private suspend fun saveHandoutPdf(
        docUri: String,
        docName: String,
        from: Int,
        to: Int,
        markdown: String,
        model: String,
        rtl: Boolean,
    ): HandoutEntity? = withContext(Dispatchers.IO) {
        try {
            val existing = container.handoutDao.findForRange(docUri, from, to)
            val id = existing?.id ?: UUID.randomUUID().toString()
            val dir = File(getApplication<Application>().filesDir, "handouts").also { it.mkdirs() }
            val safe = docName.replace(Regex("[^A-Za-z0-9._\\-\\u0600-\\u06FF]"), "_").take(40)
            val base = "p${from + 1}-${to + 1}_$id"
            val pdfFile = File(dir, "$base.pdf")
            if (existing != null && existing.pdfPath != pdfFile.absolutePath) {
                try { File(existing.pdfPath).delete() } catch (_: Exception) {}
            }
            val title = "جزوه · صفحات ${from + 1} تا ${to + 1}"
            MarkdownPdf.render(markdown, pdfFile, title = "$title\n$safe", rtl = rtl)
            val resolvedName = try {
                container.db.documentDao().get(docUri)?.name
            } catch (_: Exception) { null } ?: docName
            val entity = HandoutEntity(
                id = id,
                docUri = docUri,
                docName = resolvedName,
                fromPage = from,
                toPage = to,
                title = title,
                markdown = markdown,
                pdfPath = pdfFile.absolutePath,
                model = model,
                createdAt = System.currentTimeMillis(),
            )
            container.handoutDao.upsert(entity)
            container.handoutDao.deleteDuplicates(docUri, from, to, id)
            entity
        } catch (e: Exception) {
            null
        }
    }

    fun clearAttempts() {
        viewModelScope.launch { dao.clearAttempts() }
    }

    // ---------- settings ----------
    fun setSourceLanguage(v: String) = settingsRepo.update { it.copy(sourceLanguage = v) }
    fun setTargetLanguage(v: String) = settingsRepo.update { it.copy(targetLanguage = v) }
    fun setHandoutLanguage(v: String) = settingsRepo.update { it.copy(handoutLanguage = v) }
    fun setProfile(v: ReadingProfile) = settingsRepo.update { it.copy(profile = v) }
    fun setCustomInstruction(v: String) = settingsRepo.update { it.copy(customInstruction = v) }
    fun setPreferredModel(v: String) = settingsRepo.update { it.copy(preferredModel = v) }
    fun setOcrEngine(v: String) = settingsRepo.update { it.copy(ocrEngine = v) }
    fun setAiLocalCorrection(v: Boolean) = settingsRepo.update { it.copy(aiLocalCorrection = v) }
    fun setOcrQualityThreshold(v: Int) = settingsRepo.update { it.copy(ocrQualityThreshold = v.coerceIn(50, 100)) }
    fun setOcrOnlineFallback(v: Boolean) = settingsRepo.update { it.copy(ocrOnlineFallback = v) }
    fun setOcrMinConfidence(v: Int) = settingsRepo.update { it.copy(ocrMinConfidence = v.coerceIn(0, 100)) }
    fun setTextRepair(v: String) = settingsRepo.update { it.copy(textRepair = v) }
    fun setAiTypedTextCleanup(v: Boolean) = settingsRepo.update { it.copy(aiTypedTextCleanup = v) }
    fun setLocalPageCleanup(v: Boolean) = settingsRepo.update { it.copy(localPageCleanup = v) }
    fun setStripHeaders(v: Boolean) = settingsRepo.update { it.copy(stripHeaders = v) }
    fun setGoogleTranslateBase(v: String) = settingsRepo.update { it.copy(googleTranslateBase = v) }
    fun setPersistOcr(v: Boolean) = settingsRepo.update { it.copy(persistOcr = v) }
    fun setTranslationEngine(v: String) = settingsRepo.update { it.copy(translationEngine = v) }
    fun setTtsEngine(v: String) = settingsRepo.update { it.copy(ttsEngine = v) }
    fun setEdgeVoice(v: String) = settingsRepo.update { it.copy(edgeVoice = v) }
    fun setTtsFallbackGemini(v: Boolean) = settingsRepo.update { it.copy(ttsFallbackGemini = v) }
    fun setBilingual(v: Boolean) = settingsRepo.update { it.copy(bilingual = v) }
    fun setHighlightPdf(v: Boolean) = settingsRepo.update { it.copy(highlightPdf = v) }
    fun setReadText(v: Boolean) = settingsRepo.update { it.copy(readText = v) }
    fun setVoice(v: String) = settingsRepo.update { it.copy(voice = v) }
    fun setTranslateMainTextOnly(v: Boolean) = settingsRepo.update { it.copy(translateMainTextOnly = v) }
    fun setStudyMode(v: Boolean) = settingsRepo.update { it.copy(studyMode = v) }
    fun setPageViewMode(v: String) = settingsRepo.update { it.copy(pageViewMode = v) }
    fun clearCache() {
        texts.clearSession()
        container.readAloud.clearAudio()
        viewModelScope.launch { dao.clearCache() }
        refreshAudioBytes()
    }

    // ---------- providers / models / keys ----------
    fun setProviderEnabled(p: ProviderEntity, enabled: Boolean) {
        viewModelScope.launch { dao.upsertProvider(p.copy(enabled = enabled)) }
    }

    fun moveProvider(p: ProviderEntity, delta: Int) {
        viewModelScope.launch {
            val list = dao.providers()
            val i = list.indexOfFirst { it.id == p.id }
            val j = i + delta
            if (i < 0 || j !in list.indices) return@launch
            val a = list[i]
            val b = list[j]
            dao.upsertProvider(a.copy(position = b.position))
            dao.upsertProvider(b.copy(position = a.position))
        }
    }

    fun deleteProvider(p: ProviderEntity) {
        viewModelScope.launch {
            dao.deleteKeysOf(p.id)
            dao.deleteModelsOf(p.id)
            dao.deleteProvider(p.id)
        }
    }

    fun addModel(providerId: String, name: String, text: Boolean, vision: Boolean, tts: Boolean = false) {
        if (name.isBlank()) return
        viewModelScope.launch {
            val trimmed = name.trim()
            val existing = models.value.firstOrNull { it.providerId == providerId && it.modelName == trimmed }
            if (existing != null) {
                dao.upsertModel(
                    existing.copy(
                        supportsText = existing.supportsText || text,
                        supportsVision = existing.supportsVision || vision,
                        supportsTts = existing.supportsTts || tts,
                        enabled = true,
                    )
                )
                return@launch
            }
            val pos = (models.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertModel(
                ModelEntity(
                    id = UUID.randomUUID().toString(),
                    providerId = providerId,
                    modelName = trimmed,
                    supportsText = text,
                    supportsVision = vision,
                    enabled = true,
                    position = pos,
                    supportsTts = tts,
                )
            )
        }
    }

    fun setModelEnabled(m: ModelEntity, enabled: Boolean) {
        viewModelScope.launch {
            dao.upsertModel(m.copy(enabled = enabled))
            ensurePreferredModelsValid()
        }
    }

    fun deleteModel(m: ModelEntity) {
        viewModelScope.launch {
            dao.deleteModel(m.id)
            ensurePreferredModelsValid()
        }
    }

    /** Swap position with neighbor for manual reordering (cheapest-first is position ascending). */
    fun moveModel(m: ModelEntity, direction: Int) {
        viewModelScope.launch {
            val group = models.value
                .filter {
                    it.providerId == m.providerId &&
                        (if (m.supportsTts) it.supportsTts else it.supportsText)
                }
                .sortedBy { it.position }
            val idx = group.indexOfFirst { it.id == m.id }
            val targetIdx = idx + direction
            if (idx < 0 || targetIdx !in group.indices) return@launch
            val other = group[targetIdx]
            dao.upsertModel(m.copy(position = other.position))
            dao.upsertModel(other.copy(position = m.position))
        }
    }

    private suspend fun ensurePreferredModelsValid() {
        val s = settingsRepo.state.value
        val all = dao.models()
        if (s.preferredModel.isNotBlank()) {
            val ok = all.any { it.modelName == s.preferredModel && it.enabled && it.supportsText }
            if (!ok) {
                val fallback = all.filter { it.enabled && it.supportsText }.minByOrNull { it.position }?.modelName.orEmpty()
                settingsRepo.update { it.copy(preferredModel = fallback) }
            }
        }
        if (s.preferredTtsModel.isNotBlank()) {
            val ok = all.any { it.modelName == s.preferredTtsModel && it.enabled && it.supportsTts }
            if (!ok) {
                val fallback = all.filter { it.enabled && it.supportsTts }.minByOrNull { it.position }?.modelName.orEmpty()
                settingsRepo.update { it.copy(preferredTtsModel = fallback) }
            }
        }
    }

    private val _modelFetchMsg = MutableStateFlow<String?>(null)
    val modelFetchMsg = _modelFetchMsg.asStateFlow()

    /** Import models reported by Gemini ListModels for the first usable Gemini key. */
    fun fetchGeminiModelsFromApi() {
        viewModelScope.launch {
            _modelFetchMsg.value = if (settingsRepo.state.value.appLanguage == "en") "Fetching models…" else "در حال دریافت مدل‌ها…"
            try {
                val providers = dao.providers().filter { it.type == ProviderTypes.GEMINI && it.enabled }
                val p = providers.firstOrNull() ?: run {
                    _modelFetchMsg.value = if (settingsRepo.state.value.appLanguage == "en") "No Gemini provider" else "ارائه‌دهنده Gemini یافت نشد"
                    return@launch
                }
                val key = dao.keysFor(p.id).firstOrNull {
                    it.providerId == p.id && it.status != KeyStatus.DISABLED.name && it.status != KeyStatus.INVALID.name
                } ?: run {
                    _modelFetchMsg.value = if (settingsRepo.state.value.appLanguage == "en") "No active API key" else "کلید فعالی نیست"
                    return@launch
                }
                val secret = SecretBox.decrypt(key.secret)
                val gemini = GeminiProvider()
                val (textIds, ttsIds) = gemini.listModels(p.baseUrl, secret)
                if (textIds.isEmpty() && ttsIds.isEmpty()) {
                    _modelFetchMsg.value = if (settingsRepo.state.value.appLanguage == "en")
                        "API returned no models (check key / network)"
                    else
                        "API مدلی برنگرداند (کلید یا شبکه را بررسی کنید)"
                    return@launch
                }
                var added = 0
                val existing = dao.models().filter { it.providerId == p.id }
                fun nextPos() = (existing.maxOfOrNull { it.position } ?: -1) + 1 + added
                for (name in textIds) {
                    if (existing.any { it.modelName == name }) continue
                    dao.upsertModel(
                        ModelEntity(
                            id = UUID.randomUUID().toString(),
                            providerId = p.id,
                            modelName = name,
                            supportsText = true,
                            supportsVision = true,
                            enabled = false, // user enables deliberately — avoid activating unknown/expensive
                            position = nextPos(),
                            supportsTts = false,
                        )
                    )
                    added++
                }
                for (name in ttsIds) {
                    if (existing.any { it.modelName == name }) continue
                    dao.upsertModel(
                        ModelEntity(
                            id = UUID.randomUUID().toString(),
                            providerId = p.id,
                            modelName = name,
                            supportsText = false,
                            supportsVision = false,
                            enabled = false,
                            position = 100 + nextPos(),
                            supportsTts = true,
                        )
                    )
                    added++
                }
                _modelFetchMsg.value = if (settingsRepo.state.value.appLanguage == "en")
                    "Imported $added new models (disabled by default). Text=${textIds.size}, TTS=${ttsIds.size}"
                else
                    "$added مدل جدید اضافه شد (پیش‌فرض غیرفعال). متن=${textIds.size}، صوت=${ttsIds.size}"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                _modelFetchMsg.value = e.message ?: e.javaClass.simpleName
            }
        }
    }

    fun clearModelFetchMsg() { _modelFetchMsg.value = null }

    fun addKey(providerId: String, label: String, secret: String) {
        if (secret.isBlank()) return
        viewModelScope.launch {
            val pos = (keys.value.filter { it.providerId == providerId }.maxOfOrNull { it.position } ?: -1) + 1
            dao.upsertKey(
                ApiKeyEntity(
                    id = UUID.randomUUID().toString(), providerId = providerId,
                    label = label.trim().ifEmpty { "کلید ${pos + 1}" },
                    secret = SecretBox.encrypt(secret.trim()), position = pos,
                )
            )
        }
    }

    fun setKeyDisabled(k: ApiKeyEntity, disabled: Boolean) {
        viewModelScope.launch {
            dao.upsertKey(
                k.copy(
                    status = if (disabled) KeyStatus.DISABLED.name else KeyStatus.ACTIVE.name,
                    cooldownUntil = 0,
                )
            )
        }
    }

    fun deleteKey(k: ApiKeyEntity) { viewModelScope.launch { dao.deleteKey(k.id) } }

    fun testKey(k: ApiKeyEntity) {
        _testMessages.value = _testMessages.value + (k.id to phaseTesting())
        viewModelScope.launch {
            val msg = try { router.test(k.id) } catch (e: CancellationException) { throw e } catch (e: Exception) { "خطا: ${e.message}" }
            _testMessages.value = _testMessages.value + (k.id to msg)
        }
    }

    fun setAppLanguage(v: String) = settingsRepo.update { it.copy(appLanguage = v) }
    fun setPreferredTtsModel(v: String) = settingsRepo.update { it.copy(preferredTtsModel = v) }
    fun setHideFallbackText(v: Boolean) = settingsRepo.update { it.copy(hideFallbackText = v) }
    fun setNightMode(v: Boolean) = settingsRepo.update { it.copy(nightMode = v) }

    private fun isFaUi(): Boolean = settingsRepo.state.value.appLanguage != "en"
    private fun phasePreparing(): String = if (isFaUi()) "در حال آماده‌سازی…" else "Preparing…"
    private fun phaseProcessingText(): String = if (isFaUi()) "در حال پردازش متن…" else "Processing text…"
    private fun phaseTesting(): String = if (isFaUi()) "در حال تست…" else "Testing…"
}

fun formatWait(seconds: Long): String = when {
    seconds < 90 -> "$seconds ثانیه"
    seconds < 5400 -> "${seconds / 60} دقیقه"
    else -> "${seconds / 3600} ساعت"
}
