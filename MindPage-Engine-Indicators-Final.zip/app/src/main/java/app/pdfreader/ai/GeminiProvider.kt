package app.pdfreader.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.net.URLEncoder

class GeminiProvider : AiProvider {
    override suspend fun generate(
        baseUrl: String,
        model: String,
        apiKey: String,
        req: AiRequest,
        onPartial: ((String) -> Unit)?,
    ): AiResult = guarded {
        val first = attempt(baseUrl, model, apiKey, req, onPartial, includeThinking = true)
        if (first is AiResult.Fail && first.kind == FailKind.BAD_REQUEST &&
            first.detail.lowercase().contains("think")
        ) {
            attempt(baseUrl, model, apiKey, req, onPartial, includeThinking = false)
        } else first
    }

    private suspend fun attempt(
        baseUrl: String,
        model: String,
        apiKey: String,
        req: AiRequest,
        onPartial: ((String) -> Unit)?,
        includeThinking: Boolean,
    ): AiResult {
        val base = "${baseUrl.trimEnd('/')}/v1beta/models/$model"
        val url = if (onPartial != null) {
            "$base:streamGenerateContent?alt=sse"
        } else {
            "$base:generateContent"
        }

        val parts = JSONArray()
        req.imageJpeg?.let {
            val inline = JSONObject()
                .put("mime_type", "image/jpeg")
                .put("data", Base64.encodeToString(it, Base64.NO_WRAP))
            val part = JSONObject()
                .put("inline_data", inline)
            parts.put(part)
        }
        parts.put(JSONObject().put("text", req.prompt))

        // maxOutputTokens calculation based on task and estimated input tokens
        val maxTokens = req.maxOutputTokens ?: when (req.task) {
            AiTask.TRANSLATE -> {
                val estimatedInputTokens = (req.prompt.length / 3.5).toInt().coerceAtLeast(100)
                (estimatedInputTokens * 1.8).toInt().coerceIn(512, 8192)
            }
            AiTask.SUMMARIZE -> 1024
            AiTask.EXPLAIN -> 2048
            AiTask.EXTRACT -> 8192
            AiTask.TTS -> 512 // TTS uses synthesize path; text-gen fallback stays small
        }

        val gen = JSONObject()
            .put("temperature", 0.2)
            .put("maxOutputTokens", maxTokens)

        if (includeThinking) {
            val lower = model.lowercase()
            when {
                lower.contains("gemini-2.5") -> {
                    gen.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
                }
                lower.contains("gemini-3") -> {
                    gen.put("thinkingConfig", JSONObject().put("thinkingLevel", "minimal"))
                }
            }
        }

        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", gen)
        req.system?.let {
            body.put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", it))))
        }
        val headers = mapOf("x-goog-api-key" to apiKey)

        if (onPartial == null) {
            val res = postJson(url, headers, body.toString())
            return if (res.code in 200..299) parse(res.body) else classifyError(res.code, res.body)
        }

        val acc = StringBuilder()
        var finish = ""
        var block = ""
        var streamError: AiResult.Fail? = null
        var promptTok = 0
        var candTok = 0
        var thoughtTok = 0

        val res = postStream(url, headers, body.toString()) { line ->
            if (!line.startsWith("data:")) return@postStream
            val payload = line.removePrefix("data:").trim()
            if (payload.isEmpty()) return@postStream
            val j = try { JSONObject(payload) } catch (e: JSONException) { return@postStream }

            j.optJSONObject("usageMetadata")?.let { u ->
                promptTok = u.optInt("promptTokenCount", promptTok)
                candTok = u.optInt("candidatesTokenCount", candTok)
                thoughtTok = u.optInt("thoughtsTokenCount", thoughtTok)
            }

            j.optJSONObject("error")?.let { err ->
                streamError = classifyError(err.optInt("code", 500), payload)
                return@postStream
            }
            j.optJSONObject("promptFeedback")?.optString("blockReason")?.let { if (it.isNotEmpty()) block = it }
            val cand = j.optJSONArray("candidates")?.optJSONObject(0) ?: return@postStream
            cand.optString("finishReason").takeIf { it.isNotEmpty() }?.let { finish = it }
            val ps = cand.optJSONObject("content")?.optJSONArray("parts")
            if (ps != null) {
                var added = false
                for (i in 0 until ps.length()) {
                    val t = ps.getJSONObject(i).optString("text", "")
                    if (t.isNotEmpty()) { acc.append(t); added = true }
                }
                if (added) onPartial(acc.toString())
            }
        }
        if (res.code !in 200..299) return classifyError(res.code, res.body)
        val err = streamError
        if (err != null) return err

        val text = acc.toString().trim()
        if (text.isEmpty()) {
            if (finish == "MAX_TOKENS") {
                return AiResult.Fail(FailKind.EMPTY, "تمام شدن توکن فکر (finishReason=MAX_TOKENS بدون خروجی)")
            }
            val blocked = block.isNotEmpty() || finish == "SAFETY" || finish == "RECITATION" || finish == "PROHIBITED_CONTENT"
            return if (blocked) AiResult.Fail(FailKind.BLOCKED, block.ifEmpty { finish })
            else AiResult.Fail(FailKind.EMPTY, finish.ifEmpty { "پاسخ خالی" })
        }
        if (finish.isEmpty()) return AiResult.Fail(FailKind.SERVER, "پایان زودهنگام جریان پاسخ")
        return AiResult.Ok(text, null, promptTok, candTok, thoughtTok)
    }

    override suspend fun synthesize(
        baseUrl: String,
        model: String,
        apiKey: String,
        text: String,
        voice: String,
    ): AiResult = guarded {
        val url = "${baseUrl.trimEnd('/')}/v1beta/models/$model:generateContent"
        val speech = JSONObject().put(
            "voiceConfig",
            JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice.ifBlank { "Kore" })),
        )
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put(
                "generationConfig",
                JSONObject().put("responseModalities", JSONArray().put("AUDIO")).put("speechConfig", speech),
            )
        val res = postJson(url, mapOf("x-goog-api-key" to apiKey), body.toString())
        if (res.code !in 200..299) return@guarded classifyError(res.code, res.body)
        val root = JSONObject(res.body)
        val usage = root.optJSONObject("usageMetadata")
        val promptTokens = usage?.optInt("promptTokenCount", 0) ?: 0
        val candidatesTokens = usage?.optInt("candidatesTokenCount", 0) ?: 0
        val thoughtsTokens = usage?.optInt("thoughtsTokenCount", 0) ?: 0

        val parts = root.optJSONArray("candidates")?.optJSONObject(0)
            ?.optJSONObject("content")?.optJSONArray("parts")
        var pcm: ByteArray? = null
        var rate = 24000
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.getJSONObject(i)
                val d = part.optJSONObject("inlineData") ?: part.optJSONObject("inline_data") ?: continue
                pcm = Base64.decode(d.optString("data"), Base64.DEFAULT)
                val mime = d.optString("mimeType", d.optString("mime_type", ""))
                Regex("rate=(\\d+)").find(mime)?.groupValues?.get(1)?.toIntOrNull()?.let { rate = it }
                break
            }
        }
        val bytes = pcm
        if (bytes == null || bytes.isEmpty()) AiResult.Fail(FailKind.EMPTY, "no audio returned")
        else {
            val isWav = bytes.size >= 12 &&
                bytes[0] == 0x52.toByte() &&
                bytes[1] == 0x49.toByte() &&
                bytes[2] == 0x46.toByte() &&
                bytes[3] == 0x46.toByte()
            val finalWav = if (isWav) bytes else Wav.fromPcm16(bytes, rate)
            AiResult.Ok("", finalWav, promptTokens, candidatesTokens, thoughtsTokens)
        }
    }

    private fun parse(json: String): AiResult {
        val root = JSONObject(json)
        val usage = root.optJSONObject("usageMetadata")
        val promptTokens = usage?.optInt("promptTokenCount", 0) ?: 0
        val candidatesTokens = usage?.optInt("candidatesTokenCount", 0) ?: 0
        val thoughtsTokens = usage?.optInt("thoughtsTokenCount", 0) ?: 0

        val cands = root.optJSONArray("candidates")
        if (cands == null || cands.length() == 0) {
            val block = root.optJSONObject("promptFeedback")?.optString("blockReason").orEmpty()
            return if (block.isNotEmpty()) AiResult.Fail(FailKind.BLOCKED, block)
            else AiResult.Fail(FailKind.EMPTY, "no candidates")
        }
        val c = cands.getJSONObject(0)
        val ps = c.optJSONObject("content")?.optJSONArray("parts")
        val sb = StringBuilder()
        if (ps != null) for (i in 0 until ps.length()) sb.append(ps.getJSONObject(i).optString("text", ""))
        val text = sb.toString().trim()
        val fr = c.optString("finishReason")
        if (text.isEmpty()) {
            if (fr == "MAX_TOKENS") {
                return AiResult.Fail(FailKind.EMPTY, "تمام شدن توکن فکر (finishReason=MAX_TOKENS بدون خروجی)")
            }
            val kind = if (fr == "SAFETY" || fr == "RECITATION" || fr == "PROHIBITED_CONTENT") FailKind.BLOCKED else FailKind.EMPTY
            return AiResult.Fail(kind, fr.ifEmpty { "پاسخ خالی" })
        }
        return AiResult.Ok(text, null, promptTokens, candidatesTokens, thoughtsTokens)
    }


    /**
     * Lists model ids exposed by this API key.
     * @return Pair(textModelIds, ttsModelIds) — classification is heuristic from name + methods; never invents ids.
     */
    suspend fun listModels(baseUrl: String, apiKey: String): Pair<List<String>, List<String>> {
        val url = "${baseUrl.trimEnd('/')}/v1beta/models?pageSize=200"
        val res = getJson(url, mapOf("x-goog-api-key" to apiKey))
        if (res.code !in 200..299) return emptyList<String>() to emptyList()
        val root = try { JSONObject(res.body) } catch (_: Exception) { return emptyList<String>() to emptyList() }
        val arr = root.optJSONArray("models") ?: return emptyList<String>() to emptyList()
        val text = ArrayList<String>()
        val tts = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val m = arr.optJSONObject(i) ?: continue
            var name = m.optString("name")
            if (name.startsWith("models/")) name = name.removePrefix("models/")
            if (name.isBlank()) continue
            val methods = m.optJSONArray("supportedGenerationMethods")
            val methodSet = buildSet {
                if (methods != null) for (j in 0 until methods.length()) add(methods.optString(j))
            }
            val lower = name.lowercase()
            val isTts = lower.contains("tts") || lower.contains("audio")
            val canGenerate = "generateContent" in methodSet || methodSet.isEmpty()
            if (isTts) tts += name
            else if (canGenerate) text += name
        }
        return text.distinct() to tts.distinct()
    }
}
