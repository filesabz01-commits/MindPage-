package app.pdfreader.ai

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.sync.withLock
import java.time.LocalDate
import java.util.concurrent.ConcurrentHashMap

/**
 * Robust AI Router:
 * - Configurable model ladders with priority order (TTS: gemini-3.8-flash-lite-tts -> ...; Text: gemini-2.5-flash-lite -> ...)
 * - Automatic attempt logging to Room (timing, tokens, outcome)
 * - Exponential backoff on transient errors (SERVER, TIMEOUT)
 * - No wasteful retries on permanent errors (400 BAD_REQUEST, 404 MODEL_UNAVAILABLE, INVALID_KEY)
 * - Fast fallback to next model in priority order
 * - Strict cooldowns on saturated models and keys
 */
class AiRouter(
    private val dao: AiDao,
    private val impls: Map<String, AiProvider>,
) {
    init {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { dao.clearCooldowns() }
        }
    }

    sealed interface Outcome {
        class Ok(
            val text: String,
            val provider: String,
            val model: String,
            val audio: ByteArray? = null,
            val promptTokens: Int = 0,
            val candidatesTokens: Int = 0,
            val thoughtsTokens: Int = 0,
        ) : Outcome

        class Failed(val reason: Reason, val detail: String, val retryAtMs: Long? = null) : Outcome
    }

    enum class Reason { NOT_CONFIGURED, ALL_COOLING_DOWN, NETWORK, ALL_FAILED, TIMEOUT, CANCELLED }

    private companion object {
        const val CALL_MS = 90_000L
        const val SUMMARY_CALL_MS = 150_000L
        const val TTS_CALL_MS = 45_000L
        const val TOTAL_BUDGET_MS = 180_000L // 3 minutes total budget
        const val MAX_BAD_REQUESTS = 2 // identical payload errors are not retried on every model

        /** Gemini free-tier daily quota resets at midnight Pacific time; retrying every few minutes only wastes calls. */
        fun millisUntilDailyReset(now: Long = System.currentTimeMillis()): Long {
            val zone = java.time.ZoneId.of("America/Los_Angeles")
            val next = java.time.Instant.ofEpochMilli(now).atZone(zone).toLocalDate().plusDays(1)
                .atStartOfDay(zone).toInstant().toEpochMilli()
            return (next - now).coerceIn(15 * 60_000L, 12 * 60 * 60_000L)
        }
    }

    private val stateLock = Mutex()
    // Bound aggregate pressure across pages and features; pace starts to avoid burst RPM spikes.
    private val requestSlots = Semaphore(2)
    private val requestPaceLock = Mutex()
    @Volatile private var lastRequestStartedAt = 0L
    private val pairCooldown = ConcurrentHashMap<String, Long>()
    /** Round-robin cursor per provider so multiple API keys share load. */
    private val keyRotate = ConcurrentHashMap<String, Int>()
    private val coolingKinds = setOf(
        FailKind.DAILY_QUOTA, FailKind.RATE_LIMIT, FailKind.SERVER,
        FailKind.TIMEOUT, FailKind.MODEL_UNAVAILABLE,
    )

    /** Monotonic skip generation: requestSkip increments; each runWith captures its start gen. */
    private val skipGeneration = java.util.concurrent.atomic.AtomicLong(0)

    fun requestSkipCurrentModel() {
        skipGeneration.incrementAndGet()
    }

    fun forceClearAllCooldowns() {
        pairCooldown.clear()
        CoroutineScope(Dispatchers.IO).launch {
            runCatching { dao.clearCooldowns() }
        }
    }

    suspend fun run(
        cap: Capability,
        req: AiRequest,
        preferredModel: String = "",
        onModelActive: ((String) -> Unit)? = null,
        onPartial: ((String) -> Unit)? = null,
    ): Outcome = runWith(cap, req, preferredModel, onModelActive) { impl, baseUrl, model, secret ->
        impl.generate(baseUrl, model, secret, req, onPartial)
    }

    suspend fun synthesize(
        text: String,
        voice: String,
        preferredModel: String = "",
        onModelActive: ((String) -> Unit)? = null,
    ): Outcome = runWith(Capability.TTS, AiRequest(text, task = AiTask.TTS), preferredModel, onModelActive) { impl, baseUrl, model, secret ->
        impl.synthesize(baseUrl, model, secret, text, voice)
    }

    private suspend fun runWith(
        cap: Capability,
        req: AiRequest,
        preferredModel: String,
        onModelActive: ((String) -> Unit)?,
        call: suspend (AiProvider, String, String, String) -> AiResult,
    ): Outcome {
        var skipFloor = skipGeneration.get()
        val providers = dao.providers().filter { it.enabled }
        var configured = false
        var badRequests = 0
        var soonest = Long.MAX_VALUE
        val errors = mutableListOf<String>()
        val deadline = System.currentTimeMillis() + TOTAL_BUDGET_MS

        val perCallMs = when {
            cap == Capability.TTS -> TTS_CALL_MS
            req.task == AiTask.SUMMARIZE -> SUMMARY_CALL_MS
            else -> CALL_MS
        }

        fun expired() = System.currentTimeMillis() > deadline

        for (p in providers) {
            val impl = impls[p.type] ?: continue
            val models = orderedModels(p.id, cap, req.task, preferredModel)
            if (models.isEmpty()) continue

            val allKeys = dao.keysFor(p.id)
            val usableKeys = allKeys.filter { it.status != KeyStatus.INVALID.name && it.status != KeyStatus.DISABLED.name }
            val nowMs = System.currentTimeMillis()

            // Soft self-heal only: clear transient cooldowns (server/timeout), never wipe daily quota / rate-limit
            if (usableKeys.isNotEmpty() && usableKeys.all { it.cooldownUntil > nowMs }) {
                val hard = usableKeys.any {
                    it.status == KeyStatus.DAILY_QUOTA_EXCEEDED.name || it.status == KeyStatus.RATE_LIMITED.name
                }
                if (!hard) {
                    dao.clearCooldowns()
                }
            }

            // Rotate starting index so consecutive requests prefer different healthy keys.
            val allForProvider = dao.keysFor(p.id)
            val startIdx = if (allForProvider.isEmpty()) 0 else {
                val n = keyRotate.getOrDefault(p.id, 0)
                keyRotate[p.id] = n + 1
                n % allForProvider.size
            }
            val rotatedKeys = if (allForProvider.isEmpty()) emptyList()
            else allForProvider.drop(startIdx) + allForProvider.take(startIdx)

            for (k in rotatedKeys) {
                if (expired()) return Outcome.Failed(Reason.TIMEOUT, "زمان کلی درخواست (۳ دقیقه) تمام شد.")
                if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) continue
                configured = true
                if (k.cooldownUntil > System.currentTimeMillis()) {
                    soonest = minOf(soonest, k.cooldownUntil)
                    continue
                }

                var keyDead = false
                var keySoonest = Long.MAX_VALUE
                val kinds = mutableSetOf<FailKind>()

                for (m in models) {
                    if (keyDead) break
                    val pair = "${k.id}|${m.modelName}"
                    val cd = pairCooldown[pair] ?: 0L
                    if (cd > System.currentTimeMillis()) {
                        keySoonest = minOf(keySoonest, cd)
                        continue
                    }

                    onModelActive?.invoke(m.modelName)
                    var tries = 0
                    var rateRetried = false

                    while (true) {
                        if (expired()) return Outcome.Failed(Reason.TIMEOUT, "زمان کلی درخواست (۳ دقیقه) تمام شد.")
                        val skipNow = skipGeneration.get()
                        if (skipNow > skipFloor) {
                            skipFloor = skipNow
                            break
                        }

                        val secret = try {
                            SecretBox.decrypt(k.secret)
                        } catch (e: Exception) {
                            touch(k.id, false, FailKind.INVALID_KEY, "cannot decrypt")
                            keyDead = true
                            break
                        }

                        val attemptStart = System.currentTimeMillis()
                        val res: AiResult = requestSlots.withPermit {
                            requestPaceLock.withLock {
                                val waitMs = (1_200L - (System.currentTimeMillis() - lastRequestStartedAt)).coerceAtLeast(0L)
                                if (waitMs > 0) delay(waitMs)
                                lastRequestStartedAt = System.currentTimeMillis()
                            }
                            withTimeoutOrNull(perCallMs) {
                                call(impl, p.baseUrl, m.modelName, secret)
                            } ?: AiResult.Fail(FailKind.TIMEOUT, "عدم پاسخ در زمان مقرر")
                        }

                        val totalMs = System.currentTimeMillis() - attemptStart
                        val outcomeStr = if (res is AiResult.Ok) "OK" else (res as AiResult.Fail).kind.name

                        // Audit log to DB
                        dao.insertAttempt(
                            AiAttemptEntity(
                                timestamp = attemptStart,
                                task = req.task.name,
                                model = m.modelName,
                                keyLabel = k.label,
                                timeToFirstByteMs = totalMs,
                                totalTimeMs = totalMs,
                                outcome = outcomeStr,
                                promptTokens = if (res is AiResult.Ok) res.promptTokens else 0,
                                candidatesTokens = if (res is AiResult.Ok) res.candidatesTokens else 0,
                                thoughtsTokens = if (res is AiResult.Ok) res.thoughtsTokens else 0,
                                errorMessage = (res as? AiResult.Fail)?.detail?.take(250),
                            )
                        )

                        if (res is AiResult.Ok) {
                            touch(k.id, true, null, null)
                            pairCooldown.remove(pair)
                            return Outcome.Ok(
                                res.text, p.name, m.modelName, res.audio,
                                res.promptTokens, res.candidatesTokens, res.thoughtsTokens,
                            )
                        }

                        val fail = res as AiResult.Fail

                        // 404 Model Unavailable: retired or unsupported ID for key -> cooldown pair, fall through to next model
                        if (fail.kind == FailKind.MODEL_UNAVAILABLE) {
                            touch(k.id, false, fail.kind, fail.detail)
                            errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                            val cdUntil = System.currentTimeMillis() + 2 * 60 * 60_000L
                            pairCooldown[pair] = cdUntil
                            break
                        }

                        // 400 Bad Request: payload error, log and break without locking the key
                        if (fail.kind == FailKind.BAD_REQUEST) {
                            touch(k.id, false, fail.kind, fail.detail)
                            errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                            if (++badRequests >= MAX_BAD_REQUESTS) {
                                return Outcome.Failed(Reason.ALL_FAILED, errors.joinToString("\n"))
                            }
                            break
                        }

                        // Rate limit: 1 retry if retryAfter is short (<= 10s)
                        if (fail.kind == FailKind.RATE_LIMIT && !rateRetried && (fail.retryAfterMs ?: 6_000L) <= 10_000L) {
                            rateRetried = true
                            delay((fail.retryAfterMs ?: 5_000L).coerceIn(2_000L, 10_000L))
                            continue
                        }

                        // Transient (TIMEOUT/SERVER/NETWORK): exponential backoff up to 2 retries
                        val transient = fail.kind == FailKind.SERVER || fail.kind == FailKind.TIMEOUT
                        if (transient && tries < 2) {
                            val backoff = minOf(1_000L * (1L shl tries), 6_000L)
                            delay(backoff)
                            tries++
                            continue
                        }

                        touch(k.id, false, fail.kind, fail.detail)
                        errors += "${m.modelName}: ${fail.kind} ${fail.detail.take(90)}"
                        kinds += fail.kind
                        val now = System.currentTimeMillis()
                        val until = now + when (fail.kind) {
                            FailKind.DAILY_QUOTA -> millisUntilDailyReset(now)
                            FailKind.MODEL_UNAVAILABLE -> 2 * 60 * 60_000L
                            FailKind.BAD_REQUEST -> 0L
                            FailKind.RATE_LIMIT -> (fail.retryAfterMs ?: 15_000L).coerceIn(5_000L, 60_000L)
                            FailKind.SERVER -> 30_000L
                            FailKind.TIMEOUT, FailKind.NETWORK -> 8_000L
                            FailKind.BLOCKED, FailKind.EMPTY, FailKind.INVALID_KEY -> 0L
                        }

                        if (until > now) {
                            pairCooldown[pair] = until
                            keySoonest = minOf(keySoonest, until)
                        }

                        if (fail.kind == FailKind.INVALID_KEY) keyDead = true

                        if (fail.kind == FailKind.NETWORK) {
                            val detailLower = fail.detail.lowercase()
                            val isSocketReset = detailLower.contains("closed") || detailLower.contains("reset") || detailLower.contains("timeout") || detailLower.contains("broken pipe")
                            if (isSocketReset && tries < 1) {
                                tries++
                                delay(2000L)
                                continue
                            }
                            return Outcome.Failed(Reason.NETWORK, errors.lastOrNull() ?: fail.detail)
                        }

                        break
                    }
                }

                if (!keyDead && keySoonest != Long.MAX_VALUE && kinds.any { it in coolingKinds }) {
                    val status = when {
                        FailKind.DAILY_QUOTA in kinds -> KeyStatus.DAILY_QUOTA_EXCEEDED
                        FailKind.RATE_LIMIT in kinds -> KeyStatus.RATE_LIMITED
                        else -> KeyStatus.TEMPORARILY_UNAVAILABLE
                    }
                    setKeyCooldown(k.id, status, keySoonest)
                    soonest = minOf(soonest, keySoonest)
                }
            }
        }

        return when {
            !configured && soonest == Long.MAX_VALUE -> Outcome.Failed(Reason.NOT_CONFIGURED, "")
            errors.isEmpty() && soonest != Long.MAX_VALUE -> Outcome.Failed(Reason.ALL_COOLING_DOWN, "", soonest)
            else -> Outcome.Failed(Reason.ALL_FAILED, errors.joinToString("\n"), soonest.takeIf { it != Long.MAX_VALUE })
        }
    }

    private suspend fun orderedModels(providerId: String, cap: Capability, task: AiTask, preferred: String): List<ModelEntity> {
        val list = dao.models()
            .filter { it.providerId == providerId && it.enabled && it.supports(cap) }
            .sortedBy { it.position }
        if (list.isEmpty()) return emptyList()

        if (preferred.isNotBlank() && preferred in GeminiModels.KNOWN) {
            val pref = list.firstOrNull { it.modelName == preferred }
            if (pref != null) return listOf(pref) + list.filter { it !== pref }
        }

        val ladder = when {
            cap == Capability.TTS -> GeminiModels.TTS
            task == AiTask.EXPLAIN || task == AiTask.SUMMARIZE -> GeminiModels.FLASH_FIRST
            else -> GeminiModels.LITE_FIRST
        }

        return list.sortedBy { m ->
            val idx = ladder.indexOf(m.modelName)
            if (idx >= 0) idx else 1000 + m.position
        }
    }

    suspend fun test(keyId: String): String {
        val k = dao.key(keyId) ?: return "کلید پیدا نشد"
        val p = dao.provider(k.providerId) ?: return "provider پیدا نشد"
        val impl = impls[p.type] ?: return "نوع provider پشتیبانی نمی‌شود"
        val dbModels = dao.models().filter { it.providerId == p.id && it.enabled && it.supportsText }.sortedBy { it.position }
        // Always also try current public Gemini IDs so a stale DB model list cannot block the test.
        val names = LinkedHashSet<String>()
        dbModels.forEach { names += it.modelName }
        if (p.type == ProviderTypes.GEMINI) GeminiModels.TEXT.forEach { names += it }
        if (names.isEmpty()) return "ابتدا یک مدل متنی اضافه کنید"
        val secret = try { SecretBox.decrypt(k.secret) } catch (e: Exception) { return "رمزگشایی کلید ممکن نشد؛ کلید را دوباره وارد کنید" }

        var last = ""
        for (modelName in names) {
            val res = impl.generate(p.baseUrl, modelName, secret, AiRequest("Reply with the single word: OK"))
            if (res is AiResult.Ok) {
                touch(k.id, true, null, null)
                // Promote working model to top of DB list for future runs
                val existing = dbModels.firstOrNull { it.modelName == modelName }
                if (existing == null && p.type == ProviderTypes.GEMINI) {
                    dao.upsertModel(
                        ModelEntity(
                            id = "gemini-auto-$modelName",
                            providerId = p.id,
                            modelName = modelName,
                            supportsText = true,
                            supportsVision = true,
                            enabled = true,
                            position = 0,
                            supportsTts = false,
                        )
                    )
                }
                return "اتصال موفق بود ($modelName)"
            }
            val f = res as AiResult.Fail
            if (f.kind == FailKind.INVALID_KEY) {
                touch(k.id, false, f.kind, f.detail)
                return "کلید نامعتبر است: ${f.detail.take(120)}"
            }
            last = "$modelName: ${f.kind} ${f.detail.take(120)}"
        }
        return "هیچ مدلی جواب نداد. آخرین خطا: $last"
    }

    private suspend fun touch(id: String, success: Boolean, kind: FailKind?, detail: String?) =
        stateLock.withLock {
            val k = dao.key(id) ?: return@withLock
            val now = System.currentTimeMillis()
            val today = LocalDate.now().toString()
            val sameDay = k.usageDay == today
            val requests = (if (sameDay) k.requestsToday else 0) + 1
            val errors = (if (sameDay) k.errorsToday else 0) + if (success) 0 else 1
            var status = k.status
            var cooldown = k.cooldownUntil
            if (success) {
                status = KeyStatus.ACTIVE.name
                cooldown = 0
            } else if (kind == FailKind.INVALID_KEY) {
                status = KeyStatus.INVALID.name
                cooldown = 0
            }
            dao.upsertKey(
                k.copy(
                    status = status, cooldownUntil = cooldown, usageDay = today,
                    requestsToday = requests, errorsToday = errors, lastUsedAt = now,
                    lastError = if (success) null else "$kind: ${detail.orEmpty()}".take(200),
                )
            )
        }

    private suspend fun setKeyCooldown(id: String, status: KeyStatus, until: Long) = stateLock.withLock {
        val k = dao.key(id) ?: return@withLock
        if (k.status == KeyStatus.INVALID.name || k.status == KeyStatus.DISABLED.name) return@withLock
        dao.upsertKey(k.copy(status = status.name, cooldownUntil = until))
    }
}
