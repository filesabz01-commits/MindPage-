package app.pdfreader.ai

import android.graphics.Bitmap
import android.content.Context
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.util.Log
import android.util.LruCache
import app.pdfreader.core.pdf.PdfDocument
import app.pdfreader.tts.PdfiumTextEngine
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.io.ByteArrayOutputStream

sealed interface PT {
    class Ok(val text: String, val model: String = "", val fromCache: Boolean = false, val source: String? = null, val via: String? = null) : PT
    data object NoText : PT
    class Fail(val message: String) : PT
}

class PageTextService(
    private val dao: AiDao,
    private val router: AiRouter,
    private val engine: PdfiumTextEngine,
    private val appContext: Context,
) {
    private val session = LruCache<String, String>(300)
    private val sessionEngine = LruCache<String, String>(300)
    private val googleSemaphore = Semaphore(2)

    fun clearSession() = session.evictAll()

        private fun uiFa(s: ReadingSettings): Boolean = s.appLanguage != "en"

private fun extractKey(docUri: String, page: Int, s: ReadingSettings, structured: Boolean = false) = sha256(
        "v14|$docUri|$page|${s.sourceLanguage}|${s.ocrEngine}|${s.aiLocalCorrection}|${s.ocrQualityThreshold}|${s.stripHeaders}|${s.aiTypedTextCleanup}|${s.localPageCleanup}" +
            (if (structured) "|struct" else "")
    )

    private fun finalKey(task: AiTask, docUri: String, page: Int, s: ReadingSettings) = sha256(
        "v14|$docUri|$page|${task.name}|${if (task == AiTask.TRANSLATE) s.translationEngine else "ai"}|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|${s.aiTypedTextCleanup}|${s.localPageCleanup}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
    )

    private fun contentKey(task: AiTask, s: ReadingSettings, text: String): String = sha256(
        "v8|content|${task.name}|${if (task == AiTask.TRANSLATE) s.translationEngine else "ai"}|${s.targetLanguage}|${s.profile.name}|" +
            (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "") + "|" +
            sha256(text.trim().lowercase())
    )

    suspend fun cached(task: AiTask, docUri: String, page: Int, s: ReadingSettings): PT.Ok? {
        val k = finalKey(task, docUri, page, s)
        return dao.cached(k)?.let { PT.Ok(it.text, it.model, true, dao.cached("$k|src")?.text) }
    }

    /**
     * Check if text is already written in the target language (avoiding wasteful translation calls).
     */
    fun isAlreadyTargetLanguage(text: String, targetLang: String): Boolean {
        val letters = text.filter { it.isLetter() }
        if (letters.length < 20) return false
        if (targetLang in RTL_LANGS) {
            val rtlLetters = letters.count { ch ->
                ch in '\u0600'..'\u06FF' || ch in '\u0750'..'\u077F' || ch in '\uFB50'..'\uFDFF' || ch in '\uFE70'..'\uFEFF'
            }
            return (rtlLetters.toDouble() / letters.length) > 0.65
        }
        if (targetLang == "en") {
            val latinLetters = letters.count { it in 'a'..'z' || it in 'A'..'Z' }
            return (latinLetters.toDouble() / letters.length) > 0.80
        }
        return false
    }

    suspend fun extract(
        doc: PdfDocument, docUri: String, page: Int, s: ReadingSettings,
        force: Boolean = false, structured: Boolean = false, onPhase: (String) -> Unit = {},
    ): PT {
        // structured = true is used for translation: the geometry-based text (tables kept as rows/columns, margin
        // watermark removed) is preferred whenever it really found a table or watermark; otherwise plain reading order.
        val key = extractKey(docUri, page, s, structured)
        if (!force) {
            session.get(key)?.let {
            return if (it == Prompts.NO_TEXT) PT.NoText else PT.Ok(it, sessionEngine.get(key).orEmpty(), true)
        }
            dao.cached("ocr|${s.ocrEngine}|$key")?.let {
                session.put(key, it.text)
                sessionEngine.put(key, it.model)
                return PT.Ok(it.text, it.model, true)
            }
        }
        val textOnly = s.ocrEngine == "text"
        var verdict = TextVerdict(PageTextKind.NONE, if (force) "OCR درخواستی" else "")
        var layer = ""
        // force=true always means OCR; text-only mode never OCRs.
        if (!force) {
            onPhase(if (uiFa(s)) "در حال بررسی لایه‌ی متنی صفحه ${page + 1}…" else "Checking text layer on page ${page + 1}…")
            val raw = try {
                // Prefer plain reading-order text for speech/highlight; structured only as fallback
                // when the plain layer is empty (tables still recovered via structured path).
                // Plain order stays the default (best reading order for speech). When the plain layer shows publisher
                // watermark noise or a table caption, geometry-based extraction is used instead: it drops the vertical
                // margin watermark and keeps table rows/columns apart.
                val plain = engine.pageText(docUri, page)?.takeIf { it.trim().length >= 20 }
                val noiseOrCaption = plain != null && (
                    TextQuality.hasPublisherNoise(plain) ||
                        Regex("""(?i)\b(?:table|جدول)\s*\d""").containsMatchIn(plain)
                    )
                val geo = if (structured || noiseOrCaption || plain == null) engine.pageTextStructured(docUri, page) else null
                when {
                    geo == null -> plain
                    plain == null -> geo
                    geo.trim().length >= 20 && (noiseOrCaption || geo.contains("| --- |")) -> geo
                    else -> plain
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            if (raw != null) {
                layer = raw
                verdict = TextQuality.assess(raw)
            }
        }
        // Typed-text-only mode: never OCR. Clean whatever the PDF text layer gives us.
        if (textOnly && !force) {
            if (layer.isBlank()) {
                onPhase(if (uiFa(s)) "لایه‌ی متنی ندارد؛ حالت «فقط متن تایپ‌شده» OCR را اجرا نمی‌کند." else "No text layer; typed-text-only mode will not OCR.")
                return PT.NoText
            }
            // Even if assess marks it GARBLED, still try to clean and speak it — user opted out of OCR.
            val cleaned = cleanLayer(layer, key, page, s, onPhase)
            if (cleaned is PT.NoText && layer.trim().length >= 20) {
                // Soft fallback: return lightly cleaned original instead of empty / OCR
                val soft = TextQuality.localClean(layer).ifBlank { layer.trim() }
                if (soft.isNotBlank()) {
                    return commitPageText(
                        key, soft, localGood = false, engine = "pdf-layer", s = s,
                        via = if (uiFa(s)) "متن PDF (پاکسازی ملایم)" else "PDF text (soft clean)",
                        onPhase = onPhase, allowAiRepair = false,
                    )
                }
            }
            return cleaned
        }
        if (verdict.kind == PageTextKind.CLEAN) {
            val cleaned = cleanLayer(layer, key, page, s, onPhase)
            // localClean wiped a non-empty layer → treat as suspicious, try OCR once
            if (cleaned is PT.NoText && layer.trim().length >= 40) {
                onPhase(if (uiFa(s)) "پاک‌سازی محلی متن را خالی کرد؛ OCR صفحه ${page + 1}…" else "Local clean emptied text; OCR page ${page + 1}…")
                return ocrPage(doc, key, page, s, "OCR (پس از پاک‌سازی خالی)", onPhase)
            }
            return cleaned
        }
        onPhase(
            if (verdict.kind == PageTextKind.GARBLED) "متن PDF مخدوش است (${verdict.reason})؛ OCR صفحه ${page + 1}…"
            else "صفحه‌ی اسکن‌شده؛ OCR فشرده‌ی صفحه ${page + 1}…"
        )
        return ocrPage(doc, key, page, s, if (verdict.kind == PageTextKind.GARBLED) "OCR (متن مخدوش)" else "OCR", onPhase)
    }

    
    /** Optional low-token AI repair shared by every tool that calls extract(). */
    private fun wantsRepair(s: ReadingSettings, localGood: Boolean, text: String = ""): Boolean {
        if (s.textRepair == "off") return false
        if (s.textRepair == "always") return true
        // "weak" (default): also force repair when publisher noise or a table caption without Markdown grid
        if (!localGood) return true
        if (text.isNotBlank() && TextQuality.hasPublisherNoise(text)) return true
        val hasTableCaption = Regex("""(?i)\b(?:table|جدول)\s*\d""").containsMatchIn(text)
        val hasMdTable = text.contains("| ---") || text.contains("|---")
        if (hasTableCaption && !hasMdTable) return true
        return false
    }

    private suspend fun maybeRepair(
        text: String,
        localGood: Boolean,
        s: ReadingSettings,
        onPhase: (String) -> Unit,
    ): Pair<String, String> {
        var work = if (s.stripHeaders) TextQuality.stripPublisherNoise(text) else text
        if (work.isBlank() || work == Prompts.NO_TEXT) return text to ""
        if (!wantsRepair(s, localGood, work)) return work to ""
        val fa = uiFa(s)
        onPhase(if (fa) "آماده‌سازی متن با AI (پاکسازی + جدول)…" else "AI text prep (cleanup + tables)…")
        return when (val o = router.run(Capability.TEXT, Prompts.buildOcrRepair(s, work.take(12000)), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                var out = o.text.trim()
                if (out.contains(Prompts.NO_TEXT) && out.length < 32) return text to ""
                if (out.isBlank()) return text to ""
                // Reject pathological shrink
                if (out.length < text.length / 4 && text.length > 200) return text to ""
                if (s.stripHeaders) out = TextQuality.stripPageFurniture(out)
                else out = TextQuality.localClean(out)
                // Local geometry table promotion as a second pass on residual grids
                out = TextQuality.promoteTables(out)
                if (out.isBlank()) text to "" else out to (o.model.ifBlank { "repair" })
            }
            is AiRouter.Outcome.Failed -> text to ""
        }
    }

    private suspend fun commitPageText(
        key: String,
        text: String,
        localGood: Boolean,
        engine: String,
        s: ReadingSettings,
        via: String,
        onPhase: (String) -> Unit,
        allowAiRepair: Boolean = true,
        forceAiRepair: Boolean = false,
    ): PT {
        // Deterministic page cleanup runs locally before any optional AI repair when enabled.
        // Typed-text-only mode keeps the aggressive body cleanup (no tables/captions).
        // If the user disabled localPageCleanup, only normalize whitespace so speech/highlight stay close to the PDF layer.
        val locallyCleaned = when {
            s.ocrEngine == "text" -> TextQuality.readingBodyCleanup(text)
            s.localPageCleanup -> TextQuality.manualPageCleanup(text)
            else -> TextQuality.localClean(text)
        }
        val safeLocal = if (locallyCleaned.isBlank() && text.isNotBlank()) text else locallyCleaned
        if (s.localPageCleanup) {
            val removedLines = text.lines().filter { line ->
                line.isNotBlank() && locallyCleaned.lines().none { it.trim() == line.trim() }
            }
            if (removedLines.isNotEmpty()) {
                dao.upsertCache(CacheEntity("ocr_removed|$key", removedLines.joinToString("\n"), "Quarantined cleanup text", System.currentTimeMillis()))
            }
        }
        // AI OCR repair is intentionally limited to on-device OCR results.
        // Online Vision output is already model-produced and must not trigger another paid request.
        val (finalText, repairModel) = if (allowAiRepair && (forceAiRepair || s.aiLocalCorrection)) {
            maybeRepair(safeLocal, localGood, s.copy(textRepair = "always"), onPhase)
        } else safeLocal to ""
        if (finalText.isBlank() || finalText == Prompts.NO_TEXT) {
            session.put(key, Prompts.NO_TEXT)
            return PT.NoText
        }
        session.put(key, finalText)
        val label = if (repairModel.isNotBlank()) {
            if (s.ocrEngine == "local") "Local OCR + AI Correction ($repairModel)" else "AI-assisted OCR"
        } else if (engine == "pdf-layer") "PDF text layer" else "Local OCR"
        dao.upsertCache(CacheEntity("ocr|${s.ocrEngine}|$key", finalText, label, System.currentTimeMillis()))
        sessionEngine.put(key, label)
        val via2 = if (repairModel.isNotBlank()) "$via · $label" else via
        return PT.Ok(finalText, label, false, null, via2)
    }

    /** Grayscale + mild contrast boost for OCR. */
    private fun enhanceForOcr(src: Bitmap): Bitmap {
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val cm = ColorMatrix().apply {
            setSaturation(0f)
            val c = 1.25f
            val t = (-0.125f * 255f)
            postConcat(ColorMatrix(floatArrayOf(
                c, 0f, 0f, 0f, t,
                0f, c, 0f, 0f, t,
                0f, 0f, c, 0f, t,
                0f, 0f, 0f, 1f, 0f,
            )))
        }
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    private suspend fun cleanLayer(layer: String, key: String, page: Int, s: ReadingSettings, onPhase: (String) -> Unit): PT {
        val typedOnly = s.ocrEngine == "text"
        onPhase(
            if (typedOnly) {
                if (uiFa(s)) "متن تایپ‌شده؛ حذف هدر/فوتر، جدول، کپشن و اضافات…"
                else "Typed text; stripping headers, tables, captions and extras…"
            } else {
                if (uiFa(s)) "متن سالم PDF؛ پردازش سریع محلی…"
                else "Clean PDF text; local processing…"
            }
        )
        // Typed-text-only mode: aggressive body cleanup (headers, footers, page numbers,
        // footnotes, figure/table captions, tables). Other modes stay conservative.
        var local = when {
            typedOnly -> TextQuality.readingBodyCleanup(layer)
            s.stripHeaders -> TextQuality.stripPageFurniture(layer)
            else -> TextQuality.localClean(layer)
        }
        if (local.isBlank()) return PT.NoText
        // This optional path is deliberately limited to the native, selectable PDF text layer.
        // Scanned/OCR text continues to use the existing local/OCR repair settings.
        // In typed-only mode we already removed tables/captions; AI cleanup may reintroduce them — skip by default
        // unless the user explicitly enabled aiTypedTextCleanup.
        var cleanupModel = ""
        if (s.aiTypedTextCleanup && local.length <= 12000) {
            onPhase(if (uiFa(s)) "پاک‌سازی هوشمند متن تایپ‌شده با AI…" else "AI cleanup of selectable PDF text…")
            val input = local
            when (val result = router.run(Capability.TEXT, Prompts.buildTypedTextCleanup(s, input), s.preferredModel)) {
                is AiRouter.Outcome.Ok -> {
                    val candidate = result.text.trim()
                    val safe = candidate.isNotBlank() && candidate != Prompts.NO_TEXT &&
                        !(input.length > 300 && candidate.length < input.length / 3)
                    if (safe) {
                        // For typed-only reading, re-run body cleanup so AI does not bring tables/captions back.
                        local = if (typedOnly) TextQuality.readingBodyCleanup(candidate)
                        else TextQuality.promoteTables(candidate)
                        cleanupModel = result.model.ifBlank { "AI" }
                    }
                }
                is AiRouter.Outcome.Failed -> {
                    // Keep the local-cleaned original; optional AI failure must never block reading.
                    onPhase(if (uiFa(s)) "پاک‌سازی AI در دسترس نبود؛ متن محلی استفاده شد." else "AI cleanup unavailable; using locally cleaned text.")
                }
            }
        } else if (s.aiTypedTextCleanup && local.length > 12000) {
            onPhase(if (uiFa(s)) "متن این صفحه طولانی است؛ برای جلوگیری از حذف ناخواسته، پاک‌سازی AI رد شد." else "Page text is long; skipped AI cleanup to avoid truncation.")
        }
        val committed = commitPageText(
            key, local, localGood = true, engine = "pdf-layer", s = s,
            via = if (typedOnly) "متن PDF · بدنه خواندنی" else "متن PDF",
            onPhase = onPhase,
            // Body already cleaned offline in typed-only mode; avoid a second aggressive AI pass unless requested.
            allowAiRepair = if (typedOnly) false else (!s.aiTypedTextCleanup || local.length > 12000),
        )
        return if (committed is PT.Ok && cleanupModel.isNotBlank())
            PT.Ok(committed.text, "pdf-layer+AI-cleanup ($cleanupModel)", committed.fromCache, committed.source, "متن PDF · پاک‌سازی AI")
        else committed
    }

    /** Three public modes: local, ai (text-only correction), and auto. */
    private fun ocrMode(s: ReadingSettings): String = when (s.ocrEngine) {
        "ai", "ai_ocr" -> "ai"
        "local", "local_only", "local_fa", "local_en" -> "local"
        else -> "auto"
    }

    private class LocalOcrOutcome(
        val text: String, val engine: String, val good: Boolean, val failure: String?,
        val quality: Int = 0,
    )

    private fun engineLabel(engine: String): String =
        if (engine == "mlkit") "ML Kit" else "Tesseract فارسی (آفلاین)"

    /**
     * Runs the on-device recognizers. Source language decides which one runs:
     * fa/ar -> Tesseract (fas) only, other explicit languages -> ML Kit only,
     * auto -> ML Kit first, Tesseract only if the Latin result is weak.
     */
    private suspend fun runLocalOcr(doc: PdfDocument, bmp: Bitmap, page: Int, s: ReadingSettings): LocalOcrOutcome {
        val fa = uiFa(s)
        val explicitlyRtl = s.sourceLanguage == "fa" || s.sourceLanguage == "ar"
        val isAuto = s.sourceLanguage == "auto"
        var failure: String? = null

        var latinText = ""
        if (!explicitlyRtl) {
            val raw = try {
                withContext(Dispatchers.Default) { LocalOcr.recognize(bmp) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                failure = if (fa) "OCR ML Kit اجرا نشد: ${e.message ?: e.javaClass.simpleName}" else "ML Kit OCR failed: ${e.message ?: e.javaClass.simpleName}"
                ""
            }
            if (raw.isNotBlank()) {
                latinText = if (s.stripHeaders) TextQuality.stripPageFurniture(raw) else TextQuality.localClean(raw)
            }
        }
        val latinQuality = TextQuality.ocrQualityScore(latinText, OcrScript.LATIN, null)
        val latinGood = latinText.isNotBlank() && latinQuality >= s.ocrQualityThreshold

        var persianText = ""
        var persianConf: Int? = null
        val needPersian = explicitlyRtl || (isAuto && !latinGood)
        if (needPersian) {
            // Tesseract reads small Persian print better from a larger render.
            val big: Bitmap? = try {
                withContext(Dispatchers.IO) { doc.render(page, 2200) }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Throwable) {
                null
            }
            val src = big ?: bmp
            try {
                val r = withContext(Dispatchers.Default) { LocalOcr.recognizePersian(appContext, src) }
                persianConf = if (r.confidence >= 0) r.confidence else null
                if (r.text.isNotBlank()) {
                    persianText = if (s.stripHeaders) TextQuality.stripPageFurniture(r.text) else TextQuality.localClean(r.text)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (t: Throwable) {
                Log.e("PageTextService", "Persian OCR failed", t)
                failure = if (fa) "OCR فارسی محلی اجرا نشد: ${t.message ?: t.javaClass.simpleName}" else "Local Persian OCR failed: ${t.message ?: t.javaClass.simpleName}"
            } finally {
                big?.recycle()
            }
        }

        val persianLetters = persianText.count { it in '\u0600'..'\u06FF' || it in '\uFB50'..'\uFEFF' }
        val latinLetters = latinText.count { it in 'A'..'Z' || it in 'a'..'z' }
        val usePersian = persianText.isNotBlank() && (
            explicitlyRtl ||
                (persianLetters >= 12 && persianLetters > latinLetters / 2) ||
                (latinText.length < 40 && persianLetters >= 8)
            )
        return if (usePersian) {
            LocalOcrOutcome(
                persianText, "tesseract-fas",
                TextQuality.ocrQualityScore(persianText, OcrScript.PERSIAN, persianConf) >= s.ocrQualityThreshold &&
                    (persianConf == null || persianConf >= s.ocrMinConfidence),
                failure, TextQuality.ocrQualityScore(persianText, OcrScript.PERSIAN, persianConf)
            )
        } else {
            LocalOcrOutcome(latinText, if (latinText.isBlank()) "" else "mlkit", latinGood, failure, latinQuality)
        }
    }

    /**
     * OCR path. Mode (Settings → OCR engine):
     *  - local:      on-device first; if empty or low quality, try online (Gemini Vision);
     *                if online is unavailable, keep the best local text (marked low quality).
     *  - local_only: on-device only, never goes online.
     *  - online:     Gemini Vision only.
     */
    private suspend fun ocrPage(
        doc: PdfDocument, key: String, page: Int, s: ReadingSettings, via: String,
        onPhase: (String) -> Unit = {},
    ): PT {
        val mode = ocrMode(s)
        val fa = uiFa(s)
        var bmp = try {
            withContext(Dispatchers.IO) {
                val raw = doc.render(page, 1800)
                val enhanced = enhanceForOcr(raw)
                if (enhanced !== raw) raw.recycle()
                enhanced
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            return PT.Fail(if (fa) "رندر صفحه برای OCR ممکن نشد." else "Could not render page for OCR.")
        }

        var local = try {
            onPhase(if (fa) "OCR محلی صفحه ${page + 1}…" else "Local OCR page ${page + 1}…")
            runLocalOcr(doc, bmp, page, s)
        } catch (e: CancellationException) {
            bmp.recycle()
            throw e
        } catch (t: Throwable) {
            Log.e("PageTextService", "Local OCR failed", t)
            LocalOcrOutcome("", "", false, t.message, 0)
        }

        // Auto mode gets one deterministic higher-resolution local retry before AI is considered.
        if (mode == "auto" && local.quality < s.ocrQualityThreshold) {
            onPhase(if (fa) "کیفیت OCR کافی نیست (${local.quality}٪)؛ تلاش مجدد محلی…" else "OCR quality is low (${local.quality}%); retrying locally…")
            val retry = try {
                withContext(Dispatchers.IO) {
                    val raw = doc.render(page, 2600)
                    val enhanced = enhanceForOcr(raw)
                    if (enhanced !== raw) raw.recycle()
                    enhanced
                }
            } catch (_: Throwable) { null }
            if (retry != null) {
                val second = try { runLocalOcr(doc, retry, page, s) }
                catch (e: CancellationException) { retry.recycle(); bmp.recycle(); throw e }
                catch (_: Throwable) { null }
                retry.recycle()
                if (second != null && second.quality > local.quality) local = second
            }
        }

        bmp.recycle()
        if (local.text.isBlank()) {
            return local.failure?.let { PT.Fail(it) } ?: PT.NoText
        }

        val shouldUseAi = mode == "ai" ||
            (mode == "auto" && local.quality < s.ocrQualityThreshold) ||
            (mode == "local" && s.aiLocalCorrection)
        val status = when {
            shouldUseAi -> if (fa) "اصلاح متن و ساختار استخراج‌شده با AI…" else "AI correction of extracted text and layout…"
            local.good -> if (fa) "کیفیت OCR مناسب است (${local.quality}٪)." else "OCR quality is sufficient (${local.quality}%)."
            else -> if (fa) "خروجی محلی با کیفیت پایین نگه داشته شد (${local.quality}٪)." else "Keeping low-confidence local OCR (${local.quality}%)."
        }
        onPhase(status)
        val weak = if (local.good) "" else if (fa) " · کیفیت ${local.quality}٪" else " · quality ${local.quality}%"
        return commitPageText(
            key = key,
            text = local.text,
            localGood = local.good,
            engine = local.engine,
            s = s,
            via = "$via · ${engineLabel(local.engine)}$weak",
            onPhase = onPhase,
            allowAiRepair = shouldUseAi,
            forceAiRepair = shouldUseAi,
        )
    }


    /** Unified cache methods */
    suspend fun cachedOcrMethod(docUri: String, page: Int, s: ReadingSettings, structured: Boolean = false): String? {
        val key = extractKey(docUri, page, s, structured)
        return dao.cached("ocr|${s.ocrEngine}|$key")?.model
    }

    suspend fun removedTextForPage(docUri: String, page: Int, s: ReadingSettings, structured: Boolean = false): String? {
        val key = extractKey(docUri, page, s, structured)
        return dao.cached("ocr_removed|$key")?.text
    }

    suspend fun cachedText(key: String): String? = dao.cached(key)?.text
    suspend fun loadSavedText(key: String): String? = cachedText(key)

    suspend fun saveText(key: String, text: String) =
        dao.upsertCache(CacheEntity(key, text, "", System.currentTimeMillis()))

    /**
     * Persist a translation produced by the read-aloud path under the same keys
     * that the plain "ترجمه" button uses, so the two features share one cache and
     * never spend tokens twice for the same page.
     */
    suspend fun saveTranslation(docUri: String, page: Int, s: ReadingSettings, translated: String, source: String) {
        val pageKey = finalKey(AiTask.TRANSLATE, docUri, page, s)
        val cKey = contentKey(AiTask.TRANSLATE, s, source)
        val now = System.currentTimeMillis()
        dao.upsertCache(CacheEntity(pageKey, translated, "segment", now))
        dao.upsertCache(CacheEntity(cKey, translated, "segment", now))
        dao.upsertCache(CacheEntity("$pageKey|src", source, "", now))
    }

    class SegmentResult(val items: List<String>?, val error: String?, val engine: String? = null)

    suspend fun translateSegments(docUri: String, page: Int, s: ReadingSettings, segments: List<String>): SegmentResult {
        if (segments.isEmpty()) return SegmentResult(emptyList(), null)
        val engine = s.translationEngine
        val key = sha256("seg|v7|$docUri|$page|$engine|${s.sourceLanguage}|${s.targetLanguage}|${s.translateMainTextOnly}|${s.profile.name}|${if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else ""}|" + segments.joinToString(""))
        dao.cached(key)?.let { c -> parseSegments(c.text, segments.size)?.let { return SegmentResult(it, null, c.model) } }

        if (s.translationEngine == "google") {
            return googleSegments(segments, key, s)
        }
        if (s.translationEngine == "auto") {
            val translated = segments.toMutableList()
            val usedEngines = linkedSetOf<String>()
            val aiIndexes = mutableListOf<Int>()
            val googleIndexes = mutableListOf<Int>()
            segments.forEachIndexed { index, segment ->
                val kind = translationBlocks(segment).map { it.kind }
                when {
                    kind.all { it == "protected" } -> translated[index] = segment
                    kind.any { it == "ai" } -> aiIndexes += index
                    else -> googleIndexes += index
                }
            }
            if (googleIndexes.isNotEmpty()) {
                val result = googleSegments(googleIndexes.map { segments[it] }, "$key|google", s)
                if (result.items == null) return result
                result.engine?.let(usedEngines::add)
                googleIndexes.forEachIndexed { i, idx -> translated[idx] = result.items[i] }
            }
            if (aiIndexes.isNotEmpty()) {
                when (val outcome = router.run(
                    Capability.TEXT,
                    Prompts.buildSegments(s.copy(translateMainTextOnly = false), aiIndexes.map { segments[it] }),
                    s.preferredModel
                )) {
                    is AiRouter.Outcome.Ok -> {
                        usedEngines += outcome.model.ifBlank { "Gemini AI" }
                        val parsed = parseSegments(outcome.text, aiIndexes.size)
                        if (parsed != null) aiIndexes.forEachIndexed { i, idx -> translated[idx] = parsed[i] }
                        else {
                            val fallback = googleSegments(aiIndexes.map { segments[it] }, "$key|fallback", s)
                            if (fallback.items == null) return fallback
                            fallback.engine?.let(usedEngines::add)
                            aiIndexes.forEachIndexed { i, idx -> translated[idx] = fallback.items[i] }
                        }
                    }
                    is AiRouter.Outcome.Failed -> {
                        val fallback = googleSegments(aiIndexes.map { segments[it] }, "$key|fallback", s)
                        if (fallback.items == null) return fallback
                        fallback.engine?.let(usedEngines::add)
                        aiIndexes.forEachIndexed { i, idx -> translated[idx] = fallback.items[i] }
                    }
                }
            }
            val joined = translated.mapIndexed { i, item -> "[[${i + 1}]] $item" }.joinToString("\n\n")
            val engineLabel = usedEngines.joinToString(" + ").ifBlank { "Auto translation" }
            dao.upsertCache(CacheEntity(key, joined, engineLabel, System.currentTimeMillis()))
            return SegmentResult(translated, null, engineLabel)
        }

        // Gemini path: exactly one structured batch request. Do not retry the same page
        // or fan out into one paid request per segment when marker parsing fails.
        when (val o = router.run(Capability.TEXT, Prompts.buildSegments(s.copy(translateMainTextOnly = false), segments), s.preferredModel)) {
            is AiRouter.Outcome.Ok -> {
                val items = parseSegments(o.text, segments.size)
                if (items != null) {
                    dao.upsertCache(CacheEntity(key, o.text, o.model, System.currentTimeMillis()))
                    return SegmentResult(items, null, o.model.ifBlank { "Gemini AI" })
                }
                // The response lost its segment markers. Avoid another Gemini call;
                // Google is the non-AI fallback for this already-failed batch.
                return googleSegments(segments, key, s)
            }
            is AiRouter.Outcome.Failed -> {
                if (o.reason == AiRouter.Reason.NOT_CONFIGURED || o.reason == AiRouter.Reason.ALL_COOLING_DOWN) {
                    return googleSegments(segments, key, s)
                }
                return SegmentResult(null, describe(o))
            }
        }
    }

    private suspend fun googleSegments(
        segments: List<String>,
        key: String,
        s: ReadingSettings,
    ): SegmentResult = try {
        val translatedList = coroutineScope {
            segments.map { seg ->
                async(Dispatchers.IO) {
                    val segHash = sha256(seg)
                    val segKey = "gt_seg|v7|${s.sourceLanguage}|${s.targetLanguage}|$segHash"
                    val cached = dao.cached(segKey)?.text
                    if (!cached.isNullOrBlank()) {
                        cached
                    } else {
                        googleSemaphore.withPermit {
                            val t = GoogleTranslateService.translate(
                                seg,
                                s.sourceLanguage,
                                s.targetLanguage,
                                s.googleTranslateBase,
                                s.stripHeaders
                            )
                            dao.upsertCache(CacheEntity(segKey, t, "Google Translate", System.currentTimeMillis()))
                            t
                        }
                    }
                }
            }.awaitAll()
        }
        val joined = translatedList.mapIndexed { i, t -> "[[${i + 1}]] $t" }.joinToString("\n\n")
        dao.upsertCache(CacheEntity(key, joined, "Google Translate", System.currentTimeMillis()))
        SegmentResult(translatedList, null, "Google Translate")
    } catch (e: Exception) {
        SegmentResult(null, "Google Translate: ${e.message}")
    }

    /**
     * More tolerant parser: accepts [[1]], [[ 1 ]], [1], 1. etc. and reconstructs by number order.
     * Falls back to sequential split if markers are missing but count of paragraphs matches.
     */
    private fun parseSegments(raw: String, n: Int): List<String>? {
        if (n <= 0) return null
        // Primary: numbered markers [[N]] or [N] or N.
        val markRegex = Regex("""(?:\[\[|\[)\s*(\d+)\s*(?:\]\]|\])|(?:^|\n)\s*(\d+)[\.\)]\s+""", RegexOption.MULTILINE)
        val marks = markRegex.findAll(raw).mapNotNull { m ->
            val num = (m.groupValues[1].ifBlank { m.groupValues[2] }).toIntOrNull() ?: return@mapNotNull null
            num to m.range
        }.toList()
        if (marks.isNotEmpty()) {
            val byNum = sortedMapOf<Int, String>()
            for ((i, pair) in marks.withIndex()) {
                val (num, range) = pair
                val end = if (i + 1 < marks.size) marks[i + 1].second.first else raw.length
                val t = raw.substring(range.last + 1, end).trim()
                    .removePrefix("\n").trim()
                if (t.isNotBlank()) byNum[num] = t
            }
            if (byNum.size == n && byNum.keys.first() == 1 && byNum.keys.last() == n) {
                return (1..n).map { byNum[it]!! }
            }
            // Accept if we got exactly the expected consecutive numbers even if start is not 1 (rare)
            if (byNum.size == n) {
                val sorted = byNum.toList().sortedBy { it.first }
                if (sorted.zipWithNext().all { (a, b) -> b.first == a.first + 1 }) {
                    return sorted.map { it.second }
                }
            }
        }
        // Fallback: split on blank lines if the model ignored numbering but produced the right count of blocks
        val blocks = raw.split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotBlank() && !it.matches(Regex("^\\[\\[?\\d+\\]?\\]$")) }
        if (blocks.size == n) return blocks
        return null
    }


    private data class TranslationBlock(val raw: String, val kind: String)

    /** Split only at structural boundaries; tables remain whole row/column grids. */
    private fun translationBlocks(text: String): List<TranslationBlock> {
        val lines = text.replace("\r\n", "\n").replace('\r', '\n').lines()
        val groups = mutableListOf<String>()
        val current = mutableListOf<String>()
        fun flush() {
            if (current.isNotEmpty()) {
                groups += current.joinToString("\n").trim()
                current.clear()
            }
        }
        var inTable = false
        for (line in lines) {
            val t = line.trim()
            val tableLine = t.startsWith("|") && t.count { it == '|' } >= 2
            if (t.isBlank()) {
                flush()
                inTable = false
            } else if (tableLine) {
                if (!inTable) flush()
                current += line
                inTable = true
            } else {
                if (inTable) flush()
                current += line
                inTable = false
            }
        }
        flush()
        return groups.map { raw ->
            val t = raw.trim()
            val isTable = t.lines().count { it.trim().startsWith("|") } >= 2
            val formulaOnly = Regex("""(?s)^[\s$\\(){}\[\]0-9A-Za-z_+\-*/=<>.,:;|^]+$""").matches(t) &&
                (t.contains("=") || t.contains("∫") || t.contains("∑") || t.contains("√"))
            val formulaMixed = t.contains(Regex("""(?:\\[a-zA-Z]+|[∑∫√≈≠≤≥∞]|[A-Za-z]\s*=\s*[^ ]+)"""))
            val technical = Regex("""(?i)\b(?:figure|fig\.|table|equation|eq\.|algorithm|theorem|lemma|definition)\s+\d""").containsMatchIn(t) ||
                Regex("""\b(?:MPa|kPa|psi|N·m|kg/m[³3]|m/s|°C|°F)\b""").containsMatchIn(t) ||
                (t.count { it.isUpperCase() } >= 8 && t.count { it.isLetter() } > 30)
            val kind = when {
                formulaOnly -> "protected"
                isTable || formulaMixed || technical -> "ai"
                else -> "google"
            }
            TranslationBlock(raw, kind)
        }
    }

    private suspend fun autoTranslateAndCache(
        text: String, pageKey: String, cKey: String, s: ReadingSettings,
        onModelActive: ((String) -> Unit)?, onPartial: ((String) -> Unit)?,
    ): PT {
        val blocks = translationBlocks(text)
        if (blocks.isEmpty()) return PT.Ok(text, "Auto Translation", false, text)
        val translated = blocks.map { it.raw }.toMutableList()
        val engines = linkedSetOf<String>()
        val blockEngines = blocks.map { if (it.kind == "protected") "Protected formula" else "" }.toMutableList()
        val blockKeys = blocks.map { block ->
            "block_translation|v2|${s.sourceLanguage}|${s.targetLanguage}|${s.profile.name}|${if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else ""}|${sha256(block.kind + "|" + block.raw)}"
        }
        val cachedBlocks = blockKeys.map { dao.cached(it) }
        cachedBlocks.forEachIndexed { index, cached ->
            if (cached != null) {
                translated[index] = cached.text
                blockEngines[index] = cached.model.ifBlank { if (blocks[index].kind == "protected") "Protected formula" else "" }
                if (cached.model.isNotBlank() && blocks[index].kind != "protected") engines += cached.model
            }
        }
        var aiIndexes = blocks.indices.filter { blocks[it].kind == "ai" && cachedBlocks[it] == null }
        val googleIndexes = blocks.indices.filter { blocks[it].kind == "google" && cachedBlocks[it] == null }

        // Ordinary prose is sent to Google as one structure-preserving page payload.
        if (googleIndexes.isNotEmpty()) {
            onModelActive?.invoke("Google Translate")
            val googlePayload = googleIndexes.joinToString("\n\n") { blocks[it].raw }
            try {
                val result = GoogleTranslateService.translate(
                    googlePayload, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders
                )
                val translatedParts = result.split(Regex("\n\\s*\n")).map { it.trim() }.filter { it.isNotBlank() }
                if (translatedParts.size == googleIndexes.size) {
                    googleIndexes.forEachIndexed { i, idx -> translated[idx] = translatedParts[i] }
                } else if (googleIndexes.size == 1) {
                    translated[googleIndexes[0]] = result
                } else {
                    // Ambiguous boundaries: preserve mapping by retrying only these prose blocks.
                    for (idx in googleIndexes) {
                        translated[idx] = GoogleTranslateService.translate(
                            blocks[idx].raw, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders
                        )
                    }
                }
                googleIndexes.forEach { blockEngines[it] = "Google Translate" }
                engines += "Google Translate"
            } catch (e: Exception) {
                return PT.Fail("Google Translate: ${e.message ?: "network error"}")
            }
        }

        // A visibly poor Google result is promoted to the same single AI batch.
        val weakGoogle = googleIndexes.filter { idx ->
            val source = blocks[idx].raw.filter { it.isLetter() }
            val result = translated[idx].filter { it.isLetter() }
            val same = source.equals(result, ignoreCase = true)
            val wrongScript = when {
                s.targetLanguage in RTL_LANGS -> result.count { it in '\u0600'..'\u06FF' || it in '\uFB50'..'\uFEFF' }.toDouble() / result.length.coerceAtLeast(1) < 0.12
                s.targetLanguage == "en" -> result.count { it in 'A'..'Z' || it in 'a'..'z' }.toDouble() / result.length.coerceAtLeast(1) < 0.25
                else -> false
            }
            same || wrongScript
        }
        aiIndexes = (aiIndexes + weakGoogle).distinct()

        // All special and low-quality Google blocks share one structured AI batch.
        if (aiIndexes.isNotEmpty()) {
            onModelActive?.invoke("AI Translation")
            val payloads = aiIndexes.map { blocks[it].raw }
            val aiResult = router.run(
                Capability.TEXT,
                Prompts.buildSegments(s.copy(translateMainTextOnly = false), payloads),
                s.preferredModel, onModelActive
            )
            when (aiResult) {
                is AiRouter.Outcome.Ok -> {
                    val parsed = parseSegments(aiResult.text, payloads.size)
                    if (parsed != null) {
                        aiIndexes.forEachIndexed { i, idx ->
                            translated[idx] = parsed[i]
                            blockEngines[idx] = "AI Translation"
                        }
                        engines += "AI Translation"
                    } else {
                        // Keep table structure by falling back block-wise to Google, not by flattening.
                        for (idx in aiIndexes) {
                            translated[idx] = GoogleTranslateService.translate(
                                blocks[idx].raw, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders
                            )
                            blockEngines[idx] = "Google Translate"
                        }
                        engines += "Google Translate"
                    }
                }
                is AiRouter.Outcome.Failed -> {
                    for (idx in aiIndexes) {
                        translated[idx] = GoogleTranslateService.translate(
                            blocks[idx].raw, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders
                        )
                        blockEngines[idx] = "Google Translate"
                    }
                    engines += "Google Translate"
                }
            }
        }

        // Formula-only blocks are protected byte-for-byte; surrounding prose is translated.
        val finalText = translated.joinToString("\n\n")
        val label = engines.joinToString(" + ").ifBlank { "Protected content" }
        val now = System.currentTimeMillis()
        blocks.forEachIndexed { index, block ->
            val engine = blockEngines[index].ifBlank {
                if (block.kind == "protected") "Protected formula" else "Google Translate"
            }
            dao.upsertCache(CacheEntity(blockKeys[index], translated[index], engine, now))
        }
        dao.upsertCache(CacheEntity(pageKey, finalText, label, now))
        dao.upsertCache(CacheEntity(cKey, finalText, label, now))
        dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
        onPartial?.invoke(finalText)
        return PT.Ok(finalText, label, false, text)
    }

    suspend fun process(
        task: AiTask, docUri: String, page: Int, s: ReadingSettings, text: String,
        force: Boolean = false,
        onModelActive: ((String) -> Unit)? = null,
        onPartial: ((String) -> Unit)? = null,
    ): PT {
        if (task == AiTask.TRANSLATE && isAlreadyTargetLanguage(text, s.targetLanguage)) {
            return PT.Ok(text, "متن از قبل به زبان مقصد است", true, text)
        }

        val pageKey = finalKey(task, docUri, page, s)
        val cKey = contentKey(task, s, text)

        if (!force) {
            dao.cached(pageKey)?.let { return PT.Ok(it.text, it.model, true, dao.cached("$pageKey|src")?.text) }
            dao.cached(cKey)?.let { return PT.Ok(it.text, it.model, true, text) }
        }

        if (task == AiTask.TRANSLATE) {
            onModelActive?.invoke(if (s.translationEngine == "google") "Google Translate" else "Gemini AI")
            // One page-level translation path: do not split/filter away table rows, short labels,
            // captions or formula lines before the structure-aware translator sees them.
            if (s.translationEngine == "auto") {
                return autoTranslateAndCache(text, pageKey, cKey, s, onModelActive, onPartial)
            }
            if (s.translationEngine == "google") {
                return googleTranslateAndCache(text, pageKey, cKey, s, onPartial)
            }
            val req = Prompts.buildText(AiTask.TRANSLATE, s.copy(translateMainTextOnly = false), text)
            return when (val o = router.run(Capability.TEXT, req, s.preferredModel, onModelActive, onPartial)) {
                is AiRouter.Outcome.Ok -> {
                    val now = System.currentTimeMillis()
                    dao.upsertCache(CacheEntity(pageKey, o.text, o.model, now))
                    dao.upsertCache(CacheEntity(cKey, o.text, o.model, now))
                    dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
                    PT.Ok(o.text, o.model, false, text)
                }
                is AiRouter.Outcome.Failed -> {
                    onModelActive?.invoke("Google Translate (fallback)")
                    googleTranslateAndCache(text, pageKey, cKey, s, onPartial)
                }
            }
        }

        val req = Prompts.buildText(task, s, text)
        return when (val o = router.run(Capability.TEXT, req, s.preferredModel, onModelActive, onPartial)) {
            is AiRouter.Outcome.Ok -> {
                val now = System.currentTimeMillis()
                dao.upsertCache(CacheEntity(pageKey, o.text, o.model, now))
                dao.upsertCache(CacheEntity(cKey, o.text, o.model, now))
                if (task == AiTask.TRANSLATE) dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
                PT.Ok(o.text, o.model, false, text)
            }
            is AiRouter.Outcome.Failed -> {
                // AI translation failed → optional Google fallback (only when engine is AI)
                if (task == AiTask.TRANSLATE && s.translationEngine == "ai") {
                    onModelActive?.invoke("Google Translate (fallback)")
                    return googleTranslateAndCache(text, pageKey, cKey, s, onPartial)
                }
                PT.Fail(describe(o))
            }
        }
    }

    private suspend fun googleTranslateAndCache(
        text: String,
        pageKey: String,
        cKey: String,
        s: ReadingSettings,
        onPartial: ((String) -> Unit)?,
    ): PT = try {
        val translated = GoogleTranslateService.translate(text, s.sourceLanguage, s.targetLanguage, s.googleTranslateBase, s.stripHeaders)
        val now = System.currentTimeMillis()
        val engineName = "Google Translate"
        dao.upsertCache(CacheEntity(pageKey, translated, engineName, now))
        dao.upsertCache(CacheEntity(cKey, translated, engineName, now))
        dao.upsertCache(CacheEntity("$pageKey|src", text, "", now))
        onPartial?.invoke(translated)
        PT.Ok(translated, engineName, false, text)
    } catch (e: Exception) {
        PT.Fail((if (uiFa(s)) "خطا در ارتباط با Google Translate: " else "Google Translate error: ") + (e.message ?: (if (uiFa(s)) "اتصال اینترنت را بررسی کنید" else "Check your internet connection")))
    }

    suspend fun summarizeRange(
        doc: PdfDocument, docUri: String, from: Int, to: Int, s: ReadingSettings, force: Boolean,
        onProgress: (String) -> Unit, onPartial: ((String) -> Unit)?,
    ): PT {
        val key = sha256(
            "v6|handout|$docUri|$from|$to|${s.handoutLanguage}|${s.targetLanguage}|${s.profile.name}|" +
                (if (s.profile == ReadingProfile.CUSTOM) s.customInstruction else "")
        )
        if (!force) dao.cached(key)?.let { return PT.Ok(it.text, it.model, true) }
        val n = to - from + 1
        val pageTexts = mutableListOf<Pair<Int, String>>() // pageIndex to text
        for (p in from..to) {
            onProgress("در حال خواندن صفحه ${p + 1} (${p - from + 1} از $n)…")
            when (val ex = extract(doc, docUri, p, s)) {
                is PT.Fail -> return PT.Fail("صفحه ${p + 1}: " + ex.message)
                PT.NoText -> {}
                is PT.Ok -> pageTexts += (p to "[Page ${p + 1}]\n${ex.text}")
            }
        }
        if (pageTexts.isEmpty()) return PT.NoText

        suspend fun ask(mode: Prompts.RangeMode, text: String, partial: ((String) -> Unit)?): PT =
            when (val o = router.run(Capability.TEXT, Prompts.buildRangeSummary(s, from, to, text, mode), s.preferredModel, null, partial)) {
                is AiRouter.Outcome.Ok -> PT.Ok(o.text, o.model)
                is AiRouter.Outcome.Failed -> PT.Fail(describe(o))
            }

        // For ranges up to 15 pages (standard chapter/section study range): single direct call with live streaming!
        // This keeps the full document context, streams tokens in 1-2s, and prevents false timeouts.
        val result: PT = if (pageTexts.size <= 15) {
            onProgress("در حال تولید جزوهٔ مرور هوشمند صفحات ${from + 1} تا ${to + 1}…")
            ask(Prompts.RangeMode.FULL, pageTexts.joinToString("\n\n") { it.second }, onPartial)
        } else {
            val groups = pageTexts.chunked(10)
            val partial = mutableListOf<String>()
            for ((i, g) in groups.withIndex()) {
                val pStart = g.first().first + 1
                val pEnd = g.last().first + 1
                onProgress("جزوهٔ بخش ${i + 1} از ${groups.size} (صفحات $pStart تا $pEnd)…")
                when (val r = ask(Prompts.RangeMode.PART, g.joinToString("\n\n") { it.second }, onPartial)) {
                    is PT.Ok -> partial += r.text
                    else -> return r
                }
            }
            onProgress("در حال ادغام نهایی جزوه…")
            ask(Prompts.RangeMode.MERGE, partial.joinToString("\n\n---\n\n"), onPartial)
        }
        if (result is PT.Ok) dao.upsertCache(CacheEntity(key, result.text, result.model, System.currentTimeMillis()))
        return result
    }

    fun describe(f: AiRouter.Outcome.Failed, isFa: Boolean = true): String {
        fun humanizeDetail(raw: String): String {
            val d = raw
            return when {
                d.contains("RECITATION", ignoreCase = true) ->
                    if (isFa) "محتوای صفحه به‌عنوان متن دارای حق‌نشر شناسایی شد. دوباره تلاش کنید؛ پاسخ بدون نقل‌قول مستقیم از کتاب خواهد بود."
                    else "The page text triggered a copyright/recitation filter. Retry — the answer will paraphrase instead of quoting the book."
                d.contains("DAILY_QUOTA", ignoreCase = true) || d.contains("RESOURCE_EXHAUSTED", ignoreCase = true) ->
                    if (isFa) "سهمیهٔ روزانهٔ کلید API تمام شده است. کلید دیگری اضافه کنید یا فردا دوباره تلاش کنید."
                    else "Daily API quota exceeded. Add another key or try again tomorrow."
                d.contains("MODEL_UNAVAILABLE", ignoreCase = true) || d.contains("\"code\": 404") ->
                    if (isFa) "برخی مدل‌ها در این کلید در دسترس نیستند؛ مدل‌های دیگر را هم امتحان کردیم."
                    else "Some models are unavailable on this key; other models were also tried."
                d.contains("429") ->
                    if (isFa) "محدودیت نرخ درخواست (429). کمی صبر کنید و دوباره بزنید."
                    else "Rate limited (429). Wait a moment and retry."
                d.contains("timeout", ignoreCase = true) || d.contains("socket", ignoreCase = true) || d.contains("connection closed", ignoreCase = true) ->
                    if (isFa)
                        "اتصال به سرور Gemini برقرار نشد (timeout / قطع ارتباط).\n" +
                        "اگر در ایران هستید معمولاً نیاز به VPN دارید. VPN را روشن کنید و دوباره تلاش کنید.\n" +
                        "کلید API احتمالاً سالم است؛ مشکل از شبکه است نه اتمام سهمیه."
                    else
                        "Could not reach Gemini servers (timeout / connection closed).\n" +
                        "If Google APIs are blocked on your network, turn on a VPN and retry.\n" +
                        "This is usually a network issue, not an exhausted API key."
                else -> d.lines().take(6).joinToString("\n").take(400)
            }
        }
        return when (f.reason) {
            AiRouter.Reason.NOT_CONFIGURED ->
                if (isFa) "هیچ کلید معتبری تنظیم نشده است. از تنظیمات، کلید Gemini را اضافه کنید."
                else "No valid API key configured. Add a Gemini key in Settings."
            AiRouter.Reason.ALL_COOLING_DOWN -> {
                val sec = ((f.retryAtMs ?: 0L) - System.currentTimeMillis()).coerceAtLeast(0L) / 1000
                if (sec > 0) {
                    if (isFa) "محدودیت موقت اعمال شده است (حدود ${waitText(sec, true)}). برای ارسال مجدد دکمهٔ تلاش دوباره را بزنید."
                    else "Temporary limit applied (about ${waitText(sec, false)}). Tap Retry to send again."
                } else {
                    if (isFa) "سرویس آماده است. دکمهٔ تلاش دوباره را بزنید."
                    else "Service is ready. Tap Retry."
                }
            }
            AiRouter.Reason.NETWORK ->
                if (isFa) "اتصال اینترنت برقرار نیست یا سرویس در دسترس نیست."
                else "No internet connection or the service is unreachable."
            AiRouter.Reason.TIMEOUT ->
                if (isFa) "پاسخ سرویس بیش از حد طول کشید. مدل‌های دیگر را امتحان کنید."
                else "The service timed out. Try other models."
            AiRouter.Reason.CANCELLED ->
                if (isFa) "عملیات توسط کاربر لغو شد."
                else "Cancelled by user."
            AiRouter.Reason.ALL_FAILED ->
                (if (isFa) "درخواست روی همه‌ی کلیدها و مدل‌ها ناموفق بود.\n" else "Request failed on all keys and models.\n") +
                    humanizeDetail(f.detail)
        }
    }

    private fun waitText(seconds: Long, isFa: Boolean): String = when {
        seconds < 90 -> if (isFa) "$seconds ثانیه" else "$seconds s"
        seconds < 5400 -> if (isFa) "${seconds / 60} دقیقه" else "${seconds / 60} min"
        else -> if (isFa) "${seconds / 3600} ساعت" else "${seconds / 3600} h"
    }
}
