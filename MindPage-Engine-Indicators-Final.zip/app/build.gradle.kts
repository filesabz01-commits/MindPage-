plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "app.pdfreader"
    compileSdk = 34

    defaultConfig {
        applicationId = "app.pdfreader"
        minSdk = 26
        targetSdk = 34
        versionCode = 26
        versionName = "0.1.26"
        // Phones only: drops the x86 native libraries (emulators) and makes the APK noticeably smaller.
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }
    }
    signingConfigs {
        // Stable debug key so CI debug APKs install over previous builds without uninstall.
        getByName("debug") {
            val debugKs = file("debug.keystore")
            if (debugKs.exists()) {
                storeFile = debugKs
                storePassword = "android"
                keyAlias = "androiddebugkey"
                keyPassword = "android"
            }
        }
        // Prefer env secrets; otherwise use bundled release.keystore so release APKs are NOT
        // signed with the public Android debug cert (Play Protect often warns on that).
        create("release") {
            val envKs = System.getenv("KEYSTORE_PASSWORD")
            val envAlias = System.getenv("KEY_ALIAS")
            val envKeyPass = System.getenv("KEY_PASSWORD")
            val envFile = System.getenv("KEYSTORE_FILE")?.let { file(it) }
            val bundled = file("release.keystore")
            when {
                envFile != null && envFile.exists() && !envKs.isNullOrBlank() && !envAlias.isNullOrBlank() && !envKeyPass.isNullOrBlank() -> {
                    storeFile = envFile
                    storePassword = envKs
                    keyAlias = envAlias
                    keyPassword = envKeyPass
                }
                bundled.exists() -> {
                    storeFile = bundled
                    storePassword = envKs ?: "mindpage-release"
                    keyAlias = envAlias ?: "mindpage"
                    keyPassword = envKeyPass ?: "mindpage-release"
                }
                else -> {
                    val debugKs = file("debug.keystore")
                    storeFile = debugKs
                    storePassword = "android"
                    keyAlias = "androiddebugkey"
                    keyPassword = "android"
                }
            }
            enableV1Signing = true
            enableV2Signing = true
            enableV3Signing = true
            enableV4Signing = true
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            isDebuggable = false
            isJniDebuggable = false
            signingConfig = signingConfigs.getByName("release")
        }
        debug {
            isDebuggable = true
            signingConfig = signingConfigs.getByName("debug")
        }
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.09.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-core")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.8.6")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.6")
    implementation("androidx.room:room-runtime:2.6.1")
    implementation("androidx.room:room-ktx:2.6.1")
    // PDFium: text positions for sentence highlighting (accessed by reflection in tts/PdfiumTextEngine.kt)
    implementation("io.legere:pdfiumandroid:1.0.19")
    ksp("androidx.room:room-compiler:2.6.1")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    // On-device OCR for scanned PDFs (no API cost)
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Offline Persian OCR (ML Kit does not support Arabic-script Persian).
    // Tesseract4Android (Tesseract 5, reads the bundled LSTM fas model). JitPack's artifacts for it are flaky,
    // so CI downloads the AAR once (with retries + cache) into app/libs; see .github/workflows/build-apk.yml.
    // Bundled offline AAR (Tesseract4Android 4.8.0 from JitPack). Required for Persian OCR without network.
    implementation(files("libs/tesseract4android.aar"))
    implementation("androidx.annotation:annotation:1.8.0")
    testImplementation("junit:junit:4.13.2")

}
