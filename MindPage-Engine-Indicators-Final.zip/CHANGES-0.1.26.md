# MindPage 0.1.26 — changes

Build fix
- ReadAloudController: `Plan` is now a data class (CI error: Unresolved reference 'copy' at line 527).

Logic fixes
- OCR: removed dead `local_fa` / `local_en` flags (they could never be true); `ocrMinConfidence` now affects the Persian OCR "good" verdict.
- OCR: ML Kit failures are reported instead of looking like an empty page.
- Google Translate: `translateChunk` is suspend (delay instead of Thread.sleep, cancellable); base URL is passed as a parameter (no global mutable state).
- AiRouter: daily-quota cooldown lasts until the Pacific-time reset (min 15 min, max 12 h); repeated BAD_REQUEST stops after 2 models.
- Database: ai_cache is pruned when it passes ~120 MB (oldest 30%); ai_attempts keeps the last 1000 rows (runs at app start).

Extraction
- When the plain text layer contains publisher/watermark noise or a table caption, geometry-based text is used. It drops rotated text in the left/right margin and keeps table cells apart. Extraction cache key bumped to v14.

Other
- Prompt no longer contains book-specific names. APK limited to arm64-v8a and armeabi-v7a. Version 0.1.26 (code 26).
