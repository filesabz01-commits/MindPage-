# Universal PDF Reader — مرحله ۳
Kotlin + Compose + Material 3 + Room. ساخت: `gradle assembleDebug` (Gradle 8.9، JDK 17، Android SDK 34).

## این مرحله
- ارزیابی ۳‌حالتی صفحه پیش از پردازش: متن سالم (بدون OCR + یک پاکسازی ساختاری) / اسکن (OCR) / متن مخدوش (کنار گذاشتن لایه‌ی خراب + OCR). دکمه‌ی «OCR این صفحه» همیشه OCR اجباری است.
- حذف نویز: DC offset، فید، حذف کلیک/پرش لبه‌ها، مکث بین تکه‌ها، پخش‌کننده‌ی بعدی از قبل آماده، تحویل بدون وقفه حتی بین صفحه‌ها.
- انتخاب متن: دسته‌های کشیدنی، هایلایت چندرنگ، خط‌زیر، خط‌خورده، کپی، یادداشت، فهرست هایلایت‌ها با پرش به صفحه.
- هایلایت صوتی: جمله (از مکث‌های واقعی صدا) + کلمه‌ی در حال خواندن؛ صفحه خودکار دنبال خط خوانده‌شده می‌رود.
- پیش‌بارگذاری: صفحه‌ی بعد (OCR/ترجمه/صدا) هم‌زمان آماده می‌شود، تکه‌ی در حال پخش اولویت دارد، تلاش مجدد با فاصله‌ی فزاینده، نمایش «آماده‌ی پخش: n ثانیه».

## OCR / text extraction (v0.1.25)
- **Typed text only:** reads the PDF text layer and never starts image OCR.
- **Local OCR:** uses on-device ML Kit for Latin text and bundled Tesseract `fas` for Persian/Arabic-script text; AI correction is a separate opt-in and receives text only.
- **AI OCR:** local recognition first, then text-only AI cleanup/correction; page images and PDFs are not sent to the AI provider.
- **Auto OCR:** prefers a healthy native PDF text layer; otherwise runs local OCR, scores the result, retries once at higher resolution when below the configurable threshold (default 95%), then uses text-only AI correction if still weak.
- Local cleanup runs before caching. Removed suspicious lines are retained in a recovery cache rather than silently discarded.
- OCR results and engine labels are cached so pages are not unnecessarily processed again.

## Reader controls
- The top toolbar and right-side ribbon auto-hide after 4 seconds; the expanded read-aloud panel collapses after playback has been running for 4.5 seconds.
- A tap on the page toggles the reader controls. A drag/scroll, pinch gesture, or cancelled gesture must not toggle them. Long-press remains reserved for text selection.
- Build: `./gradlew assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).
