# MindPage – Structured Translation Repair

This source is based on the uploaded `MindPage-Fixed-10.zip`.

## Changes
- Translation no longer applies the legacy "main text only" segment filter. Tables, short technical labels, captions, glossary entries, and exercises are no longer silently removed before translation.
- The obsolete "Main text only" switch was removed from the translation settings UI; translation now defaults to preserving meaningful page content.
- Gemini page translation now sends one structured page-level request instead of retrying the batch and then issuing one paid request per segment.
- The read-aloud segmented Gemini path now makes one batch request; malformed marker output falls back to Google Translate instead of retrying Gemini repeatedly.
- AI cleanup of selectable PDF text no longer immediately triggers a second AI repair request on the same page.
- Markdown tables with more than five columns are no longer flattened into prose.
- Gemini translation instructions now explicitly preserve tables, row/column relationships, formulas, code, captions, technical labels, and reading order.
- Translation cache versions were bumped so old flattened/incorrect translations are not reused.
- Added a regression test for wide Markdown table preservation.

## Verification
- Kotlin compiler parser check was run on the changed Kotlin sources. It reported dependency/classpath unresolved references because this environment does not have the Android/Gradle dependencies, but no Kotlin syntax/parse errors (`Expecting`, `Unexpected tokens`, etc.) were found.
- `./gradlew testDebugUnitTest` could not start because Gradle 8.9 could not be downloaded: DNS/network access to `services.gradle.org` is unavailable.
- Therefore a full Android build and unit-test run are **not verified** in this environment.

## Important limitation
The current translation output is structure-aware Markdown/PDF flow rendering. It preserves detected tables and content structure, but does not yet guarantee pixel-identical placement of every translated element over the original PDF page. Exact visual reconstruction requires a separate positioned-layout renderer and is not claimed in this delivery.


## MindPage OCR / translation redesign (2026-11)

- OCR settings now expose `Local`, `AI OCR`, and `Auto OCR`. AI OCR always starts with the bundled local recognizers and sends extracted text (never the page bitmap/PDF) to the existing text-repair prompt. Local mode only uses AI when its separate `aiLocalCorrection` switch is enabled.
- Auto OCR computes a composite 0–100 score from text length/completeness, script ratio, symbol noise, isolated-letter noise, malformed characters, and Tesseract confidence. If below the configurable threshold (default 95), it retries once at higher resolution and then invokes text-only AI correction if still weak.
- Mandatory local cleanup runs before commit in every OCR mode. It is conservative about watermark removal: only unmistakable standalone publisher lines are removed; inline technical prose is retained. Removed lines are stored under an `ocr_removed|...` cache key, and `PageTextService.removedTextForPage()` exposes them for recovery.
- Translation settings now expose Google Translate, AI Translation, and Auto Translation. Auto classifies content blocks, sends ordinary prose to Google, batches tables/technical blocks in one AI request, protects formula-only blocks, and promotes obviously wrong-script/unchanged Google results into the AI batch. Stable block cache keys prevent repeat translation of identical blocks.
- Google Translate batches adjacent prose paragraphs with paragraph markers to reduce endpoint calls. Existing table translation retains row/cell markers and exact grid reconstruction.
- AI Router now caps aggregate in-flight requests at two and spaces request starts by at least 1.2 seconds. Existing provider/model cooldown and bounded 429 retry logic remains active.
- Translation/OCR engine labels are persisted and the result sheet displays the actual method label. OCR and translation caches are now always used for deduplication; the legacy cache preference is retained only for compatibility.

## Verification status and remaining constraints

- Source-level delimiter/string sanity checks completed for modified Kotlin files.
- `testDebugUnitTest` was attempted through the Gradle wrapper, but this environment could not download Gradle 8.9 because DNS/network access to `services.gradle.org` is unavailable. Android SDK and a local Gradle installation are also absent, so a real Android build and runtime validation could not be completed here.
- The current PDF renderer remains a Markdown/flow-based document renderer. It preserves semantic structures such as paragraphs, headings, tables and formula text, but it does not reproduce original page coordinates, embedded figures, or pixel-identical placement. The OCR extraction layer does not yet emit reliable per-word bounding boxes for every recognizer, and the AI OCR repair request receives recognized text/Markdown structure rather than coordinates. Therefore exact geometric reconstruction and visual diagram translation remain future work rather than guaranteed behavior.
