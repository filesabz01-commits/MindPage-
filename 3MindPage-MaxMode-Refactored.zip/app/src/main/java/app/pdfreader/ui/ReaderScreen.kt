package app.pdfreader.ui

import app.pdfreader.R
import app.pdfreader.ReaderApp
import app.pdfreader.ui.l10n.LocalAppLanguage
import app.pdfreader.ui.l10n.LocalStrings
import app.pdfreader.ui.l10n.localize
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle

import androidx.compose.ui.text.style.TextOverflow

import app.pdfreader.tts.NRect
import app.pdfreader.data.Annot
import app.pdfreader.data.HIGHLIGHT_COLORS
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import java.util.UUID
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.shape.RoundedCornerShape as RoundShape
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Checkbox
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import app.pdfreader.data.markerPoint
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.foundation.Canvas
import app.pdfreader.tts.ReadMode
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.material3.FloatingActionButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import app.pdfreader.ai.AiTask
import app.pdfreader.core.pdf.PdfDocument
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
private const val MAX_SCALE = 5f
private const val DOUBLE_TAP_SCALE = 2.5f

private val InvertMatrix = ColorMatrix(
    floatArrayOf(
        -1f, 0f, 0f, 0f, 255f,
        0f, -1f, 0f, 0f, 255f,
        0f, 0f, -1f, 0f, 255f,
        0f, 0f, 0f, 1f, 0f,
    )
)

enum class PageViewMode { Continuous, Single, Flip }

@OptIn(FlowPreview::class, ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun ReaderScreen(
    state: ReaderState.Open,
    favorite: Boolean,
    onBack: () -> Unit,
    onToggleFavorite: () -> Unit,
    onProgress: (page: Int, offset: Int) -> Unit,
    ai: AiUi,
    bilingual: Boolean,
    onBilingual: (Boolean) -> Unit,
    onAiTask: (AiTask, Int, Boolean) -> Unit,
    onRangeSummary: (Int, Int, Boolean) -> Unit,
    onAiDismiss: () -> Unit,
    onOpenSettings: () -> Unit,
    onAiCancel: () -> Unit = {},
    onAiNextModel: () -> Unit = {},
) {
    val context = LocalContext.current
    val ctrl = remember { (context.applicationContext as ReaderApp).container.readAloud }
    val read by ctrl.state.collectAsStateWithLifecycle()
    val chat: ChatViewModel = viewModel()
    var chatOpen by remember { mutableStateOf(false) }
    var rangeOpen by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val doc = state.doc
    val container = remember { (context.applicationContext as ReaderApp).container }
    val clipboard = LocalClipboardManager.current

    // highlights and notes of this document (kept in a small file next to the app data)
    val annots = remember(state.uri) { mutableStateListOf<Annot>() }
    LaunchedEffect(state.uri) {
        val saved = container.annotations.load(state.uri)
        annots.clear()
        annots.addAll(saved)
    }
    val selection = remember(state.uri) {
        SelectionController(container.pdfiumText, state.uri, scope) { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
        }
    }
    var selecting by remember { mutableStateOf(false) }
    // Screen Y (px) of the last selection touch — used to float the toolbar near the selection
    var selectionAnchorY by remember { mutableFloatStateOf(0f) }
    var activeAnnot by remember { mutableStateOf<Annot?>(null) }
    var noteOpen by remember { mutableStateOf(false) }
    var listOpen by remember { mutableStateOf(false) }
    fun persistAnnots() {
        val snapshot = annots.toList()
        scope.launch { container.annotations.save(state.uri, snapshot) }
    }
    fun commitSelection(color: Int, note: String, kind: Int = 0) {
        val s = selection.sel ?: return
        val rects = selection.rects()
        if (rects.isEmpty()) return
        annots.add(Annot(UUID.randomUUID().toString(), s.page, color, rects, selection.text(), note.trim(), System.currentTimeMillis(), kind))
        persistAnnots()
        selection.clear()
    }
    val listState = rememberLazyListState(state.startPage, state.startOffset)

    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    var barsVisible by remember { mutableStateOf(true) }
    val readerSettings = container.settings.state.collectAsState().value
    val night = readerSettings.nightMode
    var moreOpen by remember { mutableStateOf(false) }
    var radialMenuExpanded by remember { mutableStateOf(false) }
    var studyMode by rememberSaveable { mutableStateOf(false) }
    var pageViewMode by rememberSaveable { mutableStateOf(PageViewMode.Flip) }
    var studyTool by remember { mutableStateOf<StudyTool?>(null) }
    val rtlRoot = androidx.compose.ui.platform.LocalLayoutDirection.current == LayoutDirection.Rtl
    val padPx = with(LocalDensity.current) { PAGE_SIDE_PAD.toPx() }
    var menuOpen by remember { mutableStateOf(false) }
    var jumpOpen by remember { mutableStateOf(false) }
    // Track page for single/flip pager modes
    var pagerPageIndex by remember { mutableIntStateOf(state.startPage.coerceAtLeast(0)) }
    // The page under the CENTER of the screen (continuous) or current pager page.
    val currentPage by remember {
        derivedStateOf {
            if (pageViewMode != PageViewMode.Continuous) {
                pagerPageIndex + 1
            } else {
                val info = listState.layoutInfo
                val center = (info.viewportStartOffset + info.viewportEndOffset) / 2
                val hit = info.visibleItemsInfo.minByOrNull {
                    val end = it.offset + it.size
                    if (center in it.offset until end) 0 else minOf(kotlin.math.abs(center - it.offset), kotlin.math.abs(center - end))
                }
                (hit?.index ?: listState.firstVisibleItemIndex) + 1
            }
        }
    }
    // While reading aloud, the PDF follows the page that is being read.
    // the bars hide themselves a few seconds after they appeared (not while a menu or sheet is open)
    LaunchedEffect(barsVisible, menuOpen, moreOpen, read.active, radialMenuExpanded) {
        if (barsVisible && !menuOpen && !moreOpen && !read.active && !radialMenuExpanded) {
            delay(6_000)
            barsVisible = false
        }
    }
    // leaving the reader ends read-aloud completely (player, audio requests, preparation of the next pages)
    DisposableEffect(ctrl) { onDispose { ctrl.stop() } }
    LaunchedEffect(read.page, read.active) {
        if (read.active && read.page in 0 until (doc?.pageCount ?: 0)) {
            try { listState.animateScrollToItem(read.page) } catch (ignored: Throwable) {}
        }
    }
    // While reading aloud, keep the spoken line on screen (not under the player, not off the edge).
    LaunchedEffect(read.highlight) {
        try {
            val r = read.highlight.firstOrNull() ?: return@LaunchedEffect
            if (selecting) return@LaunchedEffect
            val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { it.index == read.page } ?: return@LaunchedEffect
            val vh = (listState.layoutInfo.viewportEndOffset - listState.layoutInfo.viewportStartOffset).toFloat()
            if (vh > 0f) {
                val y = item.offset + r.t * item.size
                if (y < vh * 0.12f || y > vh * 0.55f) listState.animateScrollBy(y - vh * 0.25f)
            }
        } catch (ignored: Throwable) {}
    }
    // Page proportions start uniform (fast open) and are corrected as each page is rendered.
    val aspects = remember(doc) { mutableStateListOf<Float>().apply { addAll(state.aspects) } }

    // Screen point -> (page index, x fraction, y fraction), undoing the zoom/pan transform of the page list.
    fun hitPage(p: Offset, w: Float, h: Float): Triple<Int, Float, Float>? {
        if (w <= 0f || h <= 0f) return null
        val ux = w / 2f + (p.x - w / 2f - offsetX) / scale
        val uy = h / 2f + (p.y - h / 2f) / scale
        val item = listState.layoutInfo.visibleItemsInfo.firstOrNull { uy >= it.offset && uy < it.offset + it.size } ?: return null
        if (item.size <= 0) return null
        return Triple(item.index, ((ux - padPx) / (w - 2 * padPx)).coerceIn(0f, 1f), ((uy - item.offset) / item.size).coerceIn(0f, 1f))
    }

    // Resume reading: remember the exact spot (page + pixel offset), debounced.
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex to listState.firstVisibleItemScrollOffset }
            .debounce(600)
            .collect { (p, o) -> onProgress(p, o) }
    }
    DisposableEffect(listState) {
        onDispose { onProgress(listState.firstVisibleItemIndex, listState.firstVisibleItemScrollOffset) }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(if (night) Color.Black else MaterialTheme.colorScheme.surfaceVariant)
    ) {
        BoxWithConstraints(
            Modifier
                .fillMaxSize()
                .clipToBounds()
                .pointerInput(state.uri) {
                    // Long-press selection. It watches in the Initial pass (before the list and the zoom handler);
                    // once the long press is confirmed it consumes the rest of the gesture so the page does not scroll.
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        val gw = size.width.toFloat()
                        val gh = size.height.toFloat()
                        // 1) a drag on one of the two selection handles starts at once (no long press needed)
                        val grabbed = if (selection.sel == null) 0 else
                            hitPage(down.position, gw, gh)?.let { selection.grab(it.first, it.second, it.third, aspects.getOrElse(it.first) { 1.414f }) } ?: 0
                        if (grabbed != 0) {
                            selecting = true
                            selectionAnchorY = down.position.y
                            try {
                                down.consume()
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    selectionAnchorY = c.position.y
                                    hitPage(c.position, gw, gh)?.let { selection.moveHandle(grabbed, it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > gh - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                            return@awaitEachGesture
                        }
                        val slop = viewConfiguration.touchSlop
                        val aborted: Boolean? = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) {
                            var stop = false
                            while (!stop) {
                                val ev = awaitPointerEvent(PointerEventPass.Initial)
                                val c = ev.changes.firstOrNull { it.id == down.id }
                                stop = c == null || !c.pressed || ev.changes.count { it.pressed } > 1 ||
                                    (c.position - down.position).getDistance() > slop
                            }
                            true
                        }
                        if (aborted == null) {
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            selecting = true
                            selectionAnchorY = down.position.y
                            try {
                                selection.clear()
                                hitPage(down.position, w, h)?.let { selection.begin(it.first, it.second, it.third) }
                                while (true) {
                                    val ev = awaitPointerEvent(PointerEventPass.Initial)
                                    val c = ev.changes.firstOrNull { it.id == down.id }
                                    ev.changes.forEach { it.consume() }
                                    if (c == null || !c.pressed) break
                                    selectionAnchorY = c.position.y
                                    hitPage(c.position, w, h)?.let { selection.extend(it.first, it.second, it.third) }
                                    if (c.position.y < 90f) listState.dispatchRawDelta(-18f)
                                    else if (c.position.y > h - 90f) listState.dispatchRawDelta(18f)
                                }
                            } finally {
                                selecting = false
                            }
                        }
                    }
                }
                .pointerInput(state.uri) {
                    detectTapGestures(
                        onDoubleTap = {
                            if (scale > 1f) {
                                scale = 1f
                                offsetX = 0f
                            } else {
                                scale = DOUBLE_TAP_SCALE
                            }
                        },
                        onTap = { pos ->
                            if (selection.sel != null) {
                                selection.clear()
                            } else {
                                val hit = hitPage(pos, size.width.toFloat(), size.height.toFloat())
                                val tapped = hit?.let { (pg, nx, ny) ->
                                    annots.lastOrNull { a ->
                                        a.page == pg && (a.rects.any { r ->
                                            nx >= r.l - 0.01f && nx <= r.r + 0.01f && ny >= r.t - 0.01f && ny <= r.b + 0.01f
                                        } || (a.note.isNotBlank() && a.markerPoint()?.let { (mx, my) ->
                                            kotlin.math.abs(nx - mx) < 0.05f && kotlin.math.abs((ny - my) * aspects.getOrElse(pg) { 1.414f }) < 0.05f
                                        } == true))
                                    }
                                }
                                if (tapped != null) activeAnnot = tapped else barsVisible = !barsVisible
                            }
                        },
                    )
                }
                .pointerInput(Unit) {
                    // Pinch-zoom + pan. Runs in the Initial pass so it can take over from the list
                    // only when two fingers are down or the page is already zoomed in.
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                        do {
                            val event = awaitPointerEvent(PointerEventPass.Initial)
                            val multi = event.changes.count { it.pressed } >= 2
                            if (!selecting && (multi || scale > 1f)) {
                                val zoom = event.calculateZoom()
                                val pan = event.calculatePan()
                                if (zoom != 1f || pan != Offset.Zero) {
                                    val newScale = (scale * zoom).coerceIn(1f, MAX_SCALE)
                                    scale = newScale
                                    val maxX = size.width * (newScale - 1f) / 2f
                                    offsetX = if (newScale <= 1f) 0f else (offsetX + pan.x).coerceIn(-maxX, maxX)
                                    listState.dispatchRawDelta(-pan.y / newScale)
                                    event.changes.forEach { if (it.positionChanged()) it.consume() }
                                }
                            }
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            val renderWidth = (constraints.maxWidth * 1.25f).toInt().coerceIn(600, 1400)
            val cache = remember(doc, renderWidth) {
                val maxBytes = (Runtime.getRuntime().maxMemory() / 4).toInt()
                object : LruCache<Int, Bitmap>(maxBytes) {
                    override fun sizeOf(key: Int, value: Bitmap): Int = value.byteCount
                }
            }
            if (pageViewMode == PageViewMode.Continuous) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offsetX
                        },
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(horizontal = PAGE_SIDE_PAD, vertical = 10.dp),
                ) {
                    items(count = doc.pageCount, key = { it }) { index ->
                        PageItem(
                            index = index,
                            aspect = aspects.getOrElse(index) { 1.414f },
                            onAspect = { i, a ->
                                if (i in aspects.indices && kotlin.math.abs(aspects[i] - a) > 0.01f) aspects[i] = a
                            },
                            doc = doc,
                            cache = cache,
                            renderWidth = renderWidth,
                            night = night,
                            highlight = if (read.active && read.page == index) read.highlight else emptyList(),
                            annots = annots.filter { it.page == index },
                            selection = if (selection.sel?.page == index) selection.rects() else emptyList(),
                            handles = if (selection.sel?.page == index) selection.handles() else null,
                            wordHighlight = emptyList(),
                        )
                    }
                }
            } else {
                // Single-page or flip-style horizontal pager (Google Books-like swipe)
                val pagerState = rememberPagerState(
                    initialPage = (currentPage - 1).coerceIn(0, (doc.pageCount - 1).coerceAtLeast(0)),
                    pageCount = { doc.pageCount },
                )
                LaunchedEffect(pagerState.currentPage) {
                    pagerPageIndex = pagerState.currentPage
                }
                LaunchedEffect(pageViewMode) {
                    // when switching into pager, start at last known continuous page
                    if (pageViewMode != PageViewMode.Continuous) {
                        val idx = (currentPage - 1).coerceIn(0, doc.pageCount - 1)
                        pagerState.scrollToPage(idx)
                        pagerPageIndex = idx
                    }
                }
                HorizontalPager(
                    state = pagerState,
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                            translationX = offsetX
                        },
                ) { index ->
                    val flip = pageViewMode == PageViewMode.Flip
                    val pageOffset = (pagerState.currentPage - index) + pagerState.currentPageOffsetFraction
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = if (flip) 2.dp else PAGE_SIDE_PAD, vertical = 6.dp)
                            .then(
                                if (flip) {
                                    Modifier.graphicsLayer {
                                        cameraDistance = 24f * density
                                        // Pivot at book spine (right edge in RTL, left edge in LTR)
                                        transformOrigin = if (rtlRoot) {
                                            androidx.compose.ui.graphics.TransformOrigin(1f, 0.5f)
                                        } else {
                                            androidx.compose.ui.graphics.TransformOrigin(0f, 0.5f)
                                        }
                                        if (pageOffset in -1f..1f) {
                                            val rotation = if (rtlRoot) {
                                                (pageOffset * 65f).coerceIn(-90f, 90f)
                                            } else {
                                                (-pageOffset * 65f).coerceIn(-90f, 90f)
                                            }
                                            rotationY = rotation
                                            alpha = (1f - kotlin.math.abs(pageOffset) * 0.15f).coerceIn(0f, 1f)
                                            shadowElevation = (14f * (1f - kotlin.math.abs(pageOffset))).coerceAtLeast(0f)
                                        }
                                    }
                                } else Modifier
                            ),
                        contentAlignment = Alignment.Center,
                    ) {
                        PageItem(
                            index = index,
                            aspect = aspects.getOrElse(index) { 1.414f },
                            onAspect = { i, a ->
                                if (i in aspects.indices && kotlin.math.abs(aspects[i] - a) > 0.01f) aspects[i] = a
                            },
                            doc = doc,
                            cache = cache,
                            renderWidth = renderWidth,
                            night = night,
                            highlight = if (read.active && read.page == index) read.highlight else emptyList(),
                            annots = annots.filter { it.page == index },
                            selection = if (selection.sel?.page == index) selection.rects() else emptyList(),
                            handles = if (selection.sel?.page == index) selection.handles() else null,
                            wordHighlight = emptyList(),
                        )

                        // Google Books spine crease shadow during page curl
                        if (flip) {
                            Box(
                                modifier = Modifier
                                    .align(if (rtlRoot) Alignment.CenterEnd else Alignment.CenterStart)
                                    .fillMaxHeight()
                                    .width(16.dp)
                                    .background(
                                        androidx.compose.ui.graphics.Brush.horizontalGradient(
                                            colors = if (rtlRoot) listOf(Color.Transparent, Color.Black.copy(alpha = 0.14f))
                                                     else listOf(Color.Black.copy(alpha = 0.14f), Color.Transparent)
                                        )
                                    )
                            )
                        }
                    }
                }
            }
        }

        val cleanBookName = remember(state.name) {
            state.name.replace(".pdf", "", ignoreCase = true)
                .replace('_', ' ')
                .replace('-', ' ')
                .trim()
        }

        // Bold Orange Side Reading Ribbon (large, visible, thumb-friendly, opens page jump on click)
        // Automatically hides/shows with barsVisible (auto-hide timer & toggle on screen tap), on the RIGHT edge!
        AnimatedVisibility(
            visible = barsVisible,
            modifier = Modifier.align(if (rtlRoot) Alignment.CenterStart else Alignment.CenterEnd),
            enter = fadeIn() + slideInHorizontally { if (rtlRoot) -it else it },
            exit = fadeOut() + slideOutHorizontally { if (rtlRoot) -it else it },
        ) {
            Surface(
                modifier = Modifier
                    .width(42.dp)
                    .height(280.dp)
                    .clip(RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp))
                    .clickable { jumpOpen = true },
                shape = RoundedCornerShape(topStart = 18.dp, bottomStart = 18.dp),
                color = MaterialTheme.colorScheme.primary,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 10.dp, horizontal = 2.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween,
                ) {
                    // 1. Bold Page Number Badge at Top: Current / Total
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.25f),
                        modifier = Modifier.padding(horizontal = 2.dp),
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 3.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            val appLang = LocalAppLanguage.current
                            Text(
                                text = currentPage.localize(appLang),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                maxLines = 1,
                            )
                            Box(
                                Modifier
                                    .width(16.dp)
                                    .height(1.dp)
                                    .background(Color.White.copy(alpha = 0.6f))
                            )
                            Text(
                                text = doc.pageCount.localize(appLang),
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White.copy(alpha = 0.85f),
                                maxLines = 1,
                            )
                        }
                    }

                    // 2. Full Book Name in the center (rotated -90deg, reading bottom-up like book spines)
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            text = cleanBookName,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Black,
                            ),
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            softWrap = false,
                            modifier = Modifier
                                .graphicsLayer { rotationZ = -90f }
                                .requiredSize(width = 170.dp, height = 38.dp)
                                .wrapContentSize(Alignment.Center),
                        )
                    }

                    // 3. Mini jump/search icon at bottom
                    Icon(
                        imageVector = Icons.Default.Search,
                        contentDescription = "پرش به صفحه",
                        tint = Color.White.copy(alpha = 0.85f),
                        modifier = Modifier.size(16.dp),
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = barsVisible,
            // No outer statusBarsPadding — TopAppBar windowInsets handles it once (edge-to-edge).
            modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth(),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it },
        ) {
            val activity = context as? android.app.Activity
            TopAppBar(
                windowInsets = WindowInsets.statusBars,
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f),
                ),
                title = {
                    // Book name + page number live only on the side strip — keep top bar clean
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = stringResource(R.string.back))
                    }
                },
                actions = {
                    // Page view mode toggle: Elegant themed icon button (Flip / Continuous / Single)
                    IconButton(
                        onClick = {
                            pageViewMode = when (pageViewMode) {
                                PageViewMode.Flip -> PageViewMode.Continuous
                                PageViewMode.Continuous -> PageViewMode.Single
                                PageViewMode.Single -> PageViewMode.Flip
                            }
                        }
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                            modifier = Modifier.size(36.dp),
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                when (pageViewMode) {
                                    PageViewMode.Flip -> AppIconView(
                                        icon = AppIcon.BookFlip,
                                        tint = MaterialTheme.colorScheme.primary,
                                        size = 20.dp,
                                    )
                                    PageViewMode.Continuous -> AppIconView(
                                        icon = AppIcon.ContinuousScroll,
                                        tint = MaterialTheme.colorScheme.primary,
                                        size = 20.dp,
                                    )
                                    PageViewMode.Single -> AppIconView(
                                        icon = AppIcon.SinglePage,
                                        tint = MaterialTheme.colorScheme.primary,
                                        size = 20.dp,
                                    )
                                }
                            }
                        }
                    }
                    // Study Mode toggle (MindPage)
                    IconButton(onClick = { studyMode = !studyMode }) {
                        AppIconView(
                            AppIcon.Study,
                            tint = if (studyMode) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                            size = 22.dp,
                        )
                    }
                    // Oval Day / Night Switch with Sun and Moon
                    DayNightSwitch(
                        night = night,
                        onToggle = { container.settings.update { it.copy(nightMode = !it.nightMode) } },
                        modifier = Modifier.padding(end = 2.dp),
                    )
                    // Screen Rotation Button
                    IconButton(onClick = {
                        val act = activity ?: return@IconButton
                        act.requestedOrientation = if (act.requestedOrientation == android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
                            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
                        } else {
                            android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
                        }
                    }) {
                        AppIconView(AppIcon.Rotate, tint = MaterialTheme.colorScheme.onSurface, size = 20.dp)
                    }
                    IconButton(onClick = onToggleFavorite) {
                        Icon(
                            if (favorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = stringResource(R.string.favorite),
                            tint = if (favorite) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = stringResource(R.string.more))
                    }
                    DropdownMenu(
                        expanded = menuOpen,
                        onDismissRequest = { menuOpen = false },
                        shape = RoundedCornerShape(20.dp),
                        containerColor = MaterialTheme.colorScheme.surfaceVariant,
                        tonalElevation = 6.dp,
                        shadowElevation = 8.dp,
                    ) {
                        DropdownMenuItem(
                            text = { val appLang = LocalAppLanguage.current
                            Text(if (LocalStrings.current.isFa) "هایلایت‌ها و یادداشت‌ها (${annots.size.localize(appLang)})" else "Highlights & Notes (${annots.size.localize(appLang)})", fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },
                            onClick = { listOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.go_to_page), fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },
                            onClick = { jumpOpen = true; menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.share), fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },
                            onClick = { sharePdf(context, Uri.parse(state.uri)); menuOpen = false },
                        )
                        DropdownMenuItem(
                            text = { Text("تنظیمات", fontWeight = FontWeight.SemiBold) },
                            leadingIcon = { Icon(Icons.Default.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp)) },
                            onClick = { menuOpen = false; onOpenSettings() },
                        )
                    }
                },
            )
        }

        // Selection toolbar — only after the finger is lifted (not while dragging), frozen near the selection.
        if (selection.sel != null && !selecting) {
            BoxWithConstraints(Modifier.fillMaxSize()) {
                val density = LocalDensity.current
                val toolbarH = 52.dp
                val margin = 12.dp
                // Freeze Y at the moment selection finished so the bar does not jump around
                val frozenY = remember(selection.sel) { selectionAnchorY }
                val yDp = with(density) {
                    val raw = frozenY.toDp() - toolbarH - 8.dp
                    raw.coerceIn(margin, maxHeight - toolbarH - margin - 80.dp)
                }
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                    Surface(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .offset(y = yDp)
                            .padding(horizontal = 8.dp),
                        shape = RoundedCornerShape(28.dp),
                        tonalElevation = 10.dp,
                        shadowElevation = 12.dp,
                        color = MaterialTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.98f),
                    ) {
                        Row(
                            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                        ) {
                            // Color dots = highlight
                            for (col in HIGHLIGHT_COLORS) {
                                Box(
                                    Modifier
                                        .padding(horizontal = 3.dp)
                                        .size(22.dp)
                                        .clip(CircleShape)
                                        .background(Color(col))
                                        .clickable { commitSelection(col, "") }
                                )
                            }
                            // Icon actions (Boox-style compact)
                            TextButton(
                                onClick = { commitSelection(0xFFE53935.toInt(), "", 1) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("U̲", style = MaterialTheme.typography.titleMedium) }
                            TextButton(
                                onClick = { commitSelection(0xFFE53935.toInt(), "", 2) },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("S̶", style = MaterialTheme.typography.titleMedium) }
                            TextButton(
                                onClick = {
                                    clipboard.setText(AnnotatedString(selection.text()))
                                    Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                                    selection.clear()
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("⎘", style = MaterialTheme.typography.titleMedium) }
                            TextButton(
                                onClick = { noteOpen = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("✎", style = MaterialTheme.typography.titleMedium) }
                            // Translate — open Google Translate app with text pre-filled
                            TextButton(
                                onClick = {
                                    val q = selection.text().trim()
                                    if (q.isBlank()) return@TextButton
                                    clipboard.setText(AnnotatedString(q))
                                    val launched = openGoogleTranslate(context, q)
                                    if (!launched) {
                                        Toast.makeText(context, "Google Translate پیدا نشد؛ متن کپی شد", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("文A", style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)) }
                            // Dictionary — Wiktionary for short, Translate for longer
                            TextButton(
                                onClick = {
                                    val q = selection.text().trim()
                                    if (q.isBlank()) return@TextButton
                                    clipboard.setText(AnnotatedString(q))
                                    val words = q.split(Regex("\\s+")).filter { it.isNotBlank() }
                                    if (words.size <= 2) {
                                        val url = "https://en.wiktionary.org/wiki/" +
                                            java.net.URLEncoder.encode(q, "UTF-8")
                                        try {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                                        } catch (_: Exception) {
                                            openGoogleTranslate(context, q)
                                        }
                                    } else {
                                        openGoogleTranslate(context, q)
                                    }
                                },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("Dic", style = MaterialTheme.typography.labelLarge) }
                            TextButton(
                                onClick = { selection.clear() },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            ) { Text("✕", style = MaterialTheme.typography.titleMedium) }
                        }
                    }
                }
            }
        }

        // Side scrollbar removed: it was too easy to touch accidentally and jump pages.
        // Page number is already shown in the top app bar. Jump dialog remains available via long-press / toolbar if needed.

        // Animated Radial Speed Dial Menu (FAB) floating at bottom center
        if (!read.active) {
            val page0 = (currentPage - 1).coerceIn(0, doc.pageCount - 1)
            AnimatedVisibility(
                visible = barsVisible,
                modifier = Modifier.fillMaxSize(),
                enter = fadeIn() + androidx.compose.animation.slideInVertically { it },
                exit = fadeOut() + androidx.compose.animation.slideOutVertically { it },
            ) {
                RadialSpeedDialMenu(
                    expanded = radialMenuExpanded,
                    onToggle = { radialMenuExpanded = it },
                    items = if (studyMode) {
                        listOf(
                            RadialSpeedDialItem(AppIcon.Vocab, "ووکب") { studyTool = StudyTool.Vocab },
                            RadialSpeedDialItem(AppIcon.Grammar, "گرامر") { studyTool = StudyTool.Grammar },
                            RadialSpeedDialItem(AppIcon.Quiz, "کوئیز") { studyTool = StudyTool.Quiz },
                            RadialSpeedDialItem(AppIcon.Exercise, "تمرین") { studyTool = StudyTool.Exercise },
                            RadialSpeedDialItem(AppIcon.Sparkle, "دستیار", accent = true) { chatOpen = true },
                        )
                    } else {
                        listOf(
                            RadialSpeedDialItem(AppIcon.Sparkle, "دستیار", accent = true) { chatOpen = true },
                            RadialSpeedDialItem(AppIcon.Speaker, "خواندن") {
                                ctrl.start(doc, state.uri, page0, ReadMode.ORIGINAL)
                            },
                            RadialSpeedDialItem(AppIcon.ReadTranslate, "خواندن+ترجمه") {
                                ctrl.start(doc, state.uri, page0, ReadMode.TRANSLATE_AUDIO)
                            },
                            RadialSpeedDialItem(AppIcon.Globe, "ترجمه") {
                                onAiTask(AiTask.TRANSLATE, page0, false)
                            },
                            RadialSpeedDialItem(AppIcon.Summary, "خلاصه") {
                                onAiTask(AiTask.SUMMARIZE, page0, false)
                            },
                            RadialSpeedDialItem(AppIcon.More, "بیشتر") { moreOpen = true },
                        )
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        } else {
            ReadAloudPanel(read, ctrl, Modifier.align(Alignment.BottomCenter).fillMaxWidth())
        }
    }

    AiResultScreen(
        state = ai,
        bilingual = bilingual,
        onBilingualChange = onBilingual,
        onDismiss = onAiDismiss,
        onRetry = { d ->
            container.router.forceClearAllCooldowns()
            if (d.rangeTo >= 0) onRangeSummary(d.page, d.rangeTo, true) else onAiTask(d.task, d.page, true)
        },
        onCancel = onAiCancel,
    )
    studyTool?.let { tool ->
        StudyToolScreen(
            tool = tool,
            doc = doc,
            docUri = state.uri,
            page = (currentPage - 1).coerceIn(0, doc.pageCount - 1),
            settings = readerSettings,
            pageText = container.pageText,
            router = container.router,
            dao = container.aiDao,
            onDismiss = { studyTool = null },
        )
    }
    if (chatOpen) {
        ChatSheet(
            chat = chat,
            currentPage = currentPage.coerceAtMost(doc.pageCount),
            totalPages = doc.pageCount,
            onSend = { q -> chat.send(doc, state.uri, (currentPage - 1).coerceIn(0, doc.pageCount - 1), q) },
            onSendRange = { f, t, q -> chat.send(doc, state.uri, f, t, q) },
            onDismiss = {
                chatOpen = false
                chat.clear()
            },
        )
    }
    if (rangeOpen) {
        RangeDialog(
            current = currentPage.coerceAtMost(doc.pageCount),
            total = doc.pageCount,
            onDismiss = { rangeOpen = false },
            onStart = { f, t ->
                rangeOpen = false
                onRangeSummary(f, t, false)
            },
        )
    }

    if (moreOpen) {
        ModalBottomSheet(
            onDismissRequest = { moreOpen = false },
            shape = RoundedCornerShape(28.dp),
        ) {
            val page0 = (currentPage - 1).coerceIn(0, doc.pageCount - 1)
            Column(Modifier.padding(horizontal = 16.dp).padding(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                for ((icon, label, action) in listOf(
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Explain, "توضیح این صفحه", { onAiTask(AiTask.EXPLAIN, page0, false) }),
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Ocr, "استخراج متن صفحه (OCR)", { onAiTask(AiTask.EXTRACT, page0, false) }),
                    Triple<AppIcon, String, () -> Unit>(AppIcon.Range, "خلاصه‌ی بازه‌ی صفحه‌ها", { rangeOpen = true }),
                )) {
                    Surface(
                        shape = RoundedCornerShape(22.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth().clickable { moreOpen = false; action() },
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            AppIconView(icon, MaterialTheme.colorScheme.primary, size = 26.dp)
                            Text(label, style = MaterialTheme.typography.titleMedium)
                        }
                    }
                }
            }
        }
    }
    if (listOpen) {
        ModalBottomSheet(onDismissRequest = { listOpen = false }) {
            if (annots.isEmpty()) {
                Text(
                    "هنوز هایلایت یا یادداشتی ندارید. روی متن نگه دارید تا انتخاب شود.",
                    modifier = Modifier.padding(24.dp),
                    style = MaterialTheme.typography.bodyMedium,
                )
            } else {
                LazyColumn(Modifier.padding(bottom = 24.dp)) {
                    items(annots.sortedWith(compareBy({ it.page }, { it.created })), key = { it.id }) { a ->
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .clickable {
                                    listOpen = false
                                    scope.launch { listState.animateScrollToItem(a.page) }
                                }
                                .padding(horizontal = 20.dp, vertical = 10.dp)
                        ) {
                            val appLang = LocalAppLanguage.current
                            Text(if (LocalStrings.current.isFa) "صفحه ${(a.page + 1).localize(appLang)}" else "Page ${(a.page + 1).localize(appLang)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                            Text(a.text, maxLines = 2, style = MaterialTheme.typography.bodyMedium)
                            if (a.note.isNotBlank()) Text(a.note, maxLines = 3, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Row {
                                TextButton(onClick = { activeAnnot = a; listOpen = false }) { Text("ویرایش") }
                                TextButton(onClick = {
                                    annots.removeAll { it.id == a.id }
                                    persistAnnots()
                                }) { Text("حذف") }
                            }
                        }
                    }
                }
            }
        }
    }
    if (noteOpen) {
        var note by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { noteOpen = false },
            title = { Text("افزودن یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(selection.text(), maxLines = 4, style = MaterialTheme.typography.bodySmall)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    commitSelection(0xFFFFB300.toInt(), note, 3)
                    noteOpen = false
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { noteOpen = false }) { Text("انصراف") } },
        )
    }
    activeAnnot?.let { a ->
        var note by remember(a.id) { mutableStateOf(a.note) }
        AlertDialog(
            onDismissRequest = { activeAnnot = null },
            title = { Text(if (a.note.isBlank()) "هایلایت" else "یادداشت") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(a.text, maxLines = 6, style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = note, onValueChange = { note = it }, label = { Text("یادداشت") },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Row {
                        TextButton(onClick = {
                            clipboard.setText(AnnotatedString(a.text))
                            Toast.makeText(context, "کپی شد", Toast.LENGTH_SHORT).show()
                        }) { Text("کپی متن") }
                        TextButton(onClick = {
                            annots.removeAll { it.id == a.id }
                            persistAnnots()
                            activeAnnot = null
                        }) { Text("حذف") }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val i = annots.indexOfFirst { it.id == a.id }
                    if (i >= 0) {
                        annots[i] = a.copy(note = note.trim())
                        persistAnnots()
                    }
                    activeAnnot = null
                }) { Text("ذخیره") }
            },
            dismissButton = { TextButton(onClick = { activeAnnot = null }) { Text("بستن") } },
        )
    }

    if (jumpOpen) {
        var text by remember { mutableStateOf(currentPage.toString()) }
        AlertDialog(
            onDismissRequest = { jumpOpen = false },
            title = { Text(stringResource(R.string.go_to_page)) },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.filter(Char::isDigit).take(6) },
                    label = { Text(stringResource(R.string.page_number)) },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth(),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    text.toIntOrNull()?.let { n ->
                        scope.launch { listState.scrollToItem((n - 1).coerceIn(0, doc.pageCount - 1)) }
                    }
                    jumpOpen = false
                }) { Text(stringResource(R.string.ok)) }
            },
            dismissButton = {
                TextButton(onClick = { jumpOpen = false }) { Text(stringResource(R.string.cancel)) }
            },
        )
    }
}

@Composable
private fun PageItem(
    index: Int,
    aspect: Float,
    doc: PdfDocument,
    cache: LruCache<Int, Bitmap>,
    renderWidth: Int,
    night: Boolean,
    onAspect: (Int, Float) -> Unit,
    highlight: List<NRect> = emptyList(),
    annots: List<Annot> = emptyList(),
    selection: List<NRect> = emptyList(),
    handles: Pair<NPoint, NPoint>? = null,
    wordHighlight: List<NRect> = emptyList(),
) {
    val bitmap by produceState<Bitmap?>(initialValue = cache.get(index), index, cache) {
        if (value == null) {
            value = try {
                doc.render(index, renderWidth).also {
                    cache.put(index, it)
                    onAspect(index, it.height.toFloat() / it.width.toFloat())
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null // closed document or render failure: show the blank placeholder
            }
        }
    }
    val shape = Modifier
        .fillMaxWidth()
        .aspectRatioOf(aspect)
        .shadow(3.dp, RoundShape(16.dp))
        .clip(RoundShape(16.dp))
    val bmp = bitmap
    Box(shape) {
        if (bmp == null) {
            Box(Modifier.fillMaxSize().background(if (night) Color.DarkGray else Color.White))
        } else {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.FillWidth,
                colorFilter = if (night) ColorFilter.colorMatrix(InvertMatrix) else null,
            )
        }
        if (highlight.isNotEmpty() || annots.isNotEmpty() || selection.isNotEmpty() || wordHighlight.isNotEmpty() || handles != null) {
            Canvas(Modifier.fillMaxSize()) {
                for (a in annots) {
                    val col = Color(a.color)
                    for (r in a.rects) {
                        when (a.kind) {
                            1, 2, 3 -> {
                                val y = if (a.kind == 2) (r.t + r.b) / 2f else r.b
                                drawLine(
                                    color = col.copy(alpha = 1f),
                                    start = Offset(r.l * size.width, y * size.height),
                                    end = Offset(r.r * size.width, y * size.height),
                                    strokeWidth = 1.dp.toPx(),
                                )
                            }
                            else -> drawRoundRect(
                                color = col,
                                topLeft = Offset(r.l * size.width, r.t * size.height),
                                size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                                cornerRadius = CornerRadius(3f, 3f),
                            )
                        }
                    }
                    if (a.note.isNotBlank()) {
                        a.markerPoint()?.let { (mx, my) ->
                            val cx = mx * size.width
                            val cy = my * size.height
                            val sz = 9.dp.toPx()
                            drawRoundRect(Color(0xFFFFB300), Offset(cx - sz, cy - sz), Size(2 * sz, 2 * sz), CornerRadius(5.dp.toPx(), 5.dp.toPx()))
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy - sz * 0.25f), Offset(cx + sz * 0.5f, cy - sz * 0.25f), strokeWidth = 1.5f.dp.toPx())
                            drawLine(Color.White, Offset(cx - sz * 0.5f, cy + sz * 0.3f), Offset(cx + sz * 0.25f, cy + sz * 0.3f), strokeWidth = 1.5f.dp.toPx())
                        }
                    }
                }
                for (r in selection) {
                    drawRoundRect(
                        color = Color(0x663D5AFE),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(3f, 3f),
                    )
                }
                for (r in highlight) {
                    // lighter and a little taller than the text line, so it reads like a marker pen
                    val padY = (r.b - r.t) * 0.2f * size.height
                    val padX = 3.dp.toPx()
                    drawRoundRect(
                        color = Color(0x40FFC400),
                        topLeft = Offset(r.l * size.width - padX, r.t * size.height - padY),
                        size = Size((r.r - r.l) * size.width + 2 * padX, (r.b - r.t) * size.height + 2 * padY),
                        cornerRadius = CornerRadius(6.dp.toPx(), 6.dp.toPx()),
                    )
                }
                for (r in wordHighlight) {
                    drawRoundRect(
                        color = Color(0x99FF9100),
                        topLeft = Offset(r.l * size.width, r.t * size.height),
                        size = Size((r.r - r.l) * size.width, (r.b - r.t) * size.height),
                        cornerRadius = CornerRadius(4f, 4f),
                    )
                }
                handles?.let { (p1, p2) ->
                    for (p in listOf(p1, p2)) {
                        val x = p.x * size.width
                        val y = p.y * size.height
                        drawLine(Color(0xFF3D5AFE), Offset(x, y), Offset(x, y + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
                        drawCircle(Color(0xFF3D5AFE), radius = 6.dp.toPx(), center = Offset(x, y + 10.dp.toPx()))
                    }
                }
            }
        }
    }
}

private val PAGE_SIDE_PAD = 10.dp

private fun Modifier.aspectRatioOf(heightOverWidth: Float): Modifier =
    this.then(Modifier.aspectRatio(1f / heightOverWidth))

/**
 * Opens Google Translate with [text] pre-filled.
 * Tries, in order: PROCESS_TEXT to the Translate package, SEND to the package,
 * custom scheme, then the mobile web URL. Returns true if something launched.
 */
private fun openGoogleTranslate(context: Context, text: String): Boolean {
    val q = text.trim()
    if (q.isBlank()) return false
    val pkg = "com.google.android.apps.translate"

    // 1) PROCESS_TEXT (shows Translate UI with the selection)
    try {
        val i = Intent(Intent.ACTION_PROCESS_TEXT).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_PROCESS_TEXT, q)
            putExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, true)
            setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(i)
        return true
    } catch (_: Exception) { }

    // 2) ACTION_SEND to Translate package
    try {
        val i = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, q)
            setPackage(pkg)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(i)
        return true
    } catch (_: Exception) { }

    // 3) Browser / mobile web with query embedded
    try {
        val encoded = java.net.URLEncoder.encode(q, "UTF-8")
        val url = "https://translate.google.com/m/translate?sl=auto&tl=fa&q=$encoded"
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return true
    } catch (_: Exception) { }
    return false
}

private fun sharePdf(context: Context, uri: Uri) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, R.string.err_share, Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun RangeDialog(current: Int, total: Int, onDismiss: () -> Unit, onStart: (Int, Int) -> Unit) {
    var from by remember { mutableStateOf(current.toString()) }
    var to by remember { mutableStateOf(minOf(total, current + 9).toString()) }
    val f = from.toIntOrNull()
    val t = to.toIntOrNull()
    val valid = f != null && t != null && f in 1..total && t in 1..total
    val n = if (valid) kotlin.math.abs(t!! - f!!) + 1 else 0
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خلاصه‌ی بازه‌ی صفحه‌ها") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = from, onValueChange = { from = it.filter(Char::isDigit).take(6) },
                        label = { Text("از صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                    OutlinedTextField(
                        value = to, onValueChange = { to = it.filter(Char::isDigit).take(6) },
                        label = { Text("تا صفحه") }, singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                    )
                }
                Text(
                    if (valid) "برای خواندن این $n صفحه تا $n درخواست به هوش مصنوعی فرستاده می‌شود (صفحه‌هایی که در این نشست قبلاً خوانده شده‌اند دوباره درخواست نمی‌شوند) و بعد خلاصه تهیه می‌شود."
                    else "شماره‌ی صفحه‌ها را درست وارد کنید (۱ تا $total).",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { if (valid) onStart(f!! - 1, t!! - 1) }, enabled = valid) { Text("شروع") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("انصراف") } },
    )
}

@Composable
private fun DayNightSwitch(
    night: Boolean,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val bg = if (night) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surfaceContainerHigh
    val thumbBg = if (night) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primaryContainer
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .background(bg)
            .clickable(onClick = onToggle)
            .padding(2.dp),
        contentAlignment = Alignment.Center,
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (!night) thumbBg else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                AppIconView(
                    icon = AppIcon.Sun,
                    tint = if (!night) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    size = 15.dp,
                )
            }
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .clip(CircleShape)
                    .background(if (night) thumbBg else Color.Transparent),
                contentAlignment = Alignment.Center,
            ) {
                AppIconView(
                    icon = AppIcon.Moon,
                    tint = if (night) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    size = 15.dp,
                )
            }
        }
    }
}
