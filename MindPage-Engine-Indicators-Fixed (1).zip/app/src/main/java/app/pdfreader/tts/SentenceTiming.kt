package app.pdfreader.tts

import app.pdfreader.ai.Pause

/**
 * Works out when each sentence of a chunk starts inside its audio.
 *
 * A plain "characters so far / total characters" estimate drifts by several sentences in a long chunk
 * (numbers, abbreviations and pauses are not proportional to length). Instead the real pauses of the audio
 * are used. All sentence boundaries of the chunk are placed TOGETHER (dynamic programming), so one wrong pick
 * (for example a comma pause) can no longer push every later sentence out of place:
 *  - every boundary may use a detected pause (the closer to its estimated position and the longer, the better)
 *    or fall back to its own estimate,
 *  - boundaries stay in order and keep a minimum sentence length.
 * When the audio has no usable pauses the estimate itself is used, so the result is never worse than before.
 */
object SentenceTiming {
    private class Cand(val t: Long, val cost: Double)

    fun align(lens: IntArray, durationMs: Long, pauses: List<Pause>): LongArray {
        val n = lens.size
        val starts = LongArray(n)
        if (n <= 1 || durationMs <= 0) return starts

        val weights = DoubleArray(n) { lens[it] + 12.0 }
        val total = weights.sum()
        val sigma = maxOf(700.0, durationMs * 0.08)
        val minGap = LongArray(n) { minOf(3000L, (lens[it] * 45L).coerceAtLeast(800L)) }

        // candidates[k - 1] = possible start times of sentence k (k = 1 until n)
        val candidates = ArrayList<List<Cand>>(n - 1)
        var acc = 0.0
        for (k in 1 until n) {
            acc += weights[k - 1]
            val expected = (durationMs * acc / total).toLong()
            val row = ArrayList<Cand>()
            row.add(Cand(expected, 1.0))
            for (p in pauses) {
                val dev = kotlin.math.abs(p.centerMs - expected).toDouble()
                if (dev > 3 * sigma) continue
                val bonus = 3.0 * ((p.lengthMs - 150.0) / 450.0).coerceIn(0.0, 1.0)
                row.add(Cand(p.centerMs, (dev / sigma) * (dev / sigma) - bonus))
            }
            candidates.add(row)
        }

        val inf = Double.MAX_VALUE / 4
        val cost = Array(n - 1) { DoubleArray(candidates[it].size) { inf } }
        val prev = Array(n - 1) { IntArray(candidates[it].size) { -1 } }
        for (j in candidates[0].indices) {
            val c = candidates[0][j]
            if (c.t >= minGap[0]) cost[0][j] = c.cost
        }
        for (k in 1 until n - 1) {
            for (j in candidates[k].indices) {
                val c = candidates[k][j]
                for (i in candidates[k - 1].indices) {
                    val before = cost[k - 1][i]
                    if (before >= inf) continue
                    if (c.t < candidates[k - 1][i].t + minGap[k]) continue
                    val v = before + c.cost
                    if (v < cost[k][j]) {
                        cost[k][j] = v
                        prev[k][j] = i
                    }
                }
            }
        }

        val lastRow = n - 2
        var bestJ = -1
        var bestCost = inf
        for (j in cost[lastRow].indices) {
            if (cost[lastRow][j] < bestCost) { bestCost = cost[lastRow][j]; bestJ = j }
        }
        if (bestJ < 0) {
            // No consistent chain (very short audio): plain character-count estimate.
            var a = 0.0
            for (k in 1 until n) {
                a += weights[k - 1]
                val expected = (durationMs * a / total).toLong()
                starts[k] = maxOf(expected, starts[k - 1] + minGap[k - 1]).coerceAtMost(maxOf(0L, durationMs - 200L))
            }
            return starts
        }

        val picked = LongArray(n - 1)
        var j = bestJ
        for (k in lastRow downTo 0) {
            picked[k] = candidates[k][j].t
            j = prev[k][j]
            if (j < 0 && k > 0) break
        }
        for (k in 1 until n) {
            starts[k] = maxOf(picked[k - 1], starts[k - 1] + minGap[k - 1]).coerceAtMost(maxOf(0L, durationMs - 200L))
        }
        return starts
    }
}
