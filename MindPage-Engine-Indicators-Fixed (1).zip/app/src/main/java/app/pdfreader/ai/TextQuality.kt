package app.pdfreader.ai

enum class PageTextKind {
    CLEAN,
    NONE,
    GARBLED,
}

class TextVerdict(val kind: PageTextKind, val reason: String)

/** Expected script of an OCR result, used by [TextQuality.ocrQuality]. */
enum class OcrScript { LATIN, PERSIAN }

object TextQuality {
    private val VOWELS = "aeiouyAEIOUYàáâãäåæèéêëìíîïòóôõöøùúûüýÿœ"

    private fun isArabicScript(c: Char) =
        c in '\u0600'..'\u06FF' || c in '\u0750'..'\u077F' || c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isPresentationForm(c: Char) = c in '\uFB50'..'\uFDFF' || c in '\uFE70'..'\uFEFF'

    private fun isLatin(c: Char) = c in 'A'..'Z' || c in 'a'..'z' || c in '\u00C0'..'\u024F'

    // ---- OCR result quality (decides whether to fall back to online OCR) ----
    const val OCR_MIN_CHARS = 40
    const val OCR_MIN_CONFIDENCE = 50
    const val OCR_MIN_SCRIPT_RATIO = 0.6
    const val OCR_MAX_SYMBOL_RATIO = 0.2
    const val OCR_MAX_JUNK_TOKEN_RATIO = 0.35
    private const val OCR_COMMON_PUNCT = ".,;:!?'\"()[]{}-–—/%&+=*•·…«»،؛؟’‘“”_#@"
    private const val OCR_SINGLE_OK = "aAIو"
    private val OCR_FILLER = Regex("[._\\-–—…·•]{3,}")
    private val OCR_WS = Regex("\\s+")

    /** true = the OCR text looks usable; false = weak/garbled (caller may try online OCR). */
    fun ocrQuality(text: String, script: OcrScript, tessConfidence: Int? = null): Boolean {
        val cleaned = text.replace(OCR_FILLER, " ").trim()
        if (cleaned.length < OCR_MIN_CHARS) return false
        if (tessConfidence != null && tessConfidence < OCR_MIN_CONFIDENCE) return false
        val letters = cleaned.count { it.isLetter() }
        if (letters < OCR_MIN_CHARS / 2) return false
        val scriptLetters = cleaned.count {
            when (script) {
                OcrScript.LATIN -> isLatin(it)
                OcrScript.PERSIAN -> it.isLetter() && isArabicScript(it)
            }
        }
        if (scriptLetters.toDouble() / letters < OCR_MIN_SCRIPT_RATIO) return false
        val nonSpace = cleaned.count { !it.isWhitespace() }
        if (nonSpace == 0) return false
        val symbols = cleaned.count { !it.isWhitespace() && !it.isLetterOrDigit() && it !in OCR_COMMON_PUNCT }
        if (symbols.toDouble() / nonSpace > OCR_MAX_SYMBOL_RATIO) return false
        val tokens = cleaned.split(OCR_WS).filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return false
        val junk = tokens.count { tk -> tk.length == 1 && tk[0].isLetter() && tk[0] !in OCR_SINGLE_OK }
        return junk.toDouble() / tokens.size <= OCR_MAX_JUNK_TOKEN_RATIO
    }

    /**
     * Composite OCR quality estimate (0..100). It deliberately combines OCR confidence
     * with text completeness and corruption signals instead of trusting mean confidence alone.
     */
    fun ocrQualityScore(text: String, script: OcrScript, tessConfidence: Int? = null): Int {
        if (text.isBlank()) return 0
        val cleaned = text.trim()
        val letters = cleaned.count { it.isLetter() }
        val tokens = cleaned.split(Regex("\\s+")).filter { it.isNotBlank() }
        val malformed = cleaned.count { it == '\uFFFD' || it in '\uE000'..'\uF8FF' }
        val singleLetter = tokens.count { it.length == 1 && it[0].isLetter() }
        val scriptLetters = cleaned.count {
            when (script) {
                OcrScript.LATIN -> isLatin(it)
                OcrScript.PERSIAN -> it.isLetter() && isArabicScript(it)
            }
        }
        val scriptRatio = if (letters == 0) 0.0 else scriptLetters.toDouble() / letters
        val symbolRatio = cleaned.count { !it.isWhitespace() && !it.isLetterOrDigit() && it !in OCR_COMMON_PUNCT }.toDouble() /
            cleaned.count { !it.isWhitespace() }.coerceAtLeast(1)
        var score = 100
        if (cleaned.length < OCR_MIN_CHARS) score -= 35
        if (letters < OCR_MIN_CHARS / 2) score -= 25
        if (scriptRatio < OCR_MIN_SCRIPT_RATIO) score -= 25
        if (symbolRatio > OCR_MAX_SYMBOL_RATIO) score -= 20
        if (tokens.isNotEmpty() && singleLetter.toDouble() / tokens.size > OCR_MAX_JUNK_TOKEN_RATIO) score -= 20
        if (malformed > 0) score -= (malformed * 8).coerceAtMost(30)
        if (tessConfidence != null && tessConfidence >= 0) {
            score = (score * 0.75 + tessConfidence.coerceIn(0, 100) * 0.25).toInt()
        }
        return score.coerceIn(0, 100)
    }

    fun assess(raw: String): TextVerdict {
        var visible = 0
        var broken = 0
        var letters = 0
        var latin = 0
        var arabic = 0
        var shaped = 0
        var otherLetters = 0
        var symbols = 0
        for (c in raw) {
            if (c.isWhitespace()) continue
            visible++
            when {
                c == '\uFFFD' || c in '\uE000'..'\uF8FF' || c in '\u0080'..'\u009F' || (c.code < 32) -> broken++
                isArabicScript(c) -> { letters++; arabic++; if (isPresentationForm(c)) shaped++ }
                isLatin(c) -> { letters++; latin++ }
                c.isLetter() -> { letters++; otherLetters++ }
                c.isDigit() -> {}
                Character.getType(c).let {
                    it == Character.OTHER_SYMBOL.toInt() || it == Character.MODIFIER_SYMBOL.toInt() || it == Character.SURROGATE.toInt()
                } -> symbols++
            }
        }
        broken += Regex("\\(cid:\\d+\\)").findAll(raw).count() * 6
        if (visible < 40) return TextVerdict(PageTextKind.NONE, "لایه‌ی متنی ندارد")
        if (broken * 100 > visible * 3) return TextVerdict(PageTextKind.GARBLED, "کاراکترهای نامعتبر")
        if (symbols * 100 > visible * 20) return TextVerdict(PageTextKind.GARBLED, "نمادهای بی‌معنی")

        val tokens = raw.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (tokens.size >= 12) {
            val single = tokens.count { it.length == 1 && it[0].isLetter() }
            if (single * 100 > tokens.size * 45) return TextVerdict(PageTextKind.GARBLED, "حرف‌های جدا از هم")
            val avg = tokens.sumOf { it.length } / tokens.size
            if (avg > 25) return TextVerdict(PageTextKind.GARBLED, "کلمات چسبیده")
        }
        if (letters > 0 && otherLetters * 100 > letters * 30) return TextVerdict(PageTextKind.GARBLED, "ترکیب نامعمول نوشتارها")
        if (arabic > latin) {
            if (arabic > 0 && shaped * 100 > arabic * 35) return TextVerdict(PageTextKind.GARBLED, "حروف شکل‌یافته/وارونه")
        } else if (latin > 0) {
            val words = tokens.map { w -> w.filter { it.isLetter() } }.filter { it.length >= 3 && !it.all { ch -> ch.isUpperCase() } }
            if (words.size >= 15) {
                val noVowel = words.count { w -> w.none { it in VOWELS } }
                if (noVowel * 100 > words.size * 50) return TextVerdict(PageTextKind.GARBLED, "کلمات بدون واکه (رمزگذاری خراب)")
            }
        }
        return TextVerdict(PageTextKind.CLEAN, "")
    }

    private val pageNumber = Regex("^(page\\s*)?([0-9\u06F0-\u06F9\u0660-\u0669]{1,4}|[ivxlcdm]+)$", RegexOption.IGNORE_CASE)
    private val inddStamp = Regex(".*\\.(indd|idml|ai|psd|qxd)\\s+\\d+.*", RegexOption.IGNORE_CASE)
    private val publisherFooter = Regex(
        "^(downloaded from|wiley online library|see the terms and conditions|terms and conditions|" +
            "all rights reserved|creative commons license|published by|doi:\\s*10\\.|oa articles are governed).*",
        RegexOption.IGNORE_CASE
    )
    private val copyrightLine = Regex(
        ".*(all rights reserved|john wiley\\s*&\\s*sons|companion website|www\\.wiley\\.com|" +
            "text and data mining and training of artificial intelligence|published \\d{4} by|" +
            "©\\s*\\d{4}|copyright\\s*©|rights for text and data mining).*",
        RegexOption.IGNORE_CASE
    )
    private val publisherUrl = Regex(".*(onlinelibrary\\.wiley\\.com|sciencedirect\\.com|springerlink\\.com|tandfonline\\.com|wiley\\.com/go/).*", RegexOption.IGNORE_CASE)
    private val tableCaption = Regex(
        "^table\\s+\\d+(\\.\\d+)?\\.?(\\s+[^.]{1,80})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val shortTableCell = Regex(
        "^(intention|color used|addition|deletion|comment|dark gray|gray|black|white|red|blue|green|" +
            "yes|no|n/?a|optional|required|must|preferred)\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val runningHeader = Regex(
        "^([ivxlcdm]+|[0-9]{1,4})\\s*[|•\\-–—]\\s*.+$|" +
            "^.+[|•\\-–—]\\s*([ivxlcdm]+|[0-9]{1,4})$|" +
            "^\\d{1,3}\\s*\\|\\s*.+$|^.+\\|\\s*\\d{1,3}$",
        RegexOption.IGNORE_CASE
    )
    private val sectionTitleWithPage = Regex("^\\d+(\\.\\d+)+\\s+.{8,70}\\s+\\d{1,3}$")
    private val figureCaption = Regex(
        "^(figure|fig\\.?|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?(\\s+[^.]{1,90})?\\.\\s*$",
        RegexOption.IGNORE_CASE
    )
    private val legalStamp = Regex(
        ".*(this document was prepared exclusively|permit to practice|permit number|engineer and permit stamps|" +
            "subjects to the terms and conditions|legal terms|signature:\\s*-+|date:\\s*-+).*",
        RegexOption.IGNORE_CASE
    )
    private val romanHeader = Regex(
        "^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|index|foreword|chapter|section).*$",
        RegexOption.IGNORE_CASE
    )
    private val shortSectionTitle = Regex(
        "^(preface|contents|introduction|acknowledgment|acknowledgements|foreword|index|abstract|summary)$",
        RegexOption.IGNORE_CASE
    )
    private val diagramFormula = Regex(".*\\b(sizing|specification|development|p&id)\\b.*[+=].*", RegexOption.IGNORE_CASE)

    private val DIAGRAM_LABELS = setOf(
        "process", "control", "operation", "equipment & instruments", "equipment and instruments",
        "location", "regulations: hse", "regulations", "hse", "maintenance",
        "supporting plants", "calculation", "technical", "not technical",
        "p&id development", "sizing or specification", "p&id", "sizing",
        "p&id development guidelines", "p&id demonstration rules", "p&id drafting rules",
        "development guidelines", "demonstration rules", "drafting rules",
        "where should i put this valve?", "what is its symbol?", "what should be the thickness of this symbol?",
        "calculations", "loop diagram", "alarm table", "piping ds", "piping model", "isometrics",
        "mechanical ds", "plant modeling", "as a reference in plant during operation", "loop diagrams",
    )

    private fun isCaptionOnly(line: String): Boolean {
        val t = line.trim()
        if (t.length > 110) return false
        if (!Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+", RegexOption.IGNORE_CASE).containsMatchIn(t)) return false
        if (Regex(
                "\\b(outlines?|shows?|showed|showing|describes?|summarizes?|lists?|presents?|provides?|indicates?|explains?)\\b",
                RegexOption.IGNORE_CASE
            ).containsMatchIn(t)
        ) return false
        return figureCaption.matches(t) || tableCaption.matches(t) ||
            Regex("^(figure|fig\\.?|table|جدول|شکل)\\s*\\d+(\\.\\d+)*\\.?\\s*.{0,90}$", RegexOption.IGNORE_CASE).matches(t)
    }

    fun isJunkOrDiagram(line: String): Boolean {
        val trimmed = line.trim()
        if (trimmed.isEmpty()) return true
        if (Regex("^\\d{1,2}\\.\\s+\\S.+").matches(trimmed)) return false
        if (Regex("^\\d+(\\.\\d+)+\\s+\\S.+").matches(trimmed)) {
            if (sectionTitleWithPage.matches(trimmed)) return true
            return false
        }
        if (pageNumber.matches(trimmed)) return true
        if (inddStamp.matches(trimmed)) return true
        if (publisherFooter.matches(trimmed)) return true
        if (copyrightLine.matches(trimmed)) return true
        if (publisherUrl.matches(trimmed)) return true
        if (runningHeader.matches(trimmed)) return true
        if (sectionTitleWithPage.matches(trimmed)) return true
        if (romanHeader.matches(trimmed)) return true
        if (shortSectionTitle.matches(trimmed)) return true
        if (legalStamp.matches(trimmed)) return true
        if (diagramFormula.matches(trimmed)) return true
        // Figure/table captions are semantic content and must survive cleanup.
        if (shortTableCell.matches(trimmed)) return true
        val lower = trimmed.lowercase().removeSuffix(".").trim()
        if (lower in DIAGRAM_LABELS) return true
        if (trimmed in listOf("+", "=", "==", "->", "-->", "|", "—", "–")) return true
        if (trimmed.length < 40 && Regex("^[ivxlcdm]+\\s*[|•\\-–—:. ]*(preface|contents|intro|chapter|section)?$", RegexOption.IGNORE_CASE).matches(trimmed)) return true
        if (trimmed.length <= 24 && lower in setOf(
                "dark gray", "light gray", "gray", "black", "white", "red", "blue", "green",
                "addition", "deletion", "comment", "intention", "color used", "mark up", "markup"
            )) return true
        val words = trimmed.split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (words.size in 2..8 && (trimmed.endsWith("?") || lower.contains("p&id"))) {
            if (lower.contains("guideline") || lower.contains("rule") || lower.contains("valve") ||
                lower.contains("symbol") || lower.contains("thickness") || lower.contains("where should") ||
                lower.contains("what is") || lower.contains("what should")) return true
        }
        return false
    }

    fun looksLikeTableRow(line: String): Boolean {
        val t = line.trim()
        if (t.startsWith("|") && t.indexOf('|', startIndex = 1) >= 0) return true
        if (t.contains('|') && t.split('|').size >= 3) return true
        if (t.contains('\t')) {
            if (t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }.size >= 2) return true
        }
        val cells = splitColumns(t)
        if (cells.size >= 2 && cells.count { it.length <= 48 } >= 2) return true
        return false
    }

    fun promoteTables(raw: String): String {
        // Existing Markdown grids are authoritative structure. Never flatten wide tables:
        // engineering/data tables commonly have 6-12 columns and must survive translation.
        val mdLines = raw.lines().filter { it.trim().startsWith("|") && it.indexOf('|', startIndex = 1) >= 0 }
        if (mdLines.size >= 2) return raw

        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val out = ArrayList<String>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            // Caption-anchored table: "Table 4.4 ..." then short/aligned rows until long prose.
            if (line.trim().matches(Regex("""^(Table|TABLE|جدول)\s*\d.*"""))) {
                out += line
                i++
                val block = ArrayList<List<String>>()
                while (i < lines.size) {
                    val L = lines[i]
                    if (L.isBlank()) {
                        i++
                        if (block.size >= 2) break else continue
                    }
                    if (isNarrativeSentence(L) && L.split(Regex("\\s+")).size > 12) break
                    if (L.trim().matches(Regex("""^\d+(\.\d+)+\s+\S+.*"""))) break
                    val c = splitColumns(L)
                    if (c.size >= 2) block += c
                    else if (L.length <= 60 && block.isNotEmpty()) block += listOf(L.trim())
                    else if (block.isEmpty()) {
                        out += L
                        i++
                        continue
                    } else break
                    i++
                }
                if (block.size >= 2) {
                    val cols = block.maxOf { it.size }.coerceAtLeast(2)
                    val norm = block.map { r -> List(cols) { k -> r.getOrElse(k) { "" }.trim() } }
                    out += "| " + norm[0].joinToString(" | ") + " |"
                    out += "| " + List(cols) { "---" }.joinToString(" | ") + " |"
                    for (r in norm.drop(1)) out += "| " + r.joinToString(" | ") + " |"
                    out += ""
                }
                continue
            }

            val cells = splitColumns(line)
            if (cells.size >= 2 && cells.all { it.length <= 80 } && !isNarrativeSentence(line)) {
                val block = ArrayList<List<String>>()
                var j = i
                while (j < lines.size) {
                    val c = splitColumns(lines[j])
                    if (c.size >= 2 && c.all { it.length <= 80 } && !isNarrativeSentence(lines[j])) {
                        block += c
                        j++
                    } else if (lines[j].isBlank() && j + 1 < lines.size && splitColumns(lines[j + 1]).size >= 2) {
                        j++
                    } else break
                }
                if (block.size >= 2) {
                    val cols = block.maxOf { it.size }
                    // Prose false-positive guard: real tables rarely exceed 5 columns
                    if (cols in 2..5) {
                        val norm = block.map { r -> List(cols) { k -> r.getOrElse(k) { "" }.trim() } }
                        out += "| " + norm[0].joinToString(" | ") + " |"
                        out += "| " + List(cols) { "---" }.joinToString(" | ") + " |"
                        for (r in norm.drop(1)) {
                            out += "| " + r.joinToString(" | ") + " |"
                        }
                        out += ""
                        i = j
                        continue
                    }
                }
            }
            out += line
            i++
        }
        return out.joinToString("\n")
    }

    private fun isNarrativeSentence(line: String): Boolean {
        val t = line.trim()
        if (t.contains('|')) return false
        if (t.endsWith(".") && t.split(Regex("\\s+")).size > 8) return true
        return false
    }

    fun splitColumns(line: String): List<String> {
        val t = line.trim()
        if (t.isEmpty()) return emptyList()
        if (t.contains('|')) {
            return t.split('|').map { it.trim() }.filter { it.isNotEmpty() && !it.matches(Regex("^:?-+:?$")) }
        }
        if (t.contains('\t')) {
            val parts = t.split('\t').map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size >= 2) return parts
        }
        val multi = t.split(Regex("\\s{2,}")).map { it.trim() }.filter { it.isNotEmpty() }
        if (multi.size >= 2) return multi

        val pvuRegex = Regex("""^([A-Za-z\u0600-\u06FF\s]{2,25})\s+([\d\.\+\-×x\^]+)\s*([A-Za-z°µ%Ω\u0600-\u06FF\/\^0-9]{1,12})$""")
        val m = pvuRegex.matchEntire(t)
        if (m != null) {
            return listOf(m.groupValues[1].trim(), m.groupValues[2].trim(), m.groupValues[3].trim())
        }

        if (t.contains(':')) {
            val parts = t.split(':').map { it.trim() }.filter { it.isNotEmpty() }
            if (parts.size == 2 && parts[0].length <= 30) return parts
        }

        // Do NOT split ordinary prose / labels into fake table cells.
        // Only treat as multi-column when there is clear alignment (tabs / 2+ spaces / pipes)
        // or a parameter-value-unit pattern above. Aggressive single-space splits destroy
        // Persian and English sentences and equipment callouts.
        return listOf(t)
    }

    fun localClean(raw: String): String {
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim() }
        val paragraphs = ArrayList<String>()
        val cur = StringBuilder()
        var prev = ""
        fun flush() { if (cur.isNotBlank()) paragraphs += cur.toString().trim(); cur.clear() }
        for (l in lines) {
            if (l.isEmpty()) { flush(); prev = ""; continue }
            // Markdown table rows are structure, never "junk": the junk filter dropped rows that mention P&ID, valve, symbol...
            val isPipeRow = l.startsWith("|") && l.indexOf('|', startIndex = 1) >= 0
            if (!isPipeRow && isJunkOrDiagram(l)) continue
            if (looksLikeTableRow(l) || (l.startsWith("|") && l.contains('|'))) {
                flush()
                paragraphs += l
                prev = ""
                continue
            }
            if (cur.isEmpty()) { cur.append(l); prev = l; continue }
            val endsHyphen = prev.endsWith("-") || prev.endsWith("\u00AD")
            val endsSentence = prev.last() in ".!?\u061F:\u2026"
            when {
                endsHyphen && l.first().isLowerCase() -> { cur.setLength(cur.length - 1); cur.append(l) }
                endsSentence && (l.first().isUpperCase() || l.first() in '\u0600'..'\u06FF' || l.first() in "«\"“‘'[") -> {
                    if (prev.length < 50) {
                        flush()
                        cur.append(l)
                    } else {
                        cur.append(' ').append(l)
                    }
                }
                else -> cur.append(' ').append(l)
            }
            prev = l
        }
        flush()
        if (paragraphs.isNotEmpty()) {
            val first = paragraphs[0]
            val cleanedFirst = first
                .replace(Regex("^(xxiv|xxiii|xxii|xxi|xx|xix|xviii|xvii|xvi|xv|xiv|xiii|xii|xi|x|ix|viii|vii|vi|v|iv|iii|ii|i)\\s*[|•\\-–—:.]?\\s*(preface|contents|introduction|acknowledgment|acknowledgements|foreword)?\\s*", RegexOption.IGNORE_CASE), "")
                .trim()
            if (cleanedFirst != first) {
                if (cleanedFirst.isBlank()) paragraphs.removeAt(0)
                else paragraphs[0] = cleanedFirst
            }
        }
        paragraphs.removeAll { p ->
            copyrightLine.matches(p) || publisherFooter.matches(p) || publisherUrl.matches(p) ||
                (p.length > 80 && p.contains("All rights reserved", ignoreCase = true) && p.contains("Wiley", ignoreCase = true))
        }
        return paragraphs.joinToString("\n\n")
    }

    /**
     * Conservative furniture cleanup: preserve captions, technical labels and semantic content.
     */

    /** True if OCR/text-layer is polluted with publisher/download watermarks. */
    fun hasPublisherNoise(text: String): Boolean {
        if (text.isBlank()) return false
        val hits = listOf(
            Regex("""(?i)\bwiley\b"""),
            Regex("""(?i)online\s+library"""),
            Regex("""(?i)creative\s+commons"""),
            Regex("""(?i)downloaded\s+from"""),
            Regex("""(?i)oregon\s+health"""),
            Regex("""(?i)\bjounh\b"""),
            Regex("""(?i)terms\s+and\s+conditions"""),
            Regex("""(?i)\bindd\b"""),
            Regex("""\[\d{1,2}/\d{1,2}/\d{2,4}\]"""),
        ).count { it.containsMatchIn(text) }
        return hits >= 2
    }

    /** Drop high-confidence publisher/watermark lines and glued tokens. */
    fun stripPublisherNoise(raw: String): String {
        // Only quarantine unmistakable standalone publisher/watermark lines. A technical
        // term or a person's name embedded in a sentence is never deleted by substring match.
        val patterns = listOf(
            Regex("""(?i)^wiley\s+online\s+library$"""),
            Regex("""(?i)^creative\s+commons(?:\s+.*)?$"""),
            Regex("""(?i)^downloaded\s+from\s+.{0,100}$"""),
            Regex("""(?i)^oregon\s+health(?:\s+&\s+science)?(?:\s+university)?$"""),
            Regex("""(?i)^terms\s+and\s+conditions$"""),
            Regex("""(?i)^permission\s+from\s+the\s+publisher$"""),
            Regex("""(?i)^all\s+rights\s+reserved$"""),
        )
        val kept = raw.lineSequence().map { it.trimEnd() }.filter { line ->
            val t = line.trim()
            t.isEmpty() || !patterns.any { it.matches(t) }
        }.joinToString("\n")
        return kept.replace(Regex("""[ \t]{2,}"""), " ").trim()
    }

    fun stripPageFurniture(raw: String): String {
        val raw = stripPublisherNoise(raw)
        // Conservative: never drop equipment tags, formulas, units, or figure/table captions with body text.
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n')
        if (lines.isEmpty()) return raw
        val pageOnly = Regex("""^(?:[0-9]{1,4}|[ivxlcdm]{1,8})$""", RegexOption.IGNORE_CASE)
        val licenseOnly = Regex(
            """(?i)^(all rights reserved|copyright\s*©?\s*\d{4}|©\s*\d{4}|creative commons|licensed under|wiley online library|permission from the publisher)\.?$"""
        )
        // Count exact line frequency for header/footer detection (short lines only)
        val freq = HashMap<String, Int>()
        for (l0 in lines) {
            val l = l0.trim()
            if (l.length in 4..60) freq[l] = (freq[l] ?: 0) + 1
        }
        val kept = ArrayList<String>(lines.size)
        val n = lines.size
        for ((i, l0) in lines.withIndex()) {
            val l = l0.trim()
            if (l.isEmpty()) { kept += ""; continue }
            // Keep equipment tags / formulas / units always
            if (Regex("""[A-Za-z]{1,6}-\d+[A-Za-z]?""").containsMatchIn(l)) { kept += l0; continue }
            if (Regex("""\d+\s*(psi|bar|kpa|mpa|°?[CF]|mm|cm|m\b|kg|m³|m3|%)""", RegexOption.IGNORE_CASE).containsMatchIn(l)) {
                kept += l0; continue
            }
            if (Regex("""[Pp]\s*=\s*|ρ|[A-Za-z]\s*=\s*[^\n=]{1,40}""").containsMatchIn(l)) { kept += l0; continue }
            // Keep figure/table captions (label + description)
            if (Regex("""^(figure|fig\.?|table|جدول|شکل)\s*[\dIVXLC.-]+""", RegexOption.IGNORE_CASE).containsMatchIn(l) && l.length > 12) {
                kept += l0; continue
            }
            // Drop pure page numbers
            if (pageOnly.matches(l)) continue
            // Drop pure license one-liners
            if (licenseOnly.matches(l)) continue
            // Drop short lines that repeat often and sit in first/last 2 lines of page (running header/footer)
            val nearEdge = i < 2 || i >= n - 2
            if (nearEdge && l.length in 4..60 && (freq[l] ?: 0) >= 2) continue
            kept += l0
        }
        return localClean(kept.joinToString("\n"))
    }


    /**
     * Conservative, fully on-device cleanup for each page. It removes only high-confidence
     * page furniture and standalone figure captions, normalizes broken line wraps, and
     * promotes clearly aligned rows to Markdown tables. No network/API/model is involved.
     */
    fun manualPageCleanup(raw: String): String {
        if (raw.isBlank()) return raw
        val lines = raw.replace("\r\n", "\n").replace('\r', '\n').lines()
        // Captions and labels are meaningful page content; never discard them as furniture.
        val kept = lines
        // Existing furniture filter is deliberately conservative about formulas, units and tables.
        val furnitureRemoved = stripPageFurniture(kept.joinToString("\n"))
        val normalized = localClean(furnitureRemoved)
        if (normalized.isBlank()) return raw.trim()
        return promoteTables(normalized).trim()
    }

    /**
     * Aggressive body-only cleanup for the "typed text only" reading mode.
     * Drops headers/footers, page numbers, footnotes, figure/table captions, markdown
     * tables and short diagram labels — keeps continuous prose and real section headings.
     */
    fun readingBodyCleanup(raw: String): String {
        if (raw.isBlank()) return raw
        val base = stripPageFurniture(raw)
        val lines = base.replace("\r\n", "\n").replace('\r', '\n').lines()
        val out = ArrayList<String>()
        var inTable = false
        val footnoteMarker = Regex("""^(\[\d{1,3}\]|\(\d{1,3}\)|\d{1,3}\.|†|‡|\*|⁎)\s+\S.*""")
        val footnoteAlone = Regex("""^(\[\d{1,3}\]|\d{1,3})$""")
        val captionLine = Regex(
            """^(figure|fig\.?|table|جدول|شکل)\s*[\dIVXLCDM]+(\.[\dIVXLCDM]+)*\b.*$""",
            RegexOption.IGNORE_CASE
        )
        val sourceNote = Regex(
            """^(source|منبع|adapted from|برگرفته|reprinted|permission)\b.*$""",
            RegexOption.IGNORE_CASE
        )
        val headingKeep = Regex(
            """^(?:(?:Chapter|Unit|Section|Part|فصل|بخش)\s+\d+|[0-9]+(?:\.[0-9]+)+\s+\S.+|[0-9]+\.\s+\S.+)$""",
            RegexOption.IGNORE_CASE
        )

        for (line0 in lines) {
            val line = line0.trim()
            if (line.isEmpty()) {
                if (out.isNotEmpty() && out.last().isNotEmpty()) out += ""
                inTable = false
                continue
            }
            // Markdown / pipe tables
            if (line.startsWith("|") || (line.contains('|') && line.count { it == '|' } >= 2)) {
                inTable = true
                continue
            }
            if (inTable) {
                // End table block on a long prose line; otherwise keep skipping short residual rows.
                if (line.length >= 60 && line.count { it.isLetter() } > 30 && !looksLikeTableRow(line)) {
                    inTable = false
                } else {
                    continue
                }
            }
            if (looksLikeTableRow(line) && line.length < 120) continue
            if (captionLine.matches(line) || isCaptionOnly(line)) continue
            if (sourceNote.matches(line)) continue
            if (footnoteMarker.matches(line) || footnoteAlone.matches(line)) continue
            if (pageNumber.matches(line)) continue
            if (isJunkOrDiagram(line) && !headingKeep.matches(line)) continue
            // Drop very short all-caps banner lines (running heads)
            if (line.length in 3..48 && line == line.uppercase() && line.any { it.isLetter() } &&
                line.count { it.isLetter() } >= line.length / 2
            ) continue
            out += line
        }

        val joined = out.joinToString("\n")
        val normalized = localClean(joined)
        // Do NOT promoteTables here — tables were intentionally removed for reading.
        val result = normalized.trim()
        return if (result.isBlank()) {
            // Safety: never wipe an entire page; fall back to conservative cleanup.
            manualPageCleanup(raw)
        } else result
    }

    fun segmentPageText(raw: String): List<String> {
        if (raw.isBlank()) return emptyList()
        val lines = raw.replace("\r\n", "\n").replace("\r", "\n").lines()
        val segments = mutableListOf<String>()
        val currentPara = StringBuilder()

        fun flushPara() {
            val p = currentPara.toString().trim()
            if (p.isNotEmpty()) {
                segments.add(p)
            }
            currentPara.clear()
        }

        fun isHeadingLine(l: String): Boolean {
            val t = l.trim()
            if (t.startsWith("#")) return true
            if (Regex("""^(?:(?:Chapter|Unit|Section|Part)\s+\d+|[0-9]+(?:\.[0-9]+)+\s+[A-Z\u0600-\u06FF]).*""", RegexOption.IGNORE_CASE).matches(t)) {
                if (!Regex("""\.{3,}|_{2,}|\?$""").containsMatchIn(t)) return true
            }
            return false
        }

        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank()) {
                flushPara()
                continue
            }
            if (isHeadingLine(trimmed)) {
                flushPara()
                segments.add(trimmed)
                continue
            }
            if (currentPara.isEmpty()) {
                currentPara.append(trimmed)
            } else {
                val prev = currentPara.toString()
                if (prev.endsWith("-") && !prev.endsWith(" -")) {
                    currentPara.setLength(currentPara.length - 1)
                    currentPara.append(trimmed)
                } else {
                    currentPara.append(" ").append(trimmed)
                }
            }
        }
        flushPara()
        return segments
    }

    fun isRealHeading(seg: String): Boolean {
        val t = seg.trim()
        if (Regex("""\.{3,}|_{2,}|\?$""").containsMatchIn(t)) return false
        if (t.startsWith("#")) return true
        if (Regex("""^(?:(?:Chapter|Unit|Section|Part)\s+\d+|[0-9]+(?:\.[0-9]+)+\s+[A-Z\u0600-\u06FF]).*""", RegexOption.IGNORE_CASE).matches(t)) return true
        return false
    }

    fun shouldDropSegment(seg: String): Boolean {
        val t = seg.trim()
        if (t.isEmpty()) return true

        // 1. Lines with fill-in-the-blank dots or underscores (>= 4 dots or >= 3 underscores)
        if (Regex("""\.{4,}|_{3,}""").containsMatchIn(t)) return true

        // 2. Figure or Table caption: ^(Figure|Fig.|Table|شکل|جدول)\b
        if (Regex("""^(?:Figure|Fig\.|Table|شکل|جدول)\b""", RegexOption.IGNORE_CASE).containsMatchIn(t)) return true

        // 3. Glossary box / 2-column vocabulary list
        if (Regex("""^(?:GLOSSARY|Glossary)\b""").containsMatchIn(t) || (t.contains("GLOSSARY", ignoreCase = true) && t.length < 150)) return true

        // 4. Tables and aligned columns (| or tabs or multiple large whitespace gaps)
        if (t.contains("|")) return true
        val colSplit = t.split(Regex("""\t|\s{3,}""")).filter { it.isNotBlank() }
        if (colSplit.size >= 3) return true

        // 5. Headers / footers / standalone page numbers / book banners
        if (Regex("""^(?:[0-9]{1,4}|[ivxlcdm]{1,8})$""", RegexOption.IGNORE_CASE).matches(t)) return true
        if (Regex("""^(?:all rights reserved|copyright|isbn|oxford word skills)\b""", RegexOption.IGNORE_CASE).containsMatchIn(t)) return true

        // Real heading: keep!
        if (isRealHeading(t)) return false

        // 6. Only numbers / tags / all-caps words
        val words = t.split(Regex("""\s+""")).filter { it.isNotBlank() }
        if (words.size <= 5 && words.all { w -> Regex("""^[A-Z0-9\-_.,:;]+$""").matches(w) }) return true

        // 7. >= 3 short lines in a row (< 4 words without sentence-ending dot/exclamation/question)
        val sublines = t.lines().map { it.trim() }.filter { it.isNotBlank() }
        if (sublines.size >= 3) {
            val allShort = sublines.all { l ->
                val lw = l.split(Regex("""\s+""")).filter { it.isNotBlank() }
                lw.size < 4 && !Regex("""[.!?]$""").containsMatchIn(l)
            }
            if (allShort) return true
        }

        // Short fragments (< 4 words and no sentence termination) that are not headings
        if (words.size < 4 && !Regex("""[.!?]$""").containsMatchIn(t)) return true

        // Normal continuous paragraph (kept)
        return false
    }

    fun filterMainTextOnly(segments: List<String>): List<String> {
        val kept = segments.filterNot { shouldDropSegment(it) }
        return if (kept.isNotEmpty()) kept else segments
    }

}
