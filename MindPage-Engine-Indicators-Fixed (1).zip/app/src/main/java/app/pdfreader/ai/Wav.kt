package app.pdfreader.ai

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.MessageDigest

/** A silent stretch inside a clip, in milliseconds from the clip start. */
class Pause(val startMs: Long, val endMs: Long) {
    val centerMs: Long get() = (startMs + endMs) / 2
    val lengthMs: Long get() = endMs - startMs
}

object Wav {
    /** Wraps raw 16-bit PCM in a WAV container so any player can open it. */
    fun fromPcm16(pcm: ByteArray, sampleRate: Int, channels: Int = 1): ByteArray {
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray()).putInt(36 + pcm.size).put("WAVE".toByteArray())
        header.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(channels.toShort())
        header.putInt(sampleRate).putInt(sampleRate * channels * 2).putShort((channels * 2).toShort()).putShort(16)
        header.put("data".toByteArray()).putInt(pcm.size)
        return header.array() + pcm
    }

    fun sampleRate(wav: ByteArray): Int =
        if (wav.size < 44) 24000 else ByteBuffer.wrap(wav, 24, 4).order(ByteOrder.LITTLE_ENDIAN).int.takeIf { it in 8000..96000 } ?: 24000

    fun durationMs(wav: ByteArray): Long =
        if (wav.size <= 44) 0L else (wav.size - 44) / 2L * 1000L / sampleRate(wav)

    private fun samples(wav: ByteArray): ShortArray {
        val n = (wav.size - 44) / 2
        val out = ShortArray(n)
        ByteBuffer.wrap(wav, 44, n * 2).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer().get(out)
        return out
    }

    private fun toWav(s: ShortArray, rate: Int): ByteArray {
        val bb = ByteBuffer.allocate(s.size * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (v in s) bb.putShort(v)
        return fromPcm16(bb.array(), rate)
    }


    /**
     * Returns how many samples of the clip to keep. Measured on a real Gemini recording: after the last word
     * (and ~0.2 s of near-silence) there is a ~130 ms burst of broadband noise, about 3-4x louder than the speech
     * and with a very high zero-crossing rate. Real speech, even "s"/"sh" sounds, is never both that loud and that
     * noisy, so such a trailing burst is cut off. Two tiers:
     *  1. loud noisy burst (>2x the speech level) at the end of the sound, nothing speech-like after it;
     *  2. a quieter noise-like run (>0.4x speech level) that comes after a clear quiet gap and runs to the end.
     * Real words are never cut: voiced speech has a low zero-crossing rate, and a final word is not separated
     * from the sentence by a long gap AND made only of noise. The clip stays untouched unless one tier matches.
     * Trailing digital silence is skipped first, so a long silent tail cannot hide the burst.
     */
    private fun speechEnd(x: IntArray, rate: Int): Int {
        val n = x.size
        val fr = rate / 200                       // 5 ms frames
        if (fr < 8) return n
        val nf = n / fr
        if (nf < 60) return n
        val rms = DoubleArray(nf)
        val zc = DoubleArray(nf)
        for (f in 0 until nf) {
            val s0 = f * fr
            var sq = 0.0
            var z = 0
            for (i in s0 until s0 + fr) {
                val v = x[i].toDouble()
                sq += v * v
                if (i > s0 && ((x[i - 1] < 0 && x[i] > 0) || (x[i - 1] > 0 && x[i] < 0))) z++
            }
            rms[f] = kotlin.math.sqrt(sq / fr)
            zc[f] = z.toDouble() / (fr - 1)
        }
        var endF = nf - 1
        while (endF > 0 && rms[endF] < 40.0) endF--
        if (endF < 40) return n

        val voiced = ArrayList<Double>()
        for (f in 0..endF) if (rms[f] > 400.0 && zc[f] < 0.12) voiced.add(rms[f])
        if (voiced.size < 40) return n
        voiced.sort()
        val ref = voiced[voiced.size / 2]         // typical loudness of the speech itself
        val lo = maxOf(0, endF - 240)             // the last 1.2 s of sound

        // Tier 1: loud, noisy burst.
        fun noisy1(f: Int) = rms[f] > 2.0 * ref && zc[f] >= 0.12
        var last = -1
        for (f in endF downTo lo) if (noisy1(f)) { last = f; break }
        if (last >= 0) {
            var speechAfter = false
            for (f in last + 7..endF) if (rms[f] >= 0.6 * ref) { speechAfter = true; break }
            if (!speechAfter) {
                var first = last
                var count = 1
                var gap = 0
                var f = last - 1
                while (f >= lo) {
                    if (noisy1(f)) { first = f; gap = 0; count++ } else { gap++; if (gap > 3) break }
                    f--
                }
                if (count >= 5 && last - first + 1 <= 140) {
                    val start = (first - 2) * fr
                    if (start >= n * 4 / 10 && start >= rate * 6 / 10) return start
                }
            }
        }

        // Tier 2: quieter noise-like run, separated from the speech by a quiet gap, lasting to the end.
        fun noisy2(f: Int) = rms[f] > 0.4 * ref && zc[f] >= 0.14
        if (!noisy2(endF) && !noisy2(maxOf(0, endF - 1)) && !noisy2(maxOf(0, endF - 2))) return n
        var first2 = endF
        var f2 = endF
        var gap2 = 0
        while (f2 >= lo) {
            if (noisy2(f2)) { first2 = f2; gap2 = 0 } else { gap2++; if (gap2 > 3) break }
            f2--
        }
        var cnt = 0
        for (f in first2..endF) if (noisy2(f)) cnt++
        if (cnt < 5 || endF - first2 + 1 > 160) return n
        var quiet = 0
        var q = first2 - 1
        while (q >= 0 && rms[q] < 0.08 * ref) { quiet++; q-- }
        if (quiet < 12) return n                  // needs >= 60 ms of near-silence before it
        val start = (first2 - 2) * fr
        if (start < n * 4 / 10 || start < rate * 6 / 10) return n
        return start
    }

    /**
     * Cleans one speech clip so that clips can be played back to back without clicks or "static":
     *  - removes the DC offset (constant shift),
     *  - trims digital silence/noise at both ends and aligns to exact zero-crossing,
     *  - smooth S-curve Hann fade-in (15 ms) and fade-out (25 ms) so waveform derivative is zero at boundaries,
     *  - appends a short clean silence (pause between two clips).
     */
    fun polish(wav: ByteArray): ByteArray {
        if (wav.size < 44 + 800) return wav
        val rate = sampleRate(wav)
        val rawFull = samples(wav)
        if (rawFull.size < 80) return wav

        var sum = 0L
        for (v in rawFull) sum += v
        val dc = (sum / rawFull.size).toInt()

        // Gemini ends many clips with a short, very loud burst of noise: cut it off before anything else
        // (it would also distort the peak used below to decide what counts as silence).
        val keep = speechEnd(IntArray(rawFull.size) { rawFull[it] - dc }, rate)
        val raw = if (keep < rawFull.size) rawFull.copyOf(keep) else rawFull
        val n = raw.size
        if (n < 80) return wav
        val x = IntArray(n) { raw[it] - dc }

        var peak = 0
        for (v in x) {
            val a = kotlin.math.abs(v)
            if (a > peak) peak = a
        }
        if (peak == 0) return wav

        val thr = maxOf(160, peak / 40)

        var first = 0
        while (first < n && kotlin.math.abs(x[first]) < thr) first++
        var last = n - 1
        while (last > first && kotlin.math.abs(x[last]) < thr) last--

        if (first >= last) return wav

        // Align to zero-crossings to eliminate abrupt DC edge step
        var zFirst = maxOf(0, first - rate * 15 / 1000)
        while (zFirst < first && zFirst + 1 < n) {
            if ((x[zFirst] >= 0 && x[zFirst + 1] <= 0) || (x[zFirst] <= 0 && x[zFirst + 1] >= 0)) break
            zFirst++
        }
        val from = zFirst

        var zLast = minOf(n - 1, last + rate * 15 / 1000)
        while (zLast > last && zLast > 0) {
            if ((x[zLast] >= 0 && x[zLast - 1] <= 0) || (x[zLast] <= 0 && x[zLast - 1] >= 0)) break
            zLast--
        }
        val to = maxOf(from + 1, zLast + 1)
        val len = to - from
        if (len <= 0) return wav

        // Slightly longer fades reduce click / "خش‌خش" at chunk boundaries
        val fadeIn = minOf(len / 3, rate * 20 / 1000).coerceAtLeast(1)
        val fadeOut = minOf(len / 3, rate * 35 / 1000).coerceAtLeast(1)
        val tail = rate * 70 / 1000
        val out = ShortArray(len + tail)

        // Soft peak limit (~ -1.5 dB) to avoid digital harshness / clipping grit
        val softPeak = 28000.0
        val pi = Math.PI
        for (i in 0 until len) {
            var v = x[from + i].toDouble()
            if (i < fadeIn) {
                val factor = 0.5 * (1.0 - Math.cos(pi * i / fadeIn))
                v *= factor
            }
            val r = len - 1 - i
            if (r < fadeOut) {
                val factor = 0.5 * (1.0 - Math.cos(pi * r / fadeOut))
                v *= factor
            }
            if (kotlin.math.abs(v) > softPeak) {
                val sign = if (v >= 0) 1.0 else -1.0
                v = sign * (softPeak + (kotlin.math.abs(v) - softPeak) * 0.25)
            }
            out[i] = v.toInt().coerceIn(-32768, 32767).toShort()
        }
        return toWav(out, rate)
    }

    /** Joins two clips (each one is polished first, so the joint is silent and click-free). */
    fun join(a: ByteArray, b: ByteArray): ByteArray {
        val pa = polish(a)
        val pb = polish(b)
        if (pa.size <= 44) return pb
        if (pb.size <= 44) return pa
        return fromPcm16(pa.copyOfRange(44, pa.size) + pb.copyOfRange(44, pb.size), sampleRate(a))
    }

    /**
     * Finds the quiet gaps of a clip (10 ms energy windows). Used to learn where each sentence really starts,
     * so the highlighted sentence follows the voice instead of an estimate based on character counts.
     */
    fun pauses(wav: ByteArray, minGapMs: Int = 170): List<Pause> {
        if (wav.size < 44 + 4000) return emptyList()
        val rate = sampleRate(wav)
        val s = samples(wav)
        val win = rate / 100
        val count = s.size / win
        if (count < 10) return emptyList()
        val rms = DoubleArray(count)
        for (w in 0 until count) {
            var acc = 0.0
            val base = w * win
            for (i in 0 until win) {
                val v = s[base + i].toDouble()
                acc += v * v
            }
            rms[w] = kotlin.math.sqrt(acc / win)
        }
        val sorted = rms.sortedArray()
        val loud = sorted[(count * 0.9).toInt().coerceAtMost(count - 1)]
        val thr = maxOf(120.0, loud * 0.06)
        val out = ArrayList<Pause>()
        var runStart = -1
        for (w in 0..count) {
            val quiet = w < count && rms[w] < thr
            if (quiet && runStart < 0) runStart = w
            if (!quiet && runStart >= 0) {
                val lenMs = (w - runStart) * 10
                // ignore the lead-in and the tail: only gaps inside the speech tell where sentences change
                if (lenMs >= minGapMs && runStart > 3 && w < count - 3) out += Pause(runStart * 10L, w * 10L)
                runStart = -1
            }
        }
        return out
    }
}

fun sha256(s: String): String =
    MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/** Text prepared for speech: no Markdown marks, no table borders. */
fun plainForSpeech(s: String): String = s.lines()
    .filterNot { Regex("^[\\s|:\\-]+$").matches(it) }
    .joinToString("\n") { l ->
        l.replace("**", "").replace("__", "")
            .replace(Regex("^\\s*#{1,6}\\s*"), "")
            .replace(Regex("^\\s*[*\\-•]\\s+"), "")
            .replace("|", " ")
    }.trim()

/** Splits text into speakable chunks. The first one is short so playback starts quickly. */
fun splitForSpeech(text: String, firstMax: Int = 350, max: Int = 1100): List<String> {
    val sentences = text.split(Regex("(?<=[.!?؟۔…])\\s+|\\n+")).map { it.trim() }.filter { it.isNotEmpty() }
    val out = mutableListOf<String>()
    val sb = StringBuilder()
    for (s in sentences) {
        val limit = if (out.isEmpty()) firstMax else max
        if (sb.isNotEmpty() && sb.length + s.length + 1 > limit) {
            out.add(sb.toString())
            sb.clear()
        }
        if (s.length > max) {
            if (sb.isNotEmpty()) { out.add(sb.toString()); sb.clear() }
            s.chunked(max).forEach { out.add(it) }
        } else {
            if (sb.isNotEmpty()) sb.append(' ')
            sb.append(s)
        }
    }
    if (sb.isNotEmpty()) out.add(sb.toString())
    return out
}
