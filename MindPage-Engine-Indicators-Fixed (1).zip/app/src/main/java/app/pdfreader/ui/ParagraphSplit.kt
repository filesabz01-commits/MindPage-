package app.pdfreader.ui

/**
 * Turns the raw text of a page (PDF text layer or OCR: only line breaks, no blank lines) into real paragraphs,
 * so "show original next to translation" can show paragraph by paragraph instead of one block.
 */
object ParagraphSplit {
    private val sentenceEnd = charArrayOf('.', '!', '?', '؟', '؛', ':', ';', '"', '”', '»', ')', '…', '。')
    private val listStart = Regex("""^([-•*▪◦●]|\(?\d{1,2}[.)])\s+""")
    private val blankLine = Regex("""\n\s*\n""")

    fun isRtlText(text: String): Boolean {
        var arabic = 0
        var latin = 0
        for (c in text) {
            when {
                c in '\u0600'..'\u06FF' || c in '\uFB50'..'\uFEFF' -> arabic++
                c in 'A'..'Z' || c in 'a'..'z' -> latin++
            }
        }
        return arabic > latin
    }

    /** Paragraphs of the translation (the model keeps blank lines between paragraphs). */
    fun translated(text: String): List<String> =
        text.replace("\r\n", "\n").trim().split(blankLine).map { it.trim() }.filter { it.isNotEmpty() }

    /** Paragraphs of the original page text. Lines of one paragraph are joined into flowing text. */
    fun original(raw: String): List<String> {
        val text = raw.replace("\r\n", "\n").trim()
        if (text.isEmpty()) return emptyList()
        val out = ArrayList<String>()
        for (block in text.split(blankLine)) {
            val b = block.trim()
            if (b.isNotEmpty()) out.addAll(splitBlock(b))
        }
        return out
    }

    private fun splitBlock(block: String): List<String> {
        val lines = block.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.size <= 1) return lines
        // Tables and code keep their line structure.
        if (lines.any { it.startsWith("|") || it.startsWith("```") }) return listOf(lines.joinToString("\n"))

        val sorted = lines.map { it.length }.sorted()
        val full = sorted[(sorted.size * 9 / 10).coerceAtMost(sorted.size - 1)].coerceAtLeast(1)   // a "full" line

        fun endsSentence(s: String) = s.isNotEmpty() && s.last() in sentenceEnd
        fun isHeading(s: String) = s.length <= 80 && s.length < full * 0.7 && !endsSentence(s) && !s.endsWith(",") && !s.endsWith("-")
        fun startsNewSentence(s: String) = s.isNotEmpty() && !s[0].isLowerCase()

        val paragraphs = ArrayList<String>()
        val cur = StringBuilder(lines[0])
        for (i in 1 until lines.size) {
            val prev = lines[i - 1]
            val line = lines[i]
            val newParagraph =
                isHeading(prev) ||
                    isHeading(line) ||
                    listStart.containsMatchIn(line) ||
                    (endsSentence(prev) && prev.length < full * 0.85 && startsNewSentence(line))
            if (newParagraph) {
                paragraphs.add(cur.toString())
                cur.setLength(0)
                cur.append(line)
            } else if (cur.endsWith("-") && line.isNotEmpty() && line[0].isLowerCase()) {
                cur.setLength(cur.length - 1)
                cur.append(line)                       // "instru-" + "mentation" -> "instrumentation"
            } else {
                cur.append(' ').append(line)
            }
        }
        paragraphs.add(cur.toString())
        return paragraphs
    }
}
