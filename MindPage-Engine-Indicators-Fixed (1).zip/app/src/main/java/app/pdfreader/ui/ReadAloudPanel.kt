package app.pdfreader.ui

import app.pdfreader.ReaderApp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.platform.LocalContext
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.height
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.platform.LocalConfiguration
import android.content.res.Configuration
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.FloatingActionButton
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import app.pdfreader.tts.ReadAloudController
import app.pdfreader.tts.ReadState
import app.pdfreader.ui.l10n.LocalAppLanguage
import app.pdfreader.ui.l10n.LocalStrings
import app.pdfreader.ui.l10n.NumberFormatter
import app.pdfreader.ui.l10n.localize
import kotlinx.coroutines.delay

private val SPEEDS = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)

private fun clock(ms: Long, lang: String): String = NumberFormatter.formatClock(ms, lang)

/**
 * Bottom panel while reading aloud.
 *  - the sentence list is shown when the PDF itself cannot be highlighted (Persian / translated / OCR pages), or when
 *    the user asked for it; the "hide/show text" button works in every mode,
 *  - after a few seconds without touch the controls collapse into a round floating button (easy to hit);
 *    if the text list is enabled it stays visible next to that button; tapping the button brings the full player back.
 */
@Composable
fun ReadAloudPanel(read: ReadState, ctrl: ReadAloudController, modifier: Modifier = Modifier) {
    val repo = (LocalContext.current.applicationContext as ReaderApp).container.settings
    val settings = repo.state.collectAsStateWithLifecycle().value
    // One rule for every mode: where the PDF is highlighted the list is optional (off by default),
    // everywhere else it is the only visual (on by default). In both cases the button below can toggle it.
    val wantList = if (read.highlightPossible) settings.readText else !settings.hideFallbackText
    val listVisible = wantList && read.sentences.isNotEmpty()
    val onToggleText = {
        if (read.highlightPossible) repo.update { it.copy(readText = !it.readText) }
        else repo.update { it.copy(hideFallbackText = !it.hideFallbackText) }
    }

    val isFa = settings.appLanguage != "en"
    // Drive expand/collapse from controller so page-tap (ReaderScreen) can hide the bar too.
    val expanded = read.panelExpanded
    LaunchedEffect(read.playing, read.error, read.panelExpanded, read.status) {
        if (read.playing && read.error == null && read.panelExpanded) {
            delay(4_500)
            val s = ctrl.state.value
            // Only collapse once playback is running and there is no blocking error/status spam.
            if (s.playing && s.panelExpanded && s.error == null) {
                ctrl.setPanelExpanded(false)
            }
        }
    }

    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    // Minimal sizes: the panel must never take much of the page, especially in landscape.
    val listMaxHeight = if (landscape) 52.dp else 104.dp
    val panelShape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)

    Column(modifier.fillMaxWidth()) {
        if (!expanded) {
            // Collapsed: the player controls (slider, buttons) are gone. A small round button floats ABOVE the
            // text card (so it never narrows or covers the text); the text list stays when it is enabled.
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Row(
                    Modifier
                        .fillMaxWidth()
                        .then(if (listVisible) Modifier else Modifier.navigationBarsPadding())
                        .padding(end = 12.dp, bottom = if (listVisible) 6.dp else 10.dp),
                    horizontalArrangement = Arrangement.End,
                ) {
                    Box(
                        Modifier
                            .size(44.dp)
                            .shadow(6.dp, CircleShape)
                            .clip(CircleShape)
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .clickable { ctrl.setPanelExpanded(true) },
                        contentAlignment = Alignment.Center,
                    ) {
                        AppIconView(if (read.playing) AppIcon.Pause else AppIcon.Play, MaterialTheme.colorScheme.onPrimaryContainer, size = 22.dp)
                    }
                }
            }
            if (listVisible) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    tonalElevation = 6.dp,
                    shadowElevation = 8.dp,
                    shape = panelShape,
                ) {
                    Column(
                        Modifier
                            .navigationBarsPadding()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalArrangement = Arrangement.spacedBy(2.dp),
                    ) {
                        SentenceList(read, listMaxHeight)
                        if (!read.highlightPossible && read.highlightNote != null && !landscape) {
                            Text(read.highlightNote, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                shape = panelShape,
            ) {
                Column(
                    Modifier
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                                // Touch on the panel keeps it open / resets auto-hide timer.
                                ctrl.setPanelExpanded(true)
                            }
                        }
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp, vertical = if (landscape) 4.dp else 6.dp),
                    verticalArrangement = Arrangement.spacedBy(if (landscape) 2.dp else 4.dp),
                ) {
                    val note = read.error ?: read.status
                    if (note != null) {
                        Text(
                            note,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (read.error != null) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        )
                    }
                    if (listVisible) SentenceList(read, listMaxHeight)
                    if (listVisible && !read.highlightPossible && read.highlightNote != null && !landscape) {
                        Text(read.highlightNote, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (!landscape && read.engineLabels.isNotEmpty()) {
                        Text(
                            buildAnnotatedString {
                                read.engineLabels.forEachIndexed { index, label ->
                                    if (index > 0) {
                                        pushStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.45f)))
                                        append("  ·  ")
                                        pop()
                                    }
                                    pushStyle(SpanStyle(color = Color(0xFF16A34A), fontSize = 8.sp))
                                    append("✓ ")
                                    pop()
                                    pushStyle(SpanStyle(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.82f), fontSize = 8.sp))
                                    append(label)
                                    pop()
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, lineHeight = 10.sp),
                        )
                    }
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Controls(read, ctrl, listVisible, onToggleText, isFa, landscape)
                    }
                }
            }
        }
    }
}

@Composable
private fun SentenceList(read: ReadState, maxHeight: Dp) {
    val listState = rememberLazyListState()
    LaunchedEffect(read.sentenceIndex, read.sentences.size) {
        if (read.sentences.isNotEmpty() && read.sentenceIndex in read.sentences.indices) {
            // Keep the spoken sentence at the top of the (small) list.
            val target = read.sentenceIndex.coerceIn(0, read.sentences.lastIndex)
            try {
                listState.animateScrollToItem(target)
            } catch (ignored: Throwable) {}
        }
    }
    val dir = if (read.rtl) LayoutDirection.Rtl else LayoutDirection.Ltr
    CompositionLocalProvider(LocalLayoutDirection provides dir) {
        LazyColumn(Modifier.fillMaxWidth().heightIn(max = maxHeight), state = listState, verticalArrangement = Arrangement.spacedBy(2.dp)) {
            itemsIndexed(read.sentences) { i, sentence ->
                val current = i == read.sentenceIndex
                Text(
                    sentence,
                    modifier = Modifier.fillMaxWidth()
                        .background(
                            if (current) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
                            RoundedCornerShape(8.dp),
                        )
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                    style = MaterialTheme.typography.bodyMedium.copy(
                        textDirection = if (read.rtl) TextDirection.Rtl else TextDirection.Ltr,
                        textAlign = TextAlign.Start,
                    ),
                    color = if (current) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

/** Thin seek bar (the Material slider always takes 48 dp of height). */
@Composable
private fun MiniSeek(frac: Float, onChange: (Float) -> Unit, onFinish: () -> Unit, modifier: Modifier = Modifier) {
    val change = rememberUpdatedState(onChange)
    val finish = rememberUpdatedState(onFinish)
    Box(
        modifier
            .height(28.dp)
            .pointerInput(Unit) {
                detectTapGestures { o ->
                    change.value((o.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f))
                    finish.value()
                }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { o -> change.value((o.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f)) },
                    onDragEnd = { finish.value() },
                    onDragCancel = { finish.value() },
                ) { ch, _ ->
                    ch.consume()
                    change.value((ch.position.x / size.width.coerceAtLeast(1)).coerceIn(0f, 1f))
                }
            },
        contentAlignment = Alignment.CenterStart,
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.15f)),
        )
        Box(
            Modifier
                .fillMaxWidth(frac.coerceIn(0f, 1f))
                .height(4.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
        )
    }
}

@Composable
private fun MiniText(label: String, onClick: () -> Unit, color: Color = MaterialTheme.colorScheme.onSurface) {
    Box(
        Modifier
            .heightIn(min = 36.dp)
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center,
    ) { Text(label, style = MaterialTheme.typography.labelLarge, color = color) }
}

@Composable
private fun MiniIcon(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(36.dp)
            .clip(CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun Controls(
    read: ReadState,
    ctrl: ReadAloudController,
    showText: Boolean,
    onToggleText: () -> Unit,
    isFa: Boolean = true,
    landscape: Boolean = false,
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val frac = if (read.durationMs > 0L) {
        val raw = (read.positionMs.toDouble() / read.durationMs).toFloat()
        if (raw.isNaN() || raw.isInfinite()) 0f else raw.coerceIn(0f, 1f)
    } else 0f
    val appLang = LocalAppLanguage.current
    val isFaStr = LocalStrings.current.isFa
    val onSurface = MaterialTheme.colorScheme.onSurface

    val seek: @Composable (Modifier) -> Unit = { m ->
        MiniSeek(
            frac = drag ?: frac,
            onChange = { drag = it },
            onFinish = {
                drag?.let { ctrl.seekToFraction(it) }
                drag = null
            },
            modifier = m,
        )
    }
    val speedBtn: @Composable () -> Unit = {
        MiniText(NumberFormatter.formatSpeed(read.speed, appLang), {
            val i = SPEEDS.indexOfFirst { it >= read.speed }.let { if (it < 0) 0 else it }
            ctrl.setSpeed(SPEEDS[(i + 1) % SPEEDS.size])
        })
    }
    val prevBtn: @Composable () -> Unit = { MiniIcon({ ctrl.jumpSentence(-1) }) { AppIconView(AppIcon.Prev, onSurface, size = 22.dp) } }
    val nextBtn: @Composable () -> Unit = { MiniIcon({ ctrl.jumpSentence(1) }) { AppIconView(AppIcon.Next, onSurface, size = 22.dp) } }
    val backBtn: @Composable () -> Unit = { MiniText(if (isFaStr) "−۵ث" else "-5s", { ctrl.seekBy(-5_000) }) }
    val fwdBtn: @Composable () -> Unit = { MiniText(if (isFaStr) "+۵ث" else "+5s", { ctrl.seekBy(5_000) }) }
    val playBtn: @Composable () -> Unit = {
        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable(onClick = ctrl::toggle),
            contentAlignment = Alignment.Center,
        ) {
            AppIconView(if (read.playing) AppIcon.Pause else AppIcon.Play, MaterialTheme.colorScheme.onPrimary, size = 24.dp)
        }
    }
    val textBtn: @Composable () -> Unit = {
        MiniText(
            label = if (isFa) "متن" else "Text",
            onClick = onToggleText,
            color = if (showText) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
    val closeBtn: @Composable () -> Unit = {
        MiniIcon(ctrl::stop) { Icon(Icons.Default.Close, contentDescription = "بستن", modifier = Modifier.size(20.dp)) }
    }

    if (landscape) {
        // One single row in landscape.
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            speedBtn(); prevBtn(); backBtn(); playBtn(); fwdBtn(); nextBtn()
            Text(clock(read.positionMs, appLang), style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(start = 6.dp))
            seek(Modifier.weight(1f).padding(horizontal = 8.dp))
            Text(clock(read.durationMs, appLang), style = MaterialTheme.typography.labelSmall)
            textBtn(); closeBtn()
        }
    } else {
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(clock(read.positionMs, appLang), style = MaterialTheme.typography.labelSmall)
                seek(Modifier.weight(1f).padding(horizontal = 8.dp))
                Text(clock(read.durationMs, appLang), style = MaterialTheme.typography.labelSmall)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                speedBtn(); prevBtn(); backBtn(); playBtn(); fwdBtn(); nextBtn(); textBtn(); closeBtn()
            }
        }
    }
}
