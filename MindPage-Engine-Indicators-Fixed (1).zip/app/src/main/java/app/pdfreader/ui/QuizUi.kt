package app.pdfreader.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class QuizConfig(
    val fromPage: Int,
    val toPage: Int,
    val level: String = "medium", // easy | medium | hard
    val count: Int = 5,
    val kind: String = "both", // mc | essay | both
)

sealed class QuizItem {
    abstract val question: String
    abstract val explanation: String

    data class Mc(
        override val question: String,
        val options: List<String>,
        val correctIndex: Int,
        override val explanation: String,
    ) : QuizItem()

    data class Essay(
        override val question: String,
        override val explanation: String,
    ) : QuizItem()
}

/**
 * Parses a structured quiz block produced by the study/quiz prompts.
 *
 * Expected shape:
 * ### Q1 [MC]
 * question
 * A) ...
 * B) ...
 * **Answer:** B
 * **Explain:** ...
 *
 * ### Q2 [ESSAY]
 * question
 * **Answer:** ...
 */
fun parseQuizItems(md: String): List<QuizItem> {
    val parts = md.split(Regex("(?m)^###\\s+Q\\d+.*$"))
    if (parts.size < 2) return emptyList()
    val headers = Regex("(?m)^###\\s+Q\\d+\\s*\\[(MC|ESSAY)\\]", RegexOption.IGNORE_CASE)
        .findAll(md).map { it.groupValues[1].uppercase() }.toList()
    val out = ArrayList<QuizItem>()
    for (i in 1 until parts.size) {
        val block = parts[i].trim()
        if (block.isEmpty()) continue
        val kind = headers.getOrNull(i - 1) ?: if (Regex("(?m)^[A-D]\\)").containsMatchIn(block)) "MC" else "ESSAY"
        val answerLine = Regex("(?im)^\\*\\*Answer:\\*\\*\\s*(.+)$").find(block)?.groupValues?.get(1)?.trim().orEmpty()
        val explain = Regex("(?im)^\\*\\*Explain:\\*\\*\\s*(.+)$").find(block)?.groupValues?.get(1)?.trim()
            ?: Regex("(?im)^\\*\\*Answer:\\*\\*\\s*[A-D]\\s*[\n\r]+([\\s\\S]+)$").find(block)?.groupValues?.get(1)?.trim().orEmpty()
        val bodyLines = block.lines()
            .filterNot { it.trim().startsWith("**Answer:", ignoreCase = true) || it.trim().startsWith("**Explain:", ignoreCase = true) }
        if (kind == "MC") {
            val opts = bodyLines.mapNotNull { line ->
                val m = Regex("^\\s*([A-D])\\)\\s*(.+)$").find(line.trim()) ?: return@mapNotNull null
                m.groupValues[2].trim()
            }
            val q = bodyLines
                .filterNot { Regex("^\\s*[A-D]\\)\\s*").containsMatchIn(it) }
                .joinToString(" ") { it.trim() }
                .trim()
            val letter = answerLine.trim().firstOrNull()?.uppercaseChar()
            val idx = when (letter) {
                'A' -> 0; 'B' -> 1; 'C' -> 2; 'D' -> 3
                else -> answerLine.toIntOrNull()?.minus(1) ?: 0
            }.coerceIn(0, (opts.size - 1).coerceAtLeast(0))
            if (q.isNotBlank() && opts.size >= 2) {
                out += QuizItem.Mc(q, opts, idx, explain.ifBlank { answerLine })
            }
        } else {
            val q = bodyLines.joinToString(" ") { it.trim() }.trim()
            if (q.isNotBlank()) out += QuizItem.Essay(q, answerLine.ifBlank { explain })
        }
    }
    return out
}

@Composable
fun QuizItemsView(items: List<QuizItem>, isFa: Boolean) {
    val selected = remember { mutableStateMapOf<Int, Int>() }
    val guideOpen = remember { mutableStateMapOf<Int, Boolean>() }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEachIndexed { index, item ->
            when (item) {
                is QuizItem.Mc -> McQuestionCard(
                    index = index,
                    item = item,
                    selectedIndex = selected[index],
                    guideOpen = guideOpen[index] == true,
                    isFa = isFa,
                    onSelect = { opt ->
                        selected[index] = opt
                        guideOpen[index] = true
                    },
                    onToggleGuide = { guideOpen[index] = !(guideOpen[index] ?: false) },
                )
                is QuizItem.Essay -> EssayQuestionCard(
                    index = index,
                    item = item,
                    guideOpen = guideOpen[index] == true,
                    isFa = isFa,
                    onToggleGuide = { guideOpen[index] = !(guideOpen[index] ?: false) },
                )
            }
        }
    }
}

@Composable
private fun McQuestionCard(
    index: Int,
    item: QuizItem.Mc,
    selectedIndex: Int?,
    guideOpen: Boolean,
    isFa: Boolean,
    onSelect: (Int) -> Unit,
    onToggleGuide: () -> Unit,
) {
    val revealed = selectedIndex != null
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "${index + 1}. ${item.question}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            )
            item.options.forEachIndexed { oi, opt ->
                val isCorrect = oi == item.correctIndex
                val isSelected = selectedIndex == oi
                val borderColor = when {
                    !revealed -> MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                    isCorrect -> MaterialTheme.colorScheme.primary
                    isSelected -> MaterialTheme.colorScheme.error
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                }
                val bg = when {
                    !revealed -> MaterialTheme.colorScheme.surface
                    isCorrect -> MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f)
                    isSelected -> MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.45f)
                    else -> MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .border(1.dp, borderColor, RoundedCornerShape(12.dp))
                        .clickable(enabled = !revealed) { onSelect(oi) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Text("${'A' + oi})", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text(opt, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
                    if (revealed && isCorrect) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    } else if (revealed && isSelected && !isCorrect) {
                        Icon(Icons.Default.Close, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    }
                }
                // recolor via surface wrapper for selected states
                if (revealed && (isCorrect || isSelected)) {
                    // visual already via border; keep simple
                }
                Spacer(Modifier.height(0.dp))
            }
            GuideRow(
                open = guideOpen,
                label = if (isFa) "راهنما / پاسخ" else "Guide / Answer",
                onToggle = onToggleGuide,
            ) {
                val letter = ('A' + item.correctIndex).toString()
                Text(
                    if (isFa) "پاسخ درست: گزینه $letter" else "Correct: $letter",
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.primary,
                )
                if (item.explanation.isNotBlank()) {
                    Text(item.explanation, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun EssayQuestionCard(
    index: Int,
    item: QuizItem.Essay,
    guideOpen: Boolean,
    isFa: Boolean,
    onToggleGuide: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(
                "${index + 1}. ${item.question}",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
            )
            GuideRow(
                open = guideOpen,
                label = if (isFa) "پاسخ نمونه" else "Sample answer",
                onToggle = onToggleGuide,
            ) {
                Text(
                    item.explanation.ifBlank { if (isFa) "پاسخی ثبت نشده." else "No sample answer." },
                    style = MaterialTheme.typography.bodyMedium,
                )
            }
        }
    }
}

@Composable
private fun GuideRow(
    open: Boolean,
    label: String,
    onToggle: () -> Unit,
    content: @Composable () -> Unit,
) {
    Column {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable(onClick = onToggle)
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
            Text(label, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.tertiary)
            Icon(if (open) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
        }
        AnimatedVisibility(visible = open) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    content()
                }
            }
        }
    }
}
