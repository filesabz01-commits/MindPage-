package app.pdfreader.ai

import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Random
import org.junit.Assert.assertTrue
import org.junit.Test

class WavBurstTest {
    private val rate = 24_000

    private fun voiced(seconds: Double): ShortArray = ShortArray((seconds * rate).toInt()) { i ->
        val t = i.toDouble() / rate
        val env = 0.6 + 0.4 * Math.sin(2 * Math.PI * 4 * t)
        (env * (3000 * Math.sin(2 * Math.PI * 150 * t) + 1500 * Math.sin(2 * Math.PI * 300 * t))).toInt().toShort()
    }

    private fun wavOf(parts: List<ShortArray>): ByteArray {
        val total = parts.sumOf { it.size }
        val bb = ByteBuffer.allocate(total * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (p in parts) for (v in p) bb.putShort(v)
        return Wav.fromPcm16(bb.array(), rate)
    }

    private fun noise(seconds: Double, amp: Int): ShortArray {
        val r = Random(1)
        return ShortArray((seconds * rate).toInt()) { ((r.nextInt(2 * amp + 1)) - amp).toShort() }
    }

    @Test
    fun trailingNoiseBurstAfterQuietGapIsRemoved() {
        val withBurst = wavOf(listOf(voiced(2.2), ShortArray((0.22 * rate).toInt()) { 40 }, noise(0.13, 11_000), ShortArray((0.4 * rate).toInt())))
        val plain = wavOf(listOf(voiced(2.2)))
        val a = Wav.durationMs(Wav.polish(withBurst))
        val b = Wav.durationMs(Wav.polish(plain))
        assertTrue("burst should be cut (got $a ms vs clean $b ms)", a <= b + 60)
    }

    @Test
    fun cleanSpeechIsNotShortened() {
        val plain = wavOf(listOf(voiced(2.2)))
        val d = Wav.durationMs(Wav.polish(plain))
        assertTrue("speech must stay (got $d ms)", d >= 2_150)
    }
}
