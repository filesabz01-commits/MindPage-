package app.pdfreader.tts

import app.pdfreader.ai.Pause
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SentenceTimingTest {

    @Test
    fun usesRealSentencePauses_andIgnoresShortCommaPauses() {
        // 4 sentences of equal length, real boundaries at 5000 / 10000 / 15000 ms, plus a comma pause at 7400 ms.
        val lens = intArrayOf(80, 80, 80, 80)
        val pauses = listOf(
            Pause(4800, 5200),
            Pause(7300, 7500),
            Pause(9800, 10200),
            Pause(14800, 15200),
        )
        val starts = SentenceTiming.align(lens, 20_000, pauses)
        assertEquals(0L, starts[0])
        assertEquals(5000L, starts[1])
        assertEquals(10000L, starts[2])
        assertEquals(15000L, starts[3])
    }

    @Test
    fun withoutPauses_fallsBackToEstimate_andStaysOrdered() {
        val starts = SentenceTiming.align(intArrayOf(50, 100, 150), 9_000, emptyList())
        assertEquals(0L, starts[0])
        assertTrue(starts[1] > starts[0])
        assertTrue(starts[2] > starts[1])
        assertTrue(starts[2] < 9_000)
    }

    @Test
    fun singleSentence_startsAtZero() {
        val starts = SentenceTiming.align(intArrayOf(120), 6_000, emptyList())
        assertEquals(1, starts.size)
        assertEquals(0L, starts[0])
    }
}
