# MindPage 0.1.26 — changes

Build fix
- ReadAloudController: `Plan` is now a data class (CI error: Unresolved reference 'copy' at line 527).

Logic fixes
- OCR: removed dead `local_fa` / `local_en` flags (they could never be true); `ocrMinConfidence` now affects the Persian OCR "good" verdict.
- OCR: ML Kit failures are reported instead of looking like an empty page.
- Google Translate: `translateChunk` is suspend (delay instead of Thread.sleep, cancellable); base URL is passed as a parameter (no global mutable state).
- AiRouter: daily-quota cooldown lasts until the Pacific-time reset (min 15 min, max 12 h); repeated BAD_REQUEST stops after 2 models.
- Database: ai_cache is pruned when it passes ~120 MB (oldest 30%); ai_attempts keeps the last 1000 rows (runs at app start).

Extraction
- Translation now asks for structured text (`extract(..., structured = true)`, used only by the page Translate task). Geometry text is adopted only if it really found a table (`| --- |`) or a watermark; otherwise plain reading order is kept (protects two-column pages). TTS, Study Mode and Chat still use plain text. Separate cache key for structured results.
- When the plain text layer contains publisher/watermark noise or a table caption, geometry-based text is used. It drops rotated text in the left/right margin and keeps table cells apart. Extraction cache key bumped to v14.

Other
- Prompt no longer contains book-specific names. APK limited to arm64-v8a and armeabi-v7a. Version 0.1.26 (code 26).

Tables (reported: scrambled / incomplete tables, text pieces in the middle)
- TextQuality.localClean: Markdown table rows are no longer passed through the "junk/diagram" filter (it dropped rows that mention P&ID, valve, symbol, rule...).
- PdfiumTextEngine.tryExtractTable: a cell that wraps over several lines is merged into ONE row (by vertical gaps, or by an empty first column); under a "Table N" caption long cell lines no longer end the table early; the table is cut where prose crosses the column gutters and the rest returns as normal text.
